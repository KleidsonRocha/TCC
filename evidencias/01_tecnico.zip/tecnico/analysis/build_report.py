"""Author the final report only after every preregistered case is complete."""
from collections import Counter
from datetime import datetime,timezone
import hashlib
import html
import json
from pathlib import Path
import re
import shutil
import statistics
import zipfile
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1];REPO=ROOT.parents[2]
OUT=ROOT.parent if ROOT.name=='tecnico' else REPO/'.tmp/Documents/avaliacao_final_projeto_20261026'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def num(x,d=2):return 'não aplicável' if x is None else f'{x:.{d}f}'.replace('.',',')
def pct(x,n):return 'não aplicável' if not n else num(100*x/n,1)+'%'
def main():
    result=read(ROOT/'summary.json');assert result['complete'] and result['observed_case_records']==3408
    assert (ROOT/'runs/completed.json').exists()
    audit=read(ROOT/'input_audit.json');independence=read(ROOT/'independence_audit_extended.json')
    selection=read(ROOT/'review_selection.json');protocol=read(ROOT/'protocol.json')
    began=read(ROOT/'runs/environment.json')['started_at']
    ended=read(ROOT/'runs/completed.json')['completed_at']
    recovery=read(ROOT/'recovery_20261027.json') if (ROOT/'recovery_20261027.json').exists() else None
    data=result['per_repetition'];cat=data['categories']['1'];d,h=cat['D'],cat['H']
    sections=[]
    def p(s):sections.append(('p',s))
    def heading(s):sections.append(('h2',s))
    def table(headers,rows):sections.append(('table',(headers,rows)))
    p('Este documento consolida uma nova avaliação técnica do projeto em 26 de outubro de 2026: comparação do fluxo determinístico com o fluxo híbrido, reexecução em versão congelada e preparação da revisão comercial independente. Os testes automatizados foram executados; a compatibilidade comercial final permanece pendente das respostas de especialistas. Nenhum julgamento humano foi preenchido pelo agente.')
    pair1=result['paired_categories']['1']
    p(f"Na primeira repetição das 371 conversas, H acionou inferência em {h['residual_exposed_cases']} casos ({pct(h['residual_exposed_cases'],371)}), enquanto D fez zero chamadas. Houve {pair1['identical_conversations']} conversas idênticas entre as configurações. Somente H apresentou produtos em {pair1['H_only_presented_items']} casos e somente D em {pair1['D_only_presented_items']}. Esses resultados medem comportamento e autonomia; não comprovam, sem revisão comercial, que os produtos adicionais ou encaminhamentos foram adequados. As três repetições completas estão detalhadas abaixo.")
    table(['Frente','Entrega realizada','Limite que permanece'],[
        ['Contribuição incremental da LLM','Ablação pareada D versus H, com três repetições e mesma fonte e código','Benefício comercial depende de julgar perguntas, encaminhamentos e candidatos; D usa política conservadora de handoff residual'],
        ['Validação comercial','Auditoria dos 371 casos (337 com referência) e ficha mascarada com lote inicial de 60 e acesso aos 371','Necessárias duas revisões humanas independentes e tratamento das discordâncias'],
        ['Versão consolidada','3408 execuções de caso planejadas e concluídas, além dos testes automatizados','A bateria histórica não se torna amostra aleatória ou gabarito comercial apenas por ser reexecutada']])
    heading('1 Perguntas de pesquisa e alcance')
    p('A comparação procura determinar o que muda quando a mesma arquitetura passa a usar inferência residual: recuperação observada, necessidade de encaminhamento, preservação do pedido, repetição de perguntas, erros técnicos e custo de tempo. Não compara uma LLM isolada contra SQL, não cria um novo modelo e não repete o fine-tuning de 19/10/2026. A condição H utiliza o modelo base do Ollama; o adapter LoRA não foi importado nem promovido.')
    p('O estudo mede a cópia congelada do código disponível localmente, identificada pelo commit '+protocol['git_commit']+' e por hashes dos arquivos. A diferença de trabalho local foi registrada. A cópia do catálogo foi atualizada com os CSVs congelados e a busca utilizou o snapshot exportado em 19/10/2026: 52.798 produtos e 1.779.443 aplicações. Os serviços de atendimento ativos não foram atualizados ou reiniciados por esta avaliação.')
    heading('2 Condições comparadas e intervenção')
    table(['Condição','Comportamento'],[
        ['D sem LLM','Mantém extração, aliases, regras, estado, provas contextuais no banco, desambiguação e busca. Quando chega ao ponto em que seria necessária inferência residual, aplica encaminhamento humano explícito e conservador. Não simula timeout, não fabrica JSON de modelo e não contabiliza essa decisão como falha técnica.'],
        ['H híbrida','Executa os mesmos caminhos determinísticos. Somente o caminho residual chama qwen2.5:7b e mantém os controles existentes do backend sobre a resposta.']])
    p('O encaminhamento residual define uma alternativa operacional para D. Portanto, o efeito estimado é relativo a essa política, não ao melhor sistema determinístico que poderia ser desenvolvido. Um handoff pode ser a decisão correta; uma busca adicional pode ser inadequada. A qualidade dessas diferenças precisa do julgamento comercial cego. O código do produto não foi alterado para favorecer uma condição; a intervenção fica no harness de avaliação e preserva os mesmos helpers de preparação antes da inferência.')
    p('O tratamento H inclui a inferência e o processamento existente de sua proposta: validação, coerção e possíveis fallbacks do backend. A ablação mede a contribuição operacional desse ramo híbrido em relação ao encaminhamento residual declarado. Ela não separa quanto de cada saída adicional decorreu da geração linguística e quanto decorreu das regras que interpretaram ou repararam a proposta. Os traces e conteúdos brutos permitem investigar essa atribuição por caso; não se deve creditar automaticamente todo produto adicional a raciocínio autônomo do modelo.')
    p('As chamadas efetivas ao provedor foram registradas separadamente dos nomes internos de ferramentas. No caminho D, a contagem de chamadas de inferência é zero. Nomes legados como pre_search_validator no trace não foram usados para presumir que houve chamada à LLM.')
    p('As contagens de chamadas e as métricas de resposta referem-se aos registros de caso concluídos, incluindo os que terminaram com erro registrado. A tentativa interrompida sem resultado salvo fica identificada separadamente e não pode ser quantificada integralmente por esses registros. Os logs dos serviços isolados são preservados como diagnóstico adicional; incluem pilotos e reaquecimentos excluídos e não devem ser somados indiscriminadamente às medições oficiais.')
    heading('3 Congelamento e execução')
    table(['Aspecto','Configuração'],[
        ['Período registrado (UTC)',began+' até '+ended],
        ['Código','Cópia somente leitura do app, scripts, testes, seeds e documentação; manifestos de hashes antes da rodada oficial'],
        ['Dados','PostgreSQL exclusivo, sem porta publicada, catálogo sem linhas de revisão/treino e snapshot verificado; banco selado com default_transaction_read_only=on'],
        ['Inferência','Servidor Ollama exclusivo, sem porta publicada, pesos existentes montados em somente leitura; qwen2.5:7b, digest 845dbda0ea48ed749caafd9e6037047aa19acfcfd82e704d7ca97d631a0b697e, formato GGUF Q4_K_M'],
        ['Recursos','Docker local com 8 CPUs virtuais e aproximadamente 16,65 GB disponibilizados; servidor de inferência limitado a 4 CPUs e 8 GB; execução em CPU, sem GPU'],
        ['Geração','Temperatura 0, num_predict 220, contexto 8192, num_thread 4, seed 20261026; restrição de JSON existente'],
        ['Repetições','Três por configuração e caso. Ordem D/H determinada por hash, invertida na segunda repetição e contrabalançada na terceira'],
        ['Bloqueio','As três repetições do mesmo caso são executadas antes do próximo. O cache de prefixo do Ollama permanece ativo; não existe cache de resposta da aplicação'],
        ['Aquecimento','Geração curta excluída das métricas. Pilotos ficam separados; uma duração keep_alive inválida foi corrigida antes de qualquer rodada oficial'],
        ['Concorrência','Um caso por vez. Não é teste de carga nem simulação de clientes simultâneos'],
        ['Segurança operacional','Sem chamadas ao ERP quente, sem escrita na fila, sem alteração de pesos, sem mensagens ao WhatsApp e sem reinício dos serviços ativos']])
    p('Os arquivos protocol_registered_v1.json, protocol.json e freeze_manifest_v2.json preservam o protocolo e a correção de infraestrutura feita no piloto. Os pilotos foram excluídos. As saídas oficiais são salvas por caso concluído; a retomada usa somente arquivos já concluídos. Cada inferência planejada é uma nova chamada. Erros de infraestrutura, caso existam, permanecem separados de resultado vazio e de inadequação comercial.')
    if recovery:
        p('Houve interrupção externa entre 26 e 27/10/2026. Ao continuar, o Docker Desktop estava desligado e o runner anterior não existia. Foram preservados '+str(recovery['completed_case_records_preserved'])+' registros concluídos, até D da segunda repetição do caso sub-19-10. O motor foi iniciado em 27/10 e reiniciou automaticamente os serviços existentes, com as mesmas imagens. Somente os contêineres do laboratório foram iniciados explicitamente para a retomada. O catálogo, os 199 hashes e o digest do modelo foram reconferidos. Um reaquecimento curto foi registrado e excluído das métricas. O primeiro caso incompleto foi executado novamente; o resultado da tentativa interrompida não foi recuperado e não foi classificado como falha de qualidade do modelo.')
        p('O estudo tem dois segmentos de execução. As datas de cada caso permitem separá-los, e a análise complementar mostra os pares de latência que atravessam a interrupção. As diferenças de cache e carga após o reinício limitam a interpretação dos tempos agregados. A rodada não deve ser descrita como uma execução contínua ou um benchmark controlado de capacidade. Protocolo, código, entradas, pesos e critérios de avaliação foram preservados na retomada.')
        p('A pausa entre os segmentos não foi somada aos tempos de resposta. A latência por caso é a soma dos tempos dos seus turnos registrados; não corresponde à diferença de relógio entre a primeira execução de D e a execução posterior de H. O período total do estudo inclui a interrupção e não representa tempo contínuo de processamento.')
    heading('4 Conjuntos e unidade de análise')
    total_turns=sum(arm['turns'] for suite in data.values() for repetition in suite.values() for arm in repetition.values())
    p('Foram preservados '+str(total_turns)+' registros de turno, com pedidos, respostas, estado e telemetria. Um turno é uma interação de entrada/saída, e não uma conversa ou cliente independente.')
    table(['Conjunto','Casos por condição e repetição','Como interpretar'],[
        ['Categorias e subcategorias',371,'24 grupos e 347 subgrupos, com 347 mensagens iniciais normalizadas distintas. Mesmas entradas originais; follow-ups respondidos com fatos da referência. Referências duvidosas seguem marcadas para revisão.'],
        ['Regressão estrutural',170,'208 turnos fixos por condição e repetição. Replay das mensagens e expectativas existentes; inclui regressões, negação, aliases, estado e contrato. Não é rótulo comercial independente.'],
        ['Golden no fluxo completo',27,'Checagem dos campos esperados da primeira decisão pré-busca e registro do atendimento completo. Não é a avaliação isolada BF16 do experimento de fine-tuning.']])
    p('A soma é 568 identificadores por condição e repetição, totalizando 3408 registros de caso nas duas condições e três repetições. Esses identificadores não são 568 clientes independentes: há sobreposição de mensagens entre conjuntos, duplicação de categoria/subcategoria e várias observações do mesmo caso. Turnos e chamadas também não são tratados como clientes adicionais. Na bateria estrutural, os turnos fixos continuam sendo reproduzidos mesmo após um handoff anterior; essa propriedade testa regressão de contrato, não descreve uma conversa natural continuada após transferência.')
    p('Na bateria de categorias, a resposta seguinte depende da pergunta feita e de fatos da mesma referência. As duas configurações podem gerar números diferentes de turnos; o pareamento é por caso inicial. Os pedidos históricos não foram reescritos para favorecer o agente. A auditoria automática acrescenta flags e rastreabilidade, mas não substitui a curadoria humana necessária para uma bateria comercial revisada.')
    p('A coleção foi construída para percorrer a taxonomia e inclui pedidos baseados em títulos de catálogo, alguns extensos, ambíguos ou contraditórios. Não é uma amostra aleatória de conversas reais de clientes. O respondente de follow-up é automatizado e utiliza a referência registrada; quando essa referência está errada ou não sustenta a aplicação, a própria conversa simulada pode ficar contaminada. A origem de cada resposta incremental está preservada nos JSONs. A validade comercial e a naturalidade do pedido continuam sendo questões para a revisão humana e para os novos casos prospectivos.')
    p('Cobrir as 371 entradas históricas não significa testar todos os produtos, aplicações ou classificações do ERP. A revisão de subcategorias da fonte ausentes do catálogo ativo continua no backlog. Os scopes curados ajudam a preservar identidades existentes, mas não tornam essa bateria uma prova de cobertura integral do catálogo comercial.')
    heading('5 Controles automatizados e resultados estruturais')
    table(['Controle','Resultado'],[['Agente com PostgreSQL de testes','604 testes aprovados, nenhum ignorado'],['Gateway com Redis de testes','33 testes aprovados, nenhum ignorado'],['Dependências','Uma advertência de depreciação Starlette/AnyIO em cada suíte; não houve falha nesses controles'],['Modelo e fontes','Manifestos, hashes, contagens de snapshot, catálogo com 19 conceitos e 45 decisões de alias'],['Serviços ativos','Conferência de identidade e início registrada antes e depois, em active_services_before.txt e active_services_after.txt']])
    table(['Repetição','Estrutural D','Estrutural H','Golden D','Golden H'],[
        [r,str(data['structural'][str(r)]['D']['structural_case_passes'])+'/170',str(data['structural'][str(r)]['H']['structural_case_passes'])+'/170',
         str(data['golden_flow'][str(r)]['D']['golden_expected_field_passes'])+'/27',str(data['golden_flow'][str(r)]['H']['golden_expected_field_passes'])+'/27'] for r in [1,2,3]])
    p('A aprovação estrutural aplica as expectativas registradas, incluindo algumas expectativas de caminho e ferramenta. Uma diferença intencional da política sem LLM pode reprovar esse teste sem ser uma conduta comercial insegura; as falhas individuais estão preservadas. O golden continua sendo uma checagem parcial de campos esperados e não reprova genericamente todo slot extra. Os resultados não devem ser chamados de acurácia semântica integral.')
    eco_d=read(ROOT/'runs/rep_1/structural/D/search_008.json')
    eco_h=read(ROOT/'runs/rep_1/structural/H/search_008.json')
    if not eco_h['structural_pass']:
        assert all(not t['llm_calls'] for r in [eco_d,eco_h] for t in r['turns'])
        p('Achado verificável no cenário search_008: o pedido é “coxim amort ecosport 2008 zetec rocam dianteiro”. D e H perguntam “Qual a motorizacao do veiculo?”, conservando engine nulo, embora ZETEC ROCAM apareça entre as opções oferecidas. A expectativa de busca direta fica reprovada e foi preservada. Nenhuma LLM foi chamada nesse caso; a omissão ocorre no caminho determinístico/catálogo. É necessário investigar o reconhecimento do motor textual e distinguir dado ausente de identificação ainda insuficiente. A segurança de liberar busca apenas com o nome da família do motor precisa de evidência de aplicação e não foi decidida automaticamente nesta análise.')
    vague=read(ROOT/'runs/rep_1/structural/H/disambiguation_005.json')
    if vague['structural_pass'] and len(vague['turns'])==4 and len({t['assistant'] for t in vague['turns']})==1:
        p('Exemplo do alcance das expectativas: disambiguation_005 passa nas checagens estruturais, mas registra o mesmo texto de apresentação de quatro opções após “radiador focus 2010 1.6”, “talvez”, “aquela” e “indefinido”. As três respostas posteriores acionaram a LLM. O registro não comprova que essa interação seja comercialmente útil ou que tenha resolvido a ambiguidade. Ele mostra por que aprovação de contrato, condução conversacional e adequação dos produtos precisam de julgamentos distintos; a conversa e suas ações completas estão preservadas no leitor.')
    table(['Casos estruturais conferidos, repetição 1','Evidência observada','Interpretação e próxima verificação'],[
        ['real_004_regression','Após polia da bomba d’água, o usuário pede rolamentos e informa 2013. O estado volta de rolamentos para polia nas duas condições.','D também reproduz a troca sem inferência: revisar precedência do componente atual sobre o histórico. É dívida determinística já registrada no projeto, ainda reproduzida.'],
        ['disambiguation_002','H reapresenta as três opções do EcoSport após “nenhuma dessas”; D encaminha. A expectativa no_match_retry fica reprovada.','Revisar rejeição de lista curta e impedir que uma nova inferência ignore a rejeição explícita. Não equivale à rejeição de uma página parcial.'],
        ['disambiguation_007','Após rejeitar a página visível de dez entre doze opções, D/H mostram as duas restantes, sem inferência.','O código atual exclui os candidatos visíveis e permite os restantes; reconciliar a expectativa antiga de no_match_retry com essa política de paginação. Não classificar isso automaticamente como mesma falha do caso anterior.'],
        ['erp_batentes_s10_1996_dianteiro','“Batente” provoca pergunta de componente/função; “dianteiro” não resolve a família e H encaminha.','A curadoria vigente separa batente de carroceria/suspensão. A expectativa antiga de pesquisar “batentes” precisa revisão sem remover a exigência de identidade.'],
        ['real_046_regression','A consulta de junta da tampa de válvula retorna vazio e items_contains reprova porque a lista de critérios no estado não está materializada.','items_contains verifica ConversationState.items, não produtos do ERP. Reconciliar representação de solicitação única; não transformar essa mensagem em falso negativo confirmado sem candidato e mesma aplicação.']])
    p('Essa triagem preserva os escores registrados e evita tratar todas as reprovações como defeito da LLM ou como referência obsoleta. O inventário completo está em checagens_e_falhas.md e failures_and_controls.json. Critérios de contrato, texto, estado e catálogo devem ser revisados com sua fonte normativa e evidência antes de produzir outra versão de expectativas.')
    table(['Reprovações H no golden da primeira repetição','Conferência no fluxo','Limite da interpretação do escore'],[
        ['ask_correia_side','A regra vigente deixou de exigir lado para correia de comando; o primeiro validador decide search.','A expectativa antiga de pedir lado não acompanha a curadoria atual.'],
        ['ask_coxins_position','O agente pergunta se o coxim é de motor/câmbio ou amortecedor antes de pedir posição.','A pergunta atual prioriza identidade; o golden ainda espera position.'],
        ['search_multi_item_gate_radiador_bandeja','O primeiro retorno pré-busca mistura CORSA com o radiador, mas o use case separa radiador/GOL/2010 e bandeja/CORSA/2011; a busca registrada usa apenas o Gol e a bandeja aguarda lado.','O escore verifica o primeiro retorno, não o estado/consulta finais. É evidência de divergência entre etapas do contrato, sem demonstrar busca final cruzada entre veículos.']])
    p('Os resultados 22/27 em D e 24/27 em H foram mantidos conforme o avaliador original, em todas as repetições. A triagem acima não os transforma retroativamente em aprovação total. Para outro benchmark, é necessário versionar expectativas alinhadas à política atual e decidir explicitamente qual etapa é avaliada; comparação de modelo isolado e comportamento final do runtime não podem ser confundidos.')
    heading('6 Comparação das conversas por categoria')
    table(['Indicador da repetição 1','D sem LLM','H híbrida'],[
        ['Casos',d['cases'],h['cases']],['Turnos',d['turns'],h['turns']],
        ['Casos com alguma busca',d['searched_cases'],h['searched_cases']],
        ['Casos com produtos apresentados',d['items_presented_cases'],h['items_presented_cases']],
        ['Triagem automática coerente com cadastro',d['screening'].get('catalog_coherent_screen',0),h['screening'].get('catalog_coherent_screen',0)],
        ['Triagem de possível divergência cadastral',d['screening'].get('catalog_mismatch_suspected',0),h['screening'].get('catalog_mismatch_suspected',0)],
        ['Casos com handoff',d['handoff_cases'],h['handoff_cases']],['Repetição de slot/resposta no simulador',d['repeated_question_cases'],h['repeated_question_cases']],
        ['Casos com erro técnico',d['technical_error_cases'],h['technical_error_cases']],['Chamadas de inferência',d['llm_calls'],h['llm_calls']]])
    table(['Repetição','Casos expostos ao caminho residual em algum braço','Só H apresentou itens','Só D apresentou itens','Conversas idênticas'],[
        [r,result['paired_categories'][str(r)]['exposed_pairs'],result['paired_categories'][str(r)]['H_only_presented_items'],
         result['paired_categories'][str(r)]['D_only_presented_items'],result['paired_categories'][str(r)]['identical_conversations']] for r in [1,2,3]])
    table(['Motivo de término da simulação, repetição 1','D','H'],[
        [reason,d['stop_reasons'].get(reason,0),h['stop_reasons'].get(reason,0)]
        for reason in sorted(set(d['stop_reasons'])|set(h['stop_reasons']))])
    p('Uma redução de handoffs também pode terminar em nova pergunta sem uma resposta comprovada disponível na referência. Por isso, produtos apresentados, encaminhamento e simulação não concluída são mostrados separadamente. A falta de resposta do simulador não demonstra que um cliente real seria incapaz de responder, nem garante que a pergunta foi necessária.')
    extra=[]
    for case in read(ROOT/'paired_category_results.json'):
        comparison=next(r for r in case['repetitions'] if r['repetition']==1)
        if comparison['H_items'] and not comparison['D_items']:
            original_d=read(ROOT/'runs/rep_1/categories/D'/(case['id']+'.json'))
            extra.append([case['id'],case['initial_message'],original_d['stop_reason'],', '.join(comparison['H_codes'])])
    assert len(extra)==pair1['H_only_presented_items']
    table(['Casos com apresentação somente em H, repetição 1','Pedido inicial','Término em D','Códigos apresentados em H'],extra)
    p('A tabela enumera todos os casos de apresentação adicional dessa repetição, sem selecionar apenas exemplos favoráveis. São candidatos para inspeção, não novos acertos comerciais confirmados. As conversas completas, filtros e aplicações do catálogo estão no leitor e no dossiê; a revisão mascarada deve ocorrer antes de entregar esta identificação das configurações aos avaliadores.')
    p('Essas diferenças quantificam a contribuição operacional da inferência para esta coleção. Não demonstram sozinhas ganho de precisão: o contador de produtos adicionais pode incluir candidatos inadequados, e o handoff adicional pode ser necessário. A triagem verifica classificação, identidade curada e relações cadastradas, mas depende da referência e não certifica aplicação física. A validação humana das saídas A/B é a etapa que permitirá julgar se cada mudança foi benéfica, neutra ou prejudicial.')
    p('O motivo repeated_question interrompe a simulação quando o par (pending_slot, resposta incremental gerada pelo simulador) já apareceu no mesmo caso. Não compara semanticamente todas as perguntas do assistente e pode refletir uma referência inadequada ou uma resposta insuficiente que voltou a ser usada. Portanto, o contador não é uma taxa confirmada de perguntas desnecessárias. A ficha humana avalia repetição, necessidade da pergunta e preservação dos fatos no contexto completo.')
    heading('7 Latência e saídas brutas')
    table(['Repetição','Média por turno D em s','Média por turno H em s','P95 por turno D em s','P95 por turno H em s','Média pareada H menos D por caso em s'],[
        [r,num(data['categories'][str(r)]['D']['turn_latency']['mean_s']),num(data['categories'][str(r)]['H']['turn_latency']['mean_s']),
         num(data['categories'][str(r)]['D']['turn_latency']['p95_s']),num(data['categories'][str(r)]['H']['turn_latency']['p95_s']),
         num(result['paired_categories'][str(r)]['paired_case_latency_difference']['mean_s'])] for r in [1,2,3]])
    table(['Repetição','Chamadas H','JSON bruto completo H','Saídas cortadas H','Fallback de saída no backend H'],[
        [r,data['categories'][str(r)]['H']['llm_calls'],data['categories'][str(r)]['H']['llm_raw_json_complete'],
         data['categories'][str(r)]['H']['llm_cut_outputs'],data['categories'][str(r)]['H']['backend_fallback_turns']] for r in [1,2,3]])
    p('JSON bruto completo significa que o conteúdo pôde ser analisado sintaticamente por json.loads. Esse contador não certifica todos os campos do contrato, ausência de slots extras ou correção comercial. O backend mantém sua validação/coerção e registra separadamente o uso de fallback. Saída cortada é identificada pelo motivo length ou pelo limite de tokens atingido junto com JSON não analisável; os conteúdos originais estão preservados para conferência.')
    p('Tempos são wall clock do use case, com banco e inferência locais isolados, excluindo a inspeção cadastral independente. Não incluem transporte do WhatsApp, gateway ou túnel SSH. Média, mediana e P95 completos estão em summary.json; o P95 usa interpolação linear. A latência por caso e por turno são métricas diferentes, especialmente quando as configurações fazem quantidades diferentes de perguntas.')
    p('O relógio para quando o fluxo automatizado termina ou encaminha o caso. O trabalho e o tempo de atendimento humano após um handoff não foram medidos. Portanto, um encaminhamento rápido de D não equivale a uma resolução mais rápida para o cliente, e os tempos não permitem calcular isoladamente a economia total de operação ou o custo de substituição do atendente. A utilidade da autonomia adicional depende também de qualidade, risco e custo humano.')
    p('As repetições do mesmo caso foram blocadas, e o cache normal de prefixo pode reduzir o custo de prefill nas seguintes. Por isso, cada repetição é mostrada separadamente. A máquina também executa outros serviços, com limites de CPU aplicados ao estudo. Estes números não são um benchmark de carga, uma estimativa de capacidade na VPS nem uma comparação direta com o experimento BF16 de 19/10. Três repetições descrevem estabilidade, sem garantir independência estatística ou inferência sobre clientes futuros.')
    if recovery:
        interruption=read(ROOT/'interruption_analysis.json');assert interruption['complete']
        table(['Repetição','Pares totais','Pares no mesmo segmento','Diferença média H menos D por caso, todos (s)','Diferença sem pares entre segmentos (s)'],[
            [r,interruption['latency_sensitivity'][str(r)]['all_pairs'],
             interruption['latency_sensitivity'][str(r)]['same_segment_pairs'],
             num(interruption['latency_sensitivity'][str(r)]['mean_paired_case_difference_s_all']),
             num(interruption['latency_sensitivity'][str(r)]['mean_paired_case_difference_s_without_cross_segment_pairs'])] for r in [1,2,3]])
        p('Esta sensibilidade não altera a comparação principal nem remove resultados de qualidade. Apenas apresenta a latência com e sem os pares cuja execução D/H atravessou a interrupção: '+str([(p['case_id'],p['repetition']) for p in interruption['cross_segment_category_pairs']])+'. Os demais agregados por segmento são descritivos, pois contêm casos diferentes e não constituem um experimento causal antes/depois do reinício.')
    heading('8 Estabilidade e independência')
    table(['Conjunto','Casos com conversa diferente entre as três repetições em D','Casos com conversa diferente entre as três repetições em H'],[
        [suite,len(result['stability'][suite]['D']['changed_conversation_cases']),len(result['stability'][suite]['H']['changed_conversation_cases'])] for suite in ['categories','structural','golden_flow']])
    p('A assinatura compara mensagem do cliente, texto de resposta, critérios, itens e estado, sem usar tempos ou identificadores aleatórios. Estabilidade não significa correção: um erro determinístico pode se repetir nas três rodadas. O arquivo paired_category_results.json preserva as mudanças por caso, e os identificadores de variação ficam em summary.json.')
    overlap=audit['exact_initial_message_overlap']
    table(['Conjunto','Coincidência exata da mensagem inicial com treino','Interpretação'],[
        ['Categorias',len(overlap['categories']['train']),'Não foi encontrada coincidência exata; paráfrases, padrões e conhecimento prévio continuam possíveis'],
        ['Golden',len(overlap['golden_flow']['train']),'Mostrar também o subconjunto de 21 sem coincidência exata'],
        ['Estrutural',len(overlap['structural']['train']),'Conjunto de regressão conhecido no desenvolvimento; não é teste retido independente']])
    table(['Repetição','Golden sem coincidência D','Golden sem coincidência H'],[
        [r,str(result['golden_without_exact_overlap'][str(r)]['D']['passed'])+'/21',str(result['golden_without_exact_overlap'][str(r)]['H']['passed'])+'/21'] for r in [1,2,3]])
    p('A auditoria adicional não encontrou payloads completos idênticos entre os splits exportados de treino, validação e teste. Há mensagens curtas em comum entre splits, o que isoladamente não prova compartilhamento da conversa. Os metadados exportados não preservam conversation_id original; portanto, não é possível certificar retrospectivamente o isolamento por conversa. O modelo usado aqui é o base, não o adapter treinado nesses dados, mas os conjuntos também orientaram o desenvolvimento das regras. Um teste prospectivo independente exige novos pedidos e gabaritos congelados antes de executar ou ajustar o sistema.')
    heading('9 Auditoria das referências')
    table(['Verificação automática','Resultado'],[
        ['Casos',audit['total_cases']],['Casos com referência',audit['with_reference']],
        ['Códigos distintos de referência',audit['distinct_reference_codes']],['Códigos encontrados no snapshot',audit['source_codes_found']],
        ['Mensagens iniciais normalizadas distintas',audit['unique_normalized_initial_messages']],
        ['Casos com pelo menos um sinal de revisão',sum(bool(c['flags']) for c in audit['cases'])]])
    table(['Sinal para investigação','Casos'],[[k,v] for k,v in audit['flags'].items()])
    p('Os sinais podem se sobrepor e não são rótulos de erro comercial confirmado. Alguns significam falta de referência ou uma família ambígua que deveria provocar esclarecimento. Outros indicam divergência de classificação, composição ou texto do pedido. A existência do código confirma apenas que o registro está na fonte; não demonstra que a referência deveria aparecer para aquela solicitação. Nenhum caso foi retirado da comparação principal por ter um desfecho desfavorável.')
    heading('10 O que pedir aos especialistas')
    p('Solicite duas avaliações independentes de profissionais com conhecimento de autopeças e aplicações veiculares. O autor pode realizar uma delas, mas é necessário outro avaliador. Cada pessoa registra seu identificador e experiência, interpreta a solicitação antes de abrir as saídas e exporta seu próprio JSON sem consultar o outro. Após as duas revisões, preserve os arquivos originais, calcule concordância e adjudique divergências em registro separado, preferencialmente com terceiro especialista.')
    p('O pacote para especialistas contém uma ficha HTML offline, instruções, 21 perguntas e um modelo para dez novos casos independentes. O lote inicial tem '+str(selection['priority_cases'])+' casos, cobrindo os '+str(selection['taxonomy_groups'])+' grupos e priorizando divergências e referências a revisar. Todos os 371 casos ficam disponíveis. Essa seleção é intencional para diagnóstico; sua taxa de adequação não deve ser generalizada como acurácia aleatória dos clientes.')
    table(['Antes de abrir as saídas','Ao julgar A e B'],[
        ['Identificar peça e composição corretas; distinguir kit, reparo, acessório e conjunto','Verificar preservação de identidade e aplicação, correções e negações'],
        ['Separar dados informados e informações indispensáveis ainda ausentes','Avaliar necessidade das perguntas, repetição e encaminhamento'],
        ['Conferir referência e códigos com fonte, data e mesma aplicação','Julgar Top-1, existência de compatível no Top-3 e códigos individualmente'],
        ['Indicar se é possível pesquisar, se é preciso perguntar ou encaminhar','Classificar ausência: adequada, falso negativo com prova ou indeterminada'],
        ['Registrar evidência e sua suficiência, sem inventar lacunas','Avaliar adequação final, risco e preferência entre as saídas']])
    p('Para confirmar falso negativo, o avaliador precisa citar um candidato cuja mesma aplicação atenda aos critérios do pedido. Ausência no recorte do dossiê, produto da mesma categoria ou preferência do vendedor não bastam. Caso consulte um ERP mais recente, deve registrar data e eventual mudança desde o snapshot de 19/10/2026. Quando não conseguir verificar uma família, deve responder indeterminado; falta de evidência não vira erro automaticamente.')
    p('As letras A e B alternam por caso e não incluem nome de modelo, trace, latência ou score automático. O texto das respostas ainda pode permitir inferências sobre o comportamento, portanto isso é mascaramento de condição, não garantia de cegamento perfeito. A interpretação inicial é registrada antes de abrir as saídas; edições posteriores ficam marcadas. O formulário passou por verificação de sintaxe e testes de fluxo em DOM simulado; não havia navegador de automação disponível para uma inspeção visual nesta sessão.')
    heading('11 Como incorporar as respostas humanas')
    p('Envie apenas pacote_para_especialistas.zip aos revisores. Mantenha analyst_key.json e o relatório técnico com o responsável pela análise até concluir as revisões. A ficha não envia dados para nenhum servidor. Exporte os JSONs a cada sessão, pois o armazenamento do navegador é apenas auxiliar. Revisão, adjudicação e fonte de evidência precisam ficar versionadas separadamente, sem promover automaticamente os exemplos para treino.')
    p('O script analysis/analyze_human_reviews.py aceita os arquivos exportados e a chave privada, verifica study_id e identificadores distintos, apresenta contagens por avaliador, concordância e Cohen kappa, além da lista de divergências. Ele não escolhe silenciosamente um gabarito nem chama um julgamento individual de acurácia adjudicada. Casos indeterminados e edições de interpretação após ver as respostas precisam permanecer identificados nos denominadores.')
    p('As contagens estritas de ranking positivo usam o mesmo subconjunto pareado em D e H: pedido inicial coerente e já pesquisável, evidência prévia suficiente, pelo menos um código confirmado, sem edição posterior da referência e com Top-1/Top-3 determinados nas duas saídas. Esse recorte não representa a taxa de acerto de todos os atendimentos; pedidos inicialmente incompletos ficam fora dele. Seus julgamentos brutos continuam disponíveis nas contagens e formulários individuais. A concordância usa os dois primeiros arquivos de avaliadores informados, identificados na saída; a independência real e a experiência devem ser verificadas pelo autor.')
    p('Para fortalecer a independência futura, peça dez pedidos reais anonimizados ainda não usados nas baterias, com contexto, respostas de complementação, ação correta e evidência de produtos compatíveis ou de ausência. Congele os rótulos antes de rodar o sistema e mantenha todos os turnos de uma conversa no mesmo grupo. Esse material depende do especialista e permanece em branco no modelo entregue.')
    heading('12 Conclusão e pendências reais')
    p('A execução técnica isola a presença da inferência residual em uma arquitetura comum e quantifica seus efeitos observáveis. A rodada consolidada oferece uma versão identificada, três repetições e rastreabilidade dos casos; os controles de fonte, código, sobreposição e estabilidade ficaram documentados. Isso fortalece os pontos de ablação e consolidação que estavam pendentes.')
    p('Ainda não existe, nesta entrega, uma nova taxa de precisão comercial validada por dois especialistas. Ela não pode ser produzida apenas pelo agente ou pela consulta ao ERP, pois o próprio cadastro e as referências podem estar errados. A ficha e as perguntas são a parte que o autor deve solicitar aos profissionais. Após receber as respostas, será possível julgar se a maior autonomia da LLM compensou seus custos e riscos nos casos residuais, com denominadores e discordâncias explícitos.')
    p('A versão congelada também preserva falhas conhecidas, inclusive a governança de motor textual dentro da desambiguação de resultados relatada no Logus. Não houve correção de produção durante a medição. Os 604 testes aprovados não eliminam essas lacunas nem substituem a avaliação comercial. Aceite do canal e resultados da VPS continuam separados deste ensaio local em CPU.')
    heading('13 Arquivos e reprodução')
    table(['Arquivo ou pasta','Finalidade'],[
        ['relatorio_avaliacao_final.html e .md','Este documento, em leitura no navegador e versão editável'],
        ['leitor_conversas.html','Consulta offline de todos os casos, com filtros, comparação D/H, três repetições e links para JSONs completos'],
        ['checagens_e_falhas.md','Inventário de todas as expectativas estruturais/golden reprovadas e erros técnicos, com links para os registros'],
        ['pacote_para_especialistas.zip','Único pacote a encaminhar aos avaliadores; não contém a chave D/H'],
        ['para_especialistas/ficha_revisao_comercial.html','Ficha offline com pedidos, dossiê, saídas A/B e exportação das respostas'],
        ['para_especialistas/PERGUNTAS_PARA_O_ESPECIALISTA.md','As perguntas prontas para solicitar aos profissionais'],
        ['para_especialistas/modelo_novos_casos_independentes.json','Dez fichas em branco para pedidos prospectivos'],
        ['tecnico/protocol.json e freeze_manifest_v2.json','Protocolo e hashes antes da execução oficial'],
        ['tecnico/summary.json e paired_category_results.json','Métricas consolidadas e diferenças pareadas por caso'],
        ['tecnico/runs/rep_1, rep_2, rep_3','Respostas, estado, buscas, saídas brutas, tempos e erros de cada caso'],
        ['tecnico/runtime_logs','Logs dos serviços isolados, com pilotos/reaquecimentos e recuperação; não equivalem apenas às chamadas oficiais'],
        ['tecnico/input_audit.json e independence_audit_extended.json','Auditoria de referências, duplicação e sobreposição'],
        ['tecnico/recovery_20261027.json e interruption_analysis.json','Interrupção, retomada e sensibilidade da latência; reaquecimento excluído em recovery_warmup_20261027.json'],
        ['tecnico/agent_tests.xml e gateway_tests.xml','Resultados dos controles automatizados'],
        ['tecnico/analyst_key.json','Chave das configurações por caso; não entregar antes da revisão cega'],
        ['tecnico/analysis e tecnico/harness','Consolidadores, leitura dos formulários e scripts de execução'],
        ['tecnico/inputs e tecnico/frozen','Entradas, snapshot e código congelados para reprodução']])
    p('A reprodução exige ambiente Docker, PostgreSQL, Ollama e os pesos com o digest registrado. Os pesos não foram duplicados no pacote. Use rede e banco exclusivos, nunca restaure o dump sobre o serviço ativo, preserve as entradas e gere um novo diretório de saídas. Uma nova máquina ou mudança de contexto/quantização constitui outra condição de desempenho. Instruções operacionais e limites estão em tecnico/REPRODUCAO.md.')

    title='Avaliação final do projeto e protocolo de revisão comercial'
    md=['# '+title,'','Estudo executado em 26 de outubro de 2026',''];body=[]
    for kind,value in sections:
        if kind=='p':md.extend([value,'']);body.append('<p>'+html.escape(value)+'</p>')
        elif kind=='h2':md.extend(['## '+value,'']);body.append('<h2>'+html.escape(value)+'</h2>')
        else:
            heads,rows=value;md.extend(['| '+' | '.join(heads)+' |','| '+' | '.join('---' for _ in heads)+' |'])
            md.extend('| '+' | '.join(str(v).replace('|',' / ') for v in row)+' |' for row in rows);md.append('')
            body.append('<table><thead><tr>'+''.join('<th>'+html.escape(str(h))+'</th>' for h in heads)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table>')
    css='''body{margin:0;background:#eef1f3;color:#161616;font:17px/1.55 Georgia,serif}main{max-width:1020px;margin:30px auto;background:white;padding:48px 54px}h1{font-size:31px;line-height:1.2;color:#000}h2{font-size:23px;margin:36px 0 13px;color:#000;break-after:avoid}table{width:100%;border-collapse:collapse;font:13px/1.45 Arial,sans-serif;margin:18px 0 25px;table-layout:fixed}td,th{padding:10px;border:1px solid #d9d9d9;overflow-wrap:anywhere;text-align:left;vertical-align:middle}th{background:#e6edf3;color:#000}tr:nth-child(even){background:#f6f8fa}thead{display:table-header-group}tr{break-inside:avoid}nav{font:15px Arial,sans-serif}a{color:#174d70;margin-right:18px}.meta{font:14px Arial,sans-serif;color:#52606c}@media print{@page{size:A4;margin:18mm}body{background:white;font-size:11pt}main{margin:0;padding:0}nav{display:none}table{font-size:9pt}h1{font-size:25px}h2{font-size:18px}}@media(max-width:720px){main{margin:0;padding:20px}table{font-size:11px}td,th{padding:6px}}'''
    write(OUT/'relatorio_avaliacao_final.md','\n'.join(md))
    write(OUT/'relatorio_avaliacao_final.html','<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>'+css+'</style></head><body><main><h1>'+title+'</h1><p class="meta">Estudo executado em 26 de outubro de 2026</p><nav><a href="para_especialistas/ficha_revisao_comercial.html">Ficha para revisão</a><a href="para_especialistas/PERGUNTAS_PARA_O_ESPECIALISTA.md">Perguntas</a><a href="relatorio_avaliacao_final.md">Versão editável</a></nav>'+''.join(body)+'</main></body></html>')
    report=OUT/'relatorio_avaliacao_final.html'
    report.write_text(report.read_text(encoding='utf-8').replace('<nav>','<nav><a href="leitor_conversas.html">Consultar casos</a>'),encoding='utf-8')
    if recovery:
        replacements={
            'Estudo executado em 26 de outubro de 2026':'Estudo iniciado em 26/10/2026, com retomada registrada em 27/10/2026',
            'em 26 de outubro de 2026: comparação':'entre 26 e 27/10/2026: comparação',
            'Os serviços de atendimento ativos não foram atualizados ou reiniciados por esta avaliação.':'As imagens dos serviços de atendimento foram preservadas. O início do Docker Desktop na retomada provocou o reinício automático dos serviços; os checkpoints registram essa mudança operacional.',
            'sem reinício dos serviços ativos':'com reinício automático dos serviços pelo Docker Desktop na retomada, documentado separadamente',
            'Conferência de identidade e início registrada antes e depois, em active_services_before.txt e active_services_after.txt':'Imagens preservadas; início do motor e reinícios automáticos na retomada registrados em recovery_20261027.json e services_after_engine_restart.txt; conferência final em active_services_after.txt'
        }
        for artifact in [OUT/'relatorio_avaliacao_final.md',report]:
            value=artifact.read_text(encoding='utf-8')
            for old,new in replacements.items(): value=value.replace(old,new)
            artifact.write_text(value,encoding='utf-8')
    print('Final report authored',OUT)

if __name__=='__main__':main()
