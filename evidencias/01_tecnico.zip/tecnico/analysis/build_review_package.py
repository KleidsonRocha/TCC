import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import random
import re
import unicodedata
import zipfile

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parents[2]
OUT=ROOT.parent if ROOT.name=='tecnico' else REPO/'.tmp/Documents/avaliacao_final_projeto_20261026'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',str(s or '').casefold()) if not unicodedata.combining(c))
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def main(qa=False):
    if not qa and (ROOT/'review_package_manifest.json').exists():
        raise RuntimeError('Reviewer package already sealed. Preserve it; use a new study directory/version instead of overwriting.')
    cases=read(ROOT/'inputs/cases_371.json');audit={c['id']:c for c in read(ROOT/'input_audit.json')['cases']}
    paired={};available=[]
    for c in cases:
        ds=ROOT/'runs/rep_1/categories/D'/(c['id']+'.json');hs=ROOT/'runs/rep_1/categories/H'/(c['id']+'.json')
        if ds.exists() and hs.exists():paired[c['id']]={'D':read(ds),'H':read(hs)};available.append(c)
    if not qa:assert len(available)==371
    if qa:available=available[:3]
    source=read(ROOT/('review_source_dossier.json' if (ROOT/'review_source_dossier.json').exists() else 'reference_source_details.json'))
    by_code=defaultdict(list);by_item=defaultdict(list)
    for p in source['products']:by_code[str(p['cd_item'])].append(p)
    for a in source['applications']:by_item[a['id_item']].append(a)
    def signature(r):return [(t['user'],t['assistant']) for t in r['turns']]
    def priority_score(c):
        pair=paired[c['id']];d,h=pair['D'],pair['H'];flags=audit[c['id']]['flags'];ref=c.get('reference') or {}
        return (int(signature(d)!=signature(h)),int(bool(flags)),int(ref.get('cd_item') in {'UNI-21985','E-10524','LT70206','702666','KT-30305','SK-813','KJH0309','7130071100'}),hashlib.sha256(c['id'].encode()).hexdigest())
    priority=set();groups=defaultdict(list)
    for c in available:groups[c['group_code']].append(c)
    # First ensure taxonomy representation, then prioritize discordance and risks.
    for group,rows in groups.items():priority.add(max(rows,key=priority_score)['id'])
    for c in sorted(available,key=priority_score,reverse=True):
        if len(priority)>=min(60,len(available)):break
        priority.add(c['id'])
    rng=random.Random(20261026);shuffled=sorted(available,key=lambda c:c['id']);rng.shuffle(shuffled)
    cards=[];mapping={}
    for index,c in enumerate(shuffled,1):
        cid=f'AV-{index:03d}';pair=paired[c['id']];swap=bool(rng.randrange(2));arms={'A':'H' if swap else 'D','B':'D' if swap else 'H'}
        mapping[cid]={'original_case_id':c['id'],'arms':arms,'group_code':c['group_code'],'priority':c['id'] in priority}
        def output(r):
            turns=[{'user':t['user'],'assistant':t['assistant']} for t in r['turns']]
            criteria=(r['turns'][-1].get('response',{}).get('conversation_state') or {}).get('criteria',{})
            return {'turns':turns,'criteria':criteria,'products':[{'code':i['item_id'],'title':i.get('title','')} for i in r.get('items',[])]}
        ref=c.get('reference') or {};codes={str(ref['cd_item'])} if ref.get('cd_item') else set()
        codes|={str(i['item_id']) for r in pair.values() for i in r.get('items',[])}
        model=norm((c.get('initial_facts') or {}).get('vehicle_model'))
        year=(c.get('initial_facts') or {}).get('vehicle_year')
        year=int(year) if year and str(year).isdigit() else None
        products=[]
        for code in sorted(codes):
            for p in by_code.get(code,[]):
                apps=by_item[p['id_item']]
                ordered=sorted(apps,key=lambda a:(norm(a.get('vehicle_model'))!=model,
                    bool(year and not (a.get('year_start') and a['year_start']<=year and (a.get('year_open_end') or a.get('year_end') and a['year_end']>=year))),a['application_id']))
                products.append({'code':code,'title':p['candidate_title'],'group':p['cd_grupo'],'subgroup':p['cd_subgrupo'],
                    'application_count':len(apps),'applications':ordered[:8]})
        cards.append({'id':cid,'priority':c['id'] in priority,'initial_message':c['initial_message'],
            'reference_product':{'code':ref.get('cd_item'),'title':ref.get('candidate_title'),'family':ref.get('part_family')} if ref else None,
            'source_products':products,'A':output(pair[arms['A']]),'B':output(pair[arms['B']])})
    studyid='QA-TCC-20261026' if qa else 'TCC-20261026'
    data={'study_id':studyid,'cases':cards,'date':'2026-10-26'}
    target=ROOT/'qa' if qa else OUT/'para_especialistas';target.mkdir(parents=True,exist_ok=True)
    template=(ROOT/'analysis/review_form_template.html').read_text(encoding='utf-8')
    embedded=json.dumps(data,ensure_ascii=False).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
    write(target/'ficha_revisao_comercial.html',template.replace('__STUDY_DATA__',embedded))
    write(ROOT/('qa/analyst_key.json' if qa else 'analyst_key.json'),json.dumps({'study_id':studyid,'cases':mapping},ensure_ascii=False,indent=2))
    if qa:
        print('QA form prepared',len(cards));return
    write(target/'INSTRUCOES.md','''# Instruções para a revisão comercial

O objetivo é julgar a adequação técnica de atendimentos de autopeças, não dar
uma nota à apresentação do TCC ou adivinhar qual configuração utiliza IA.

## Quem deve responder

Solicite duas revisões independentes de profissionais com experiência em
autopeças e aplicações veiculares. O autor pode realizar uma das revisões
se possuir experiência técnica pertinente, mas precisa haver pelo menos outra
pessoa qualificada. Informe também eventual vínculo com o projeto. Cada pessoa deve usar seu próprio
identificador e não consultar as respostas da outra antes de exportar seu JSON.
Se uma pessoa não domina uma família, marque indeterminado em vez de supor.

## Como usar

0. Antes de examinar as saídas A/B, separe os dez novos pedidos anonimizados
   do template a partir da experiência real, com gabarito e evidência prévios.
   Não copie nem parafraseie pedidos desta bateria. Preserve essa versão inicial;
   o autor deve conferir duplicação e congelar o conjunto antes de executar o agente.
1. Abra `ficha_revisao_comercial.html` no navegador; funciona sem internet.
2. Informe um identificador de avaliador e função/experiência, sem dados pessoais desnecessários.
3. Comece pelo lote recomendado de 60 casos. Ele cobre os 24 grupos e prioriza divergências e referências a revisar. É amostragem intencional, não amostra aleatória de clientes. Todos os 371 casos também estão disponíveis.
4. Antes de abrir A e B, interprete o pedido e confira a referência usando evidência de identidade e da mesma aplicação. Informe a próxima ação correta e os dados indispensáveis.
5. Registre essa interpretação para abrir as duas saídas. Elas são identificadas apenas como A e B, com letras alternadas por caso. Não há um sistema A único no conjunto inteiro.
6. Julgue cada saída separadamente. Distinga pergunta necessária, encaminhamento adequado, resultado vazio e erro de recuperação. Preço/estoque e encaixe físico não são inferidos.
7. Exporte o JSON ao final de cada sessão e guarde uma cópia. O armazenamento do navegador é auxiliar; o arquivo exportado é a entrega. Pode dividir a revisão em sessões de 10 a 15 casos.
8. Entregue o JSON ao autor. Não é necessário editar o código nem operar a VPS. Nenhum arquivo é enviado automaticamente.

## Evidência e casos difíceis

- A referência original da bateria pode estar incorreta. Não a transforme em gabarito só porque aparece na ficha.
- O dossiê mostra recortes do snapshot de 19/10/2026, incluindo até oito aplicações por produto. Uma lista parcial não comprova ausência de aplicação.
- Se consultar o ERP atual, informe data e origem e registre eventual mudança cadastral desde o snapshot. Divergência temporal deve ser separada de falha do agente.
- Para falso negativo confirmado, cite pelo menos um código e uma mesma aplicação compatível com os dados do pedido. Produto da mesma categoria não basta.
- Diferencie conjunto que contém a peça, kit de reparo, acessório e peça avulsa. Diferencie preferência de marca de compatibilidade.
- Não invente versão, motor, lado ou eixo. Verifique se o dado é de fato indispensável ou se as aplicações já permitem selecionar candidatos sem ele.
- Um encaminhamento humano pode ser correto. Uma lista com muitos produtos pode ser inadequada. HTTP 200 não é critério comercial.

## Depois das duas revisões

O autor deve preservar os dois arquivos originais, calcular concordância e
separar discordâncias. Um terceiro especialista ou uma reunião de adjudicação
deve produzir um registro separado com decisão e evidência. Não apagar o
desacordo original nem escolher silenciosamente a avaliação mais favorável.
Nenhuma resposta foi preenchida automaticamente neste pacote.
''')
    write(target/'PERGUNTAS_PARA_O_ESPECIALISTA.md','''# Perguntas para avaliar os atendimentos

Responda por caso e, nas perguntas sobre resultado, por saída A e B. Sempre
há a opção de não conseguir determinar; isso é diferente de erro confirmado.

## Antes de ver a resposta do sistema

1. O pedido é coerente, contraditório ou insuficiente para pesquisar?
2. Qual é a peça pedida? É peça avulsa, kit, reparo, acessório ou conjunto?
3. Quais dados de veículo e refinamentos foram realmente informados?
4. Quais informações ainda são indispensáveis e por quê?
5. A próxima ação correta é pesquisar, perguntar ou encaminhar?
6. O produto de referência da bateria representa a peça e a aplicação pedidas?
7. Quais códigos têm compatibilidade sustentada por evidência? Quais equivalentes são aceitáveis?
8. Pode confirmar ausência de candidato ou ainda faltam dados/consulta?
9. Qual fonte, data, código e aplicação sustentam o julgamento?
10. A evidência é suficiente, parcial ou insuficiente?

## Para cada atendimento A e B

11. A peça e os dados do veículo foram preservados, inclusive correções e negações?
12. As perguntas eram necessárias e vinculadas à aplicação correta?
13. Houve pergunta repetida ou perda de um dado já informado?
14. O encaminhamento humano, ou sua ausência, foi adequado?
15. O primeiro candidato é tecnicamente compatível com o pedido?
16. Existe ao menos um candidato compatível entre os três primeiros?
17. Se não houve resultado, a ausência é correta, um falso negativo comprovado ou indeterminada?
18. Se existe erro, ele está na identidade, composição, aplicação, filtro, cadastro, pergunta ou ordenação? Cite evidência.
19. A condução final foi adequada, parcial, inadequada ou indeterminada?
20. Qual é o risco de seguir a resposta sem revisão?

## Comparação

21. Qual saída conduziu melhor o caso: A, B, empate, nenhuma ou indeterminado? Por quê?

## Para criar um teste comercial independente novo

Peça ao profissional dez pedidos reais anonimizados que não estejam nas
baterias anteriores. Para cada pedido, solicite a frase original, o contexto
necessário, as respostas de complementação, a ação correta e a evidência dos
códigos compatíveis ou da ausência. Inclua consultas completas, ambíguas,
negação/correção, kit versus peça, dado desconhecido e ausência confirmada.
Congele esses gabaritos antes de executar o agente; não ajuste o pedido para
fazer o sistema acertar. Evite nomes, telefone, placa ou outros dados de clientes.
Esse novo conjunto ainda depende do especialista e não foi inventado pelo agente.
''')
    write(target/'modelo_novos_casos_independentes.json',json.dumps({'schema_version':'1.0','status':'A preencher por especialista antes de executar o sistema',
        'cases':[{'id':f'NOVO-{i:02d}','pedido_anonimizado':'','contexto':'','respostas_incrementais':[],
                  'familia_correta':'','acao_esperada':'','dados_indispensaveis':[],
                  'codigos_compativeis':[],'ausencia_confirmada':None,'evidencia':'','avaliador_id':''} for i in range(1,11)]},ensure_ascii=False,indent=2))
    write(ROOT/'review_selection.json',json.dumps({'all_cases':len(cards),'priority_cases':len(priority),'taxonomy_groups':len(groups),
        'method':'One case per group prioritized by discordance/reference flags; remaining slots by the same priority ranking, deterministic tie break',
        'not_random_customer_sample':True,'cards':[{'id':c['id'],'priority':c['priority']} for c in cards]},ensure_ascii=False,indent=2))
    archive=OUT/'pacote_para_especialistas.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(target.rglob('*')):
            if p.is_file():z.write(p,str(p.relative_to(OUT)))
    print('Reviewer package',len(cards),'cases;',len(priority),'priority;',archive.stat().st_size,'bytes')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--qa',action='store_true');main(p.parse_args().qa)
