"""List every failed registered check; never reinterpret it as commercial truth."""
from collections import Counter,defaultdict
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parents[2]/'.tmp/Documents/avaliacao_final_projeto_20261026'
def main():
    paths=list((ROOT/'runs').glob('rep_*/*/*/*.json'));assert len(paths)==3408
    structural=[];golden=[];technical=[]
    for path in sorted(paths):
        r=json.loads(path.read_text(encoding='utf-8'));base={k:r[k] for k in ['id','suite','arm','repetition']}
        base['raw_file']='tecnico/'+str(path.relative_to(ROOT)).replace('\\','/')
        for t in r['turns']:
            if t['status']>=500:technical.append({**base,'turn':t.get('turn'),'user':t['user'],'status':t['status']})
            if t.get('expectation_failures'):
                structural.append({**base,'turn':t['turn'],'user':t['user'],'assistant':t['assistant'],
                    'expected':t.get('expected'),'failures':t['expectation_failures'],'status':t['status']})
        if r['suite']=='golden_flow' and not r['original_expected_field_pass']:
            golden.append({**base,'message':r['input']['message.text'],'expected':r['input']['expected'],
                'evaluation':r.get('evaluation'),'presearch_values':r['turns'][0].get('presearch_values')})
    data={'structural_failed_turn_records':structural,'golden_failed_case_records':golden,
          'technical_error_turn_records':technical,
          'warning':'These are registered check failures, not adjudicated commercial mistakes; D intentionally hands off at residual inference boundary.'}
    (ROOT/'failures_and_controls.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# Checagens reprovadas e erros técnicos','',
        'Inventário completo das expectativas reprovadas, preservando as três repetições. '
        'Uma reprovação estrutural pode representar uma diferença intencional da política D. '
        'Ela não é automaticamente erro comercial. O golden compara campos esperados parciais.','']
    for title,rows in [('Estrutural',structural),('Golden no fluxo completo',golden),('Erros técnicos',technical)]:
        lines+=['## '+title,'',f'{len(rows)} registros nesta seção.','']
        grouped=defaultdict(list)
        for row in rows:grouped[row['id'],row['arm'],row.get('turn')].append(row)
        for (cid,arm,turn),rs in grouped.items():
            lines += [f'### {cid} — {arm}'+(f' — turno {turn}' if turn else ''),'',
                'Repetições: '+', '.join(str(r['repetition']) for r in rs)+'.','']
            for row in rs:
                details=row.get('failures',row.get('evaluation',{'status':row.get('status')}))
                lines += [f"- Repetição {row['repetition']}: {json.dumps(details,ensure_ascii=False)}",f"  [JSON completo]({row['raw_file']})"]
            lines.append('')
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'checagens_e_falhas.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps({'structural_failed_turn_records':len(structural),'golden_failed_case_records':len(golden),
        'technical_error_turn_records':len(technical)},ensure_ascii=False))
if __name__=='__main__':main()
