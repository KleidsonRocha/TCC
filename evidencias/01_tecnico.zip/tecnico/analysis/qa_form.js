// Logic QA in an isolated DOM stub. These answers are test fixtures, never reviews.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const path=require('path');const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'qa/ficha_revisao_comercial.html'),'utf8');
const data=html.match(/<script id="studyData" type="application\/json">([\s\S]*?)<\/script>/)[1];
const script=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
new vm.Script(script);
const storage=new Map(),checks=[];
function environment(){
 const elements=new Map(),alerts=[],downloads=[],fields=[];
 class Element{
  constructor(id){this.id=id;this.value='';this.dataset={};this.events={};this.files=[];this.textContent='';}
  addEventListener(name,fn){this.events[name]=fn;}
  click(){if(this.onclick)return this.onclick();if(this.download)downloads.push(this.download);}
  set innerHTML(value){this._html=value;if(this.id==='content'){
    fields.length=0;
    for(const match of value.matchAll(/<(select|textarea)\b([^>]*)>([\s\S]*?)<\/\1>/g)){
      const attrs=match[2],get=n=>(attrs.match(new RegExp(n+'="([^"]*)"'))||[])[1];
      const id=get('id');if(!id)continue;const el=new Element(id);el.dataset={group:get('data-group'),name:get('data-name')};
      if(match[1]==='textarea')el.value=match[3];else el.value=(match[3].match(/<option value="([^"]*)" selected/)||[])[1]||'';
      elements.set(id,el);if(el.dataset.group)fields.push(el);
    }
    for(const name of ['lock','unlock']){if(value.includes('id="'+name+'"'))elements.set(name,new Element(name));else elements.delete(name);}
   }}
  get innerHTML(){return this._html||'';}
 }
 const document={getElementById(id){return elements.get(id)||null;},
  querySelectorAll(){return fields;},createElement(){return new Element('anchor');}};
 for(const id of ['reviewer','experience','export','import','file','saveStatus','scope','caseSelect','previous','next','progress','content','studyData'])elements.set(id,new Element(id));
 elements.get('studyData').textContent=data;elements.get('scope').value='priority';
 const context=vm.createContext({document,console,Date,JSON,String,Blob:class{constructor(parts){this.parts=parts;}},
  URL:{createObjectURL(blob){context.exportedBlob=blob;return 'blob:qa';},revokeObjectURL(){}},setTimeout:fn=>fn(),
  localStorage:{setItem:(k,v)=>storage.set(k,v),getItem:k=>storage.get(k)||null},
  alert:x=>alerts.push(x),confirm:()=>true,window:{scrollTo(){}}});
 vm.runInContext(script,context);
 return {context,elements,alerts,downloads,document,read:s=>vm.runInContext(s,context)};
}
async function main(){
 const e=environment();assert(e.elements.get('content').innerHTML.includes('Preencha seu identificador'));
 checks.push('No response entry before reviewer identity');
 const testDossier="({reference_product:{code:'QA-REF',title:'reference'},source_products:[{code:'QA-REF',title:'reference',applications:[]},{code:'QA-RETURNED',title:'candidate',applications:[]}]})";
 assert(!e.read('dossier('+testDossier+',false)').includes('QA-RETURNED'));
 assert(e.read('dossier('+testDossier+',true)').includes('QA-RETURNED'));
 checks.push('Returned candidate dossier hidden until initial reference judgement is locked');
 e.elements.get('reviewer').value='QA_ONLY';e.elements.get('reviewer').onchange();
 assert(!e.read('current().reference_locked_at'));assert(!e.elements.get('content').innerHTML.includes('<h2>Saída A</h2>'));
 assert.equal(Object.keys(e.read('current().reference')).length,0);checks.push('No prefilled human labels; outputs initially hidden');
 e.elements.get('lock').click();assert(e.alerts.length===1);checks.push('Reference required before output access');
 for(const [name,value] of [['coherence','unclear'],['correct_action','unknown'],['evidence','QA fixture only, not a human assessment']]){
  const el=e.elements.get('reference-'+name);el.value=value;el.events.change();
 }
 e.elements.get('lock').click();assert(e.read('!!current().reference_locked_at'));
 assert(e.elements.get('content').innerHTML.includes('<h2>Saída A</h2>'));checks.push('Reference lock exposes A and B');
 for(const group of ['A','B']){const el=e.elements.get(group+'-overall');el.value='unknown';el.events.change();}
 assert(e.read('isComplete(selected)'));checks.push('Explicit unknown answers are accepted without inventing compatibility');
 e.elements.get('export').click();const exported=JSON.parse(e.context.exportedBlob.parts[0]);
 assert.equal(exported.study_id,'QA-TCC-20261026');assert.equal(exported.reviewer_id,'QA_ONLY');
 assert(!('arms' in exported));checks.push('Offline JSON export preserves study and reviewer without analyst key');
 const reload=environment();reload.elements.get('reviewer').value='QA_ONLY';reload.elements.get('reviewer').onchange();
 assert(reload.read('!!current().reference_locked_at'));checks.push('Reviewer-specific saved session restores');
 reload.elements.get('unlock').click();assert(reload.read('current().reference_edited_after_outputs'));
 checks.push('Editing reference after viewing outputs is marked');
 reload.elements.get('file').files=[{text:async()=>JSON.stringify({study_id:'WRONG',reviewer_id:'x',assessments:{}})}];
 await reload.elements.get('file').onchange();assert(reload.alerts.some(x=>x.includes('outro estudo')));checks.push('Import from another study rejected');
 fs.writeFileSync(path.join(root,'qa/form_logic_checks.json'),JSON.stringify({passed:true,checks,scope:'Static JS and DOM-stub flow checks, no live browser available; test data excluded from research'},null,2));
 console.log(JSON.stringify({passed:true,checks}));
}
main().catch(e=>{console.error(e);process.exitCode=1;});
