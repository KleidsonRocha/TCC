"""Offline reader for every measured conversation; no scoring or external requests."""
import html
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent if ROOT.name == 'tecnico' else ROOT.parents[2] / '.tmp/Documents/avaliacao_final_projeto_20261026'

def search_summary(search):
    value={k:search[k] for k in ['criteria','returned_ids','elapsed_s','elapsed_ms','error'] if k in search}
    value['products']=[{k:p.get(k) for k in ['item_id','title','score']} for p in search.get('products',[])]
    diagnostics=search.get('diagnostics') or {}
    value['diagnostics_summary']={k:v for k,v in diagnostics.items() if not isinstance(v,(list,dict))}
    value['diagnostic_list_counts']={k:len(v) for k,v in diagnostics.items() if isinstance(v,list)}
    return value

def main():
    summary = json.loads((ROOT / 'summary.json').read_text(encoding='utf-8'))
    assert summary['complete'] and summary['observed_case_records'] == 3408
    cases = {}
    for path in sorted((ROOT / 'runs').glob('rep_*/*/*/*.json')):
        row = json.loads(path.read_text(encoding='utf-8'))
        key = row['suite'] + '/' + row['id']
        card = cases.setdefault(key, {'id': row['id'], 'suite': row['suite'], 'reps': {}})
        turns = []
        for turn in row['turns']:
            response = turn.get('response') or {}
            turns.append({'user': turn.get('user', ''), 'assistant': turn.get('assistant', ''),
                'status': turn['status'], 'latency_s': turn['latency_s'],
                'llm_calls': len(turn['llm_calls']), 'searches': [search_summary(s) for s in turn.get('searches', [])],
                'presearch': turn.get('presearch_values', []),
                'actions': response.get('actions', []),
                'llm_call_times': [c['elapsed_s'] for c in turn['llm_calls']]})
        card['reps'].setdefault(str(row['repetition']), {})[row['arm']] = {
            'turns': turns, 'screening': row.get('screening'), 'stop_reason': row.get('stop_reason'),
            'items': row.get('items', []), 'raw_file': 'tecnico/' + str(path.relative_to(ROOT)).replace('\\', '/')}
    paired = json.loads((ROOT / 'paired_category_results.json').read_text(encoding='utf-8'))
    for row in paired:
        card = cases['categories/' + row['id']]
        card['initial_message'] = row['initial_message']
        card['comparisons'] = {str(r['repetition']): r for r in row['repetitions']}
    data = json.dumps(list(cases.values()), ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
    template = '''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Conversas da avaliação D/H</title><style>body{font:16px/1.5 Arial,sans-serif;color:#19232c;margin:0;background:#edf1f5}main{max-width:1250px;margin:auto;padding:24px}h1{color:#000}header,article{background:white;padding:22px;margin-bottom:18px;border-radius:8px}label{display:inline-block;margin:7px}select,input,button{font:inherit;padding:6px;max-width:95%}#case{width:100%}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.turn{border-top:1px solid #ccc;padding:12px 0}.user{font-weight:bold}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f4f6f8;padding:12px;font-size:13px}a{color:#174d70}.note{font-size:14px;color:#45515e}@media(max-width:760px){.grid{grid-template-columns:1fr}main{padding:10px}}</style>
<main><header><h1>Leitor das conversas e buscas</h1><p>D = caminhos determinísticos com encaminhamento residual. H = mesmos caminhos com inferência residual do modelo base. Triagem cadastral não é precisão comercial. Este leitor mostra as três repetições, incluindo falhas; não contém avaliações humanas.</p>
<p><a href="relatorio_avaliacao_final.html">Voltar ao relatório</a></p>
<p class="note">Este leitor resume buscas e produtos retornados. Os links dos JSONs completos preservam atributos, candidatos brutos, estado e auditoria integral.</p>
<label>Conjunto <select id="suite"><option value="categories">371 categorias</option><option value="structural">170 regressões estruturais</option><option value="golden_flow">27 golden no fluxo</option></select></label>
<label>Repetição <select id="rep"><option>1</option><option>2</option><option>3</option></select></label>
<label>Texto ou ID <input id="text" type="search" placeholder="Clio, FH 460, sub-..."></label>
<label><input id="diff" type="checkbox"> Só conversas diferentes D/H nas categorias</label>
<p class="note">O filtro de diferenças usa texto, critérios, itens e estado registrados pelo agregador, sem tempos/IDs aleatórios. Nos demais conjuntos esse filtro não se aplica. Turnos estruturais seguem replay fixo, mesmo após handoff.</p>
<p id="count"></p><select id="case" aria-label="Caso"></select></header><div id="content"></div></main>
<script id="data" type="application/json">__DATA__</script><script>
const cards=JSON.parse(document.getElementById('data').textContent),el=id=>document.getElementById(id);
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pretty=x=>'<pre>'+esc(JSON.stringify(x,null,2))+'</pre>';
function filter(){const s=el('suite').value,r=el('rep').value,q=el('text').value.toLocaleLowerCase();
 let visible=cards.filter(c=>c.suite===s&&(!q||(c.id+' '+(c.initial_message||'')+' '+JSON.stringify(c.reps[r])).toLocaleLowerCase().includes(q))&&(!el('diff').checked||s!=='categories'||!c.comparisons[r].same_conversation));
 const old=el('case').value;el('case').innerHTML=visible.map(c=>'<option value="'+esc(c.suite+'/'+c.id)+'">'+esc(c.id+' — '+(c.initial_message||c.reps[r].H.turns[0]?.user||''))+'</option>').join('');
 if(visible.some(c=>c.suite+'/'+c.id===old))el('case').value=old;el('count').textContent=visible.length+' casos neste filtro';show();}
function show(){const c=cards.find(c=>c.suite+'/'+c.id===el('case').value),r=el('rep').value;
 if(!c){el('content').innerHTML='<article>Nenhum caso neste filtro.</article>';return;}
 el('content').innerHTML='<div class="grid">'+['D','H'].map(arm=>{const v=c.reps[r][arm];return '<article><h2>'+arm+' — '+(arm==='D'?'Determinístico':'Híbrido')+'</h2><p>'+esc(v.screening)+' · '+esc(v.stop_reason||'')+'</p><p><a href="'+esc(v.raw_file)+'">JSON completo: estado, saídas brutas e auditoria</a></p>'+v.turns.map((t,i)=>'<section class="turn"><p class="user">'+(i+1)+'. Cliente: '+esc(t.user)+'</p><p>Agente: '+esc(t.assistant)+'</p><p class="note">Status '+t.status+' · '+t.latency_s.toFixed(2)+' s · '+t.llm_calls+' chamadas à LLM</p><details><summary>Critérios pré-busca</summary>'+pretty(t.presearch)+'</details><details><summary>Buscas e retornos</summary>'+pretty(t.searches)+'</details><details><summary>Ações e tempos da inferência</summary>'+pretty({actions:t.actions,llm_call_times_s:t.llm_call_times})+'</details></section>').join('')+'<details><summary>Itens apresentados neste caso</summary>'+pretty(v.items)+'</details></article>';}).join('')+'</div>';}
for(const id of ['suite','rep','text','diff'])el(id).addEventListener(id==='text'?'input':'change',filter);el('case').addEventListener('change',show);filter();
</script></html>'''
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'leitor_conversas.html').write_text(template.replace('__DATA__', data), encoding='utf-8')
    print('Offline case reader:', len(cases), 'IDs,', len(data), 'embedded bytes; 3408 records')

if __name__ == '__main__': main()
