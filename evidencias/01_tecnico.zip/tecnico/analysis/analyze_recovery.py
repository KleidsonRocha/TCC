"""Describe execution segments and latency sensitivity without changing primary results."""
import argparse
from collections import defaultdict
from datetime import datetime
import json
from pathlib import Path
import statistics

ROOT=Path(__file__).resolve().parents[1]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def main(partial=False):
    recovery=read(ROOT/'recovery_20261027.json')
    boundary=datetime.fromisoformat(recovery['resumed_at'])
    rows=[read(p) for p in (ROOT/'runs').glob('rep_*/*/*/*.json')]
    if not partial: assert len(rows)==3408 and (ROOT/'runs/completed.json').exists()
    index={};segments=defaultdict(lambda:{'case_records':0,'turns':0,'latency_sum_s':0.0,'llm_calls':0})
    for r in rows:
        segment='after_resumption' if datetime.fromisoformat(r['started_at'])>=boundary else 'before_interruption'
        index[r['suite'],r['id'],r['repetition'],r['arm']]=(r,segment)
        m=segments[segment+'/'+r['suite']+'/'+str(r['repetition'])+'/'+r['arm']]
        m['case_records']+=1;m['turns']+=len(r['turns'])
        m['latency_sum_s']+=sum(t['latency_s'] for t in r['turns'])
        m['llm_calls']+=sum(len(t['llm_calls']) for t in r['turns'])
    for m in segments.values():m['mean_turn_latency_s']=m['latency_sum_s']/m['turns'] if m['turns'] else None
    sensitivity={};cross=[]
    categories=read(ROOT/'inputs/cases_371.json')
    for rep in [1,2,3]:
        all_diffs=[];same_segment=[]
        for case in categories:
            dk=('categories',case['id'],rep,'D');hk=('categories',case['id'],rep,'H')
            if dk not in index or hk not in index:continue
            (d,ds),(h,hs)=index[dk],index[hk]
            diff=sum(t['latency_s'] for t in h['turns'])-sum(t['latency_s'] for t in d['turns'])
            all_diffs.append(diff)
            if ds==hs:same_segment.append(diff)
            else:cross.append({'suite':'categories','case_id':case['id'],'repetition':rep,
                'D_segment':ds,'H_segment':hs,'latency_difference_H_minus_D_s':diff})
        sensitivity[str(rep)]={'all_pairs':len(all_diffs),'same_segment_pairs':len(same_segment),
            'mean_paired_case_difference_s_all':statistics.mean(all_diffs) if all_diffs else None,
            'mean_paired_case_difference_s_without_cross_segment_pairs':statistics.mean(same_segment) if same_segment else None}
    result={'complete':not partial,'resumption_boundary_utc':recovery['resumed_at'],
        'segments':dict(segments),'cross_segment_category_pairs':cross,'latency_sensitivity':sensitivity,
        'primary_results_modified':False,
        'limitations':['Segments contain different cases; their unpaired means are descriptive, not a causal before/after comparison',
            'Warmup after restart is excluded; normal prefix cache state and host load may differ',
            'The interrupted incomplete attempt has no recovered result; it is recorded as external interruption, not silently counted as model success or failure']}
    (ROOT/'interruption_analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'complete':not partial,'records':len(rows),'cross_segment_pairs':cross},ensure_ascii=False))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--partial',action='store_true');main(p.parse_args().partial)
