"""Register completed technical evidence; leave commercial validation and known bugs pending."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];REPO=ROOT.parents[2];DOCS=REPO/'docker-agent/docs'
TITLE='Avaliacao Tecnica Consolidada Com E Sem LLM Em 27/10/2026'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def insert_section(path,section):
    text=path.read_bytes().decode('utf-8');eol='\r\n' if '\r\n' in text else '\n'
    if TITLE in text:raise ValueError('Evidence already registered; inspect before updating')
    index=text.find(eol+'## ')
    assert index>=0,path
    text=text[:index]+eol+section.replace('\n',eol).rstrip()+eol+text[index:]
    path.write_bytes(text.encode('utf-8'))
def main():
    result=read(ROOT/'summary.json');assert result['complete'] and result['observed_case_records']==3408
    assert read(ROOT/'verification.json')['complete']
    d=result['per_repetition']['categories']['1']['D'];h=result['per_repetition']['categories']['1']['H']
    pair=result['paired_categories']['1']
    common=f'''## {TITLE}

- Concluidas 3408 execucoes de caso: 371 conversas por categoria/subcategoria,
  170 cenarios estruturais (208 turnos fixos) e 27 golden no fluxo completo,
  nas configuracoes D/H e em tres repeticoes blocadas por caso. Codigo
  congelado no commit `52e4d74`, com hashes de 199 arquivos e fonte de
  52.798 produtos/1.779.443 aplicacoes. Execucao local em CPU, banco exclusivo
  somente leitura e Qwen2.5:7b Q4_K_M; sem novo treino ou uso do adapter.
- D conserva os caminhos deterministicos completos e encaminha ao humano
  apenas na fronteira residual de inferencia. H conserva o mesmo backend
  e usa a LLM nesse ponto. D e uma politica conservadora declarada, nao o
  melhor sistema deterministico concebivel. Inferencias efetivas em D: zero.
- Repeticao 1 nas categorias: H acionou a LLM em {h['residual_exposed_cases']}/371
  conversas ({h['llm_calls']} chamadas); {pair['identical_conversations']}/371
  conversas foram identicas entre D/H. Produtos apresentados em
  {d['items_presented_cases']}/371 (D) e {h['items_presented_cases']}/371 (H);
  handoffs em {d['handoff_cases']} (D) e {h['handoff_cases']} (H). Erros tecnicos:
  {d['technical_error_cases']} casos D e {h['technical_error_cases']} H.
  Recuperacao adicional e menor handoff nao certificam adequacao comercial.
- Controles: 604 testes do agente e 33 do gateway aprovados, sem skips;
  advertencia de depreciacao Starlette/AnyIO preservada. Aprovacoes e falhas
  da bateria real, saidas brutas, buscas, estado e tempos ficam no relatorio;
  expectativa estrutural e golden parcial nao equivalem a acerto comercial.
- Houve interrupcao externa entre 26 e 27/10. Ao continuar, o Docker Desktop
  estava desligado; seu inicio reiniciou automaticamente os servicos existentes,
  com as mesmas imagens. Preservados 1809 registros concluidos e retomados
  somente os incompletos, apos reconferir banco, hashes e modelo. Reaquecimento
  excluido e sensibilidade de latencia por segmento documentados. Nao declarar
  uma execucao continua ou desempenho equivalente ao da VPS.
- Relatorio HTML/Markdown, leitor offline de todos os casos, pacote tecnico,
  hashes e reproducao em `.tmp/Documents/avaliacao_final_projeto_20261026/`
  na raiz. Saidas originais em `.tmp/eval/final_validation_20261026/`, na raiz.
  Material local ignorado pelo Git; nao e requisito para um clone novo.
- Revisao comercial continua pendente: ficha cega com os 371 casos, lote
  inicial intencional de 60 cobrindo 24 grupos, 21 perguntas e template para
  dez pedidos prospectivos. Exigir dois profissionais qualificados, revisoes
  independentes e adjudicacao com evidencia. Nenhuma resposta humana foi
  preenchida pelo agente; nao ha nova taxa adjudicada de precisao comercial.
- Achado em `search_008`: o pedido informa `zetec rocam`, mas D/H conservam
  `engine` nulo e pedem a motorizacao; ZETEC ROCAM aparece entre as opcoes.
  Sem inferencia nessa resposta. Preservada a expectativa de busca reprovada;
  investigar extracao e distinguir identificacao insuficiente de dado ausente.
  Nao concluir automaticamente que a familia do motor basta para compatibilidade.
- Confirmada a divida `real_004_regression`: apos mudar para rolamentos e
  informar o ano, o criterio volta a polia nas duas condicoes, inclusive D.
  `disambiguation_002` reapresenta em H a lista curta explicitamente rejeitada.
  Paginar as duas opcoes restantes em `disambiguation_007` e um caso distinto.
  Expectativas antigas de batente generico e de lista de criterios no estado
  precisam reconciliacao; nao rotular todas as reprovacoes como erro da LLM.
'''
    insert_section(DOCS/'PROGRESS.md',common)
    history=f'''## {TITLE}

Executada ablacao local em CPU na copia congelada `52e4d74`: mesmos catalogo,
regras, estado e busca com/sem inferencia residual do Qwen2.5:7b Q4_K_M.
As tres repeticoes das 371 conversas, 170 cenarios e 27 golden produziram
3408 registros; os controles adicionais tiveram 604+33 testes aprovados.
O estudo mede comportamento operacional e estabilidade, sem inventar um
gabarito comercial. Resultados e limites em [PROGRESS.md](PROGRESS.md).

Na continuacao de 27/10, o Docker Desktop estava desligado. O reinicio do
motor restaurou automaticamente os servicos existentes com as mesmas imagens;
o estudo retomou apos 1809 registros completos, sem alterar entradas ou
parametros. Interrupcao, reaquecimento excluido, checkpoints e sensibilidade
de latencia ficaram documentados. Nao misturar estes tempos em CPU com o
experimento BF16/LoRA de 19/10 ou com o transporte no Omni/Convert.

Auditoria das referencias e sobreposicoes preservada; a ficha para dois
especialistas exige interpretacao inicial antes das saidas A/B e evidencia
de componente/aplicacao. Os 60 casos prioritarios sao amostra intencional,
nao estimativa populacional. Os 371 casos ficam acessiveis, com dez fichas
novas em branco para validacao prospectiva. Revisao humana, curadoria e
independencia de novas conversas continuam pendentes; nada foi promovido a
treino ou golden automaticamente. Relatorio e evidencias ficam locais em
`.tmp/Documents/avaliacao_final_projeto_20261026/`, na raiz, fora do Git.
'''
    insert_section(DOCS/'HISTORICO.md',history)
    path=DOCS/'DECISIONS.md';text=path.read_bytes().decode('utf-8');eol='\r\n' if '\r\n' in text else '\n'
    assert '## 50.' not in text
    decision='''
## 50. Isolar A Inferencia Residual E Preservar A Validacao Comercial Independente

Decisao (27/10/2026), na avaliacao solicitada pelo usuario:

- Comparar o mesmo backend e fonte congelados com/sem inferencia residual;
  declarar o handoff conservador da condicao D, sem simular erro de provedor
  ou fabricar JSON de modelo. Registrar chamadas efetivas, nao inferi-las
  pelos nomes de ferramentas. O modelo base do Ollama permanece ativo;
  esta avaliacao nao treina, importa ou promove o adapter de 19/10.
- Preservar entradas, versao, hashes, fonte, configuracao e todas as falhas.
  Repetir cada caso tres vezes, com ordem D/H contrabalancada, e descrever
  cache/CPU, unidade de analise e duplicacoes. Repeticao nao cria novos
  clientes independentes, e latencia ate handoff nao mede trabalho humano.
- Registrar interrupcoes e reaquecimentos excluidos. Na retomada de 27/10,
  o inicio do Docker Desktop reiniciou servicos automaticamente; as imagens
  foram preservadas. Separar segmentos e pares que atravessaram a pausa,
  sem ocultar a tentativa incompleta ou trocar o protocolo congelado.
- Diferenciar contrato estrutural, golden parcial, triagem cadastral e
  adequacao comercial. Nao chamar apresentacao de mais itens, ausencia de
  HTTP 500 ou concordancia com referencia nao curada de ganho de precisao.
- Solicitar duas revisoes qualificadas independentes, com interpretacao do
  pedido antes das saidas mascaradas A/B, origem/data/evidencia, opcoes
  indeterminadas e adjudicacao separada de discordancias. IDs distintos nao
  comprovam por si so a independencia real. A chave D/H fica com o autor.
- Manter os 371 casos originais e priorizar 60 por cobertura e risco, sem
  generalizar essa amostra intencional para clientes. Novos pedidos com
  gabarito previo e agrupamento por conversa devem fortalecer independencia;
  a ausencia de IDs originais impede certificar retrospectivamente os splits.
  Nao promover respostas da avaliacao para treino automaticamente.

Evidencias locais, pendencias humanas e resultados em [PROGRESS.md](PROGRESS.md).
O defeito conhecido de motor textual na desambiguacao do Logus permanece no
backlog; a medicao congelada nao representa correcao ou novo deploy.
'''
    path.write_bytes((text.rstrip()+eol+decision.replace('\n',eol)).encode('utf-8'))
    path=DOCS/'TODO.md';text=path.read_bytes().decode('utf-8');eol='\r\n' if '\r\n' in text else '\n'
    text=text.replace('Revisado em 19/10/2026.','Revisado em 27/10/2026.',1)
    marker='- [ ] Curar referencias e expectativas das auditorias de categoria de 14 e 19/10/2026.'
    assert marker in text
    pending='''- [ ] Concluir a revisao comercial independente da avaliacao de 26-27/10/2026.
  - Parte tecnica concluida: 3408 registros D/H, tres repeticoes e 604+33
    testes; resultados em PROGRESS.md. Enviar somente o pacote de especialistas
    a dois profissionais qualificados. Comecar pelos 60 casos prioritarios,
    com acesso aos 371, e preservar os dois JSONs originais e as discordancias.
  - Adjudicar com evidencia de mesma aplicacao; calcular medidas comerciais
    somente nos denominadores avaliaveis. Solicitar os dez novos pedidos
    anonimizados e congelar gabaritos antes de executar o sistema. Referencias
    historicas, gabaritos prospectivos e dados de treino continuam separados.
  - Revisar tambem as expectativas semanticas para respostas vagas apos uma
    lista: `disambiguation_005` passa nas checagens estruturais enquanto repete
    a apresentacao de quatro opcoes. Definir o comportamento desejado com
    evidencia, sem reclassificar retroativamente as expectativas desta rodada.

- [ ] Investigar reconhecimento de motor textual na mensagem inicial do EcoSport.
  - Caso congelado `search_008`: `coxim amort ecosport 2008 zetec rocam dianteiro`.
    Nas duas configuracoes, sem LLM, `engine` fica nulo e o agente pede novamente
    motorizacao, oferecendo ZETEC ROCAM entre as opcoes. Preservar a informacao
    textual e verificar a prova de modelo/ano; se faltar discriminacao, perguntar
    especificamente o que falta. Conferir aplicacao antes de aprovar a expectativa
    de busca direta e adicionar regressao com o catalogo efetivo.

- [ ] Impedir que o historico restaure a peca anterior ao responder o ano.
  - Divida confirmada em `real_004_regression`: polia do Focus -> rolamentos
    dianteiros -> `2013` volta para polia em D/H, inclusive sem inferencia.
    Priorizar o componente atual no estado quando a mensagem apenas complementa
    o ano; preservar itens distintos quando houver pedido adicional explicito.
- [ ] Governar rejeicao de produtos conforme o alcance da lista exibida.
  - `disambiguation_002`: depois de `nenhuma dessas`, H repete as tres opcoes.
    Revisar o caminho sem estado de desambiguacao, evitando nova busca igual.
    Diferenciar a pagina visivel de `disambiguation_007`, que exclui dez e
    mostra os dois candidatos restantes por politica deterministica atual.
  - Reconciliar expectativas antigas de batente ambiguo e `items_contains`
    (criterios no estado, nao produtos do ERP), sem enfraquecer identidade ou
    chamar ausencia de lista no estado de falso negativo comercial.
  - Alinhar o golden com as regras atuais de lado em correia de comando e de
    tipo de coxim. No pedido radiador Gol/bandeja Corsa, o primeiro retorno
    pre-busca diverge do estado final corretamente separado pelo use case;
    versionar o contrato/etapa medidos antes de outra comparacao de modelos.

'''
    text=text.replace(marker,pending.replace('\n',eol)+marker,1)
    battery='- [ ] Reexecutar bateria revisada e controles positivos/negativos no mesmo snapshot apos cada lote.'
    assert battery in text
    text=text.replace(battery,battery+eol+'  - A bateria original sinalizada foi reexecutada na ablacao congelada de 26-27/10; isso nao conclui a curadoria comercial nem substitui uma nova rodada com expectativas revisadas.',1)
    path.write_bytes(text.encode('utf-8'))
    print('Registered completed technical study in four project documents; human review and known bugs remain pending')
if __name__=='__main__':main()
