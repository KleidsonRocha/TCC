"""Read exported independent reviews; never fabricate missing judgements."""
import argparse
from collections import Counter,defaultdict
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def agreement(pairs):
    pairs=[(a,b) for a,b in pairs if a and b]
    if not pairs:return {'n':0,'agreement':None,'cohen_kappa':None}
    n=len(pairs);observed=sum(a==b for a,b in pairs)/n
    ca=Counter(a for a,b in pairs);cb=Counter(b for a,b in pairs)
    expected=sum(ca[k]*cb[k] for k in set(ca)|set(cb))/(n*n)
    return {'n':n,'agreement':observed,'cohen_kappa':(observed-expected)/(1-expected) if expected<1 else None,
        'note':'Unknown is an explicit category; unanswered fields are excluded. Kappa is undefined for no category variation.'}
def analyze(paths,key_override=None):
    key=key_override or read(ROOT/'analyst_key.json');reviews=[read(Path(p)) for p in paths]
    ids=[r.get('reviewer_id') for r in reviews]
    if len(ids)!=len(set(ids)) or not all(ids):raise ValueError('Distinct reviewer identifiers required; do not count two exports by the same person twice')
    if any(r.get('study_id')!=key['study_id'] for r in reviews):raise ValueError('Review belongs to a different study')
    per_reviewer={};disagreements=[]
    for r in reviews:
        stats={arm:{'overall':Counter(),'top1':Counter(),'top3':Counter(),'absence':Counter(),
            'source_sufficient_positive_rank_cases':0,'positive_top1_hits':0,'positive_top3_hits':0} for arm in ['D','H']}
        completed=0;edited=0
        for cid,a in r.get('assessments',{}).items():
            if cid not in key['cases']:continue
            ref=a.get('reference',{});edited+=bool(a.get('reference_edited_after_outputs'))
            complete=bool(a.get('reference_locked_at') and ref.get('coherence') and ref.get('correct_action') and ref.get('evidence')
                and a.get('A',{}).get('overall') and a.get('B',{}).get('overall'))
            completed+=complete
            if not complete:continue
            codes=ref.get('compatible_codes','').strip().casefold()
            positive=ref.get('coherence')=='coherent' and ref.get('correct_action')=='search' and ref.get('no_match_truth')=='exists' and ref.get('evidence_strength')=='sufficient' and bool(codes) and codes not in {'indeterminado','nao sei','não sei'} and not a.get('reference_edited_after_outputs')
            paired_rank_eligible=positive and all(a.get(label,{}).get('top1') in {'compatible','incompatible','no_items'} and a.get(label,{}).get('top3') in {'yes','no','no_items'} for label in ['A','B'])
            for blind,arm in key['cases'][cid]['arms'].items():
                judged=a.get(blind,{})
                for field in ['overall','top1','top3','absence']:
                    if judged.get(field):stats[arm][field][judged[field]]+=1
                if paired_rank_eligible:
                    stats[arm]['source_sufficient_positive_rank_cases']+=1
                    stats[arm]['positive_top1_hits']+=judged['top1']=='compatible'
                    stats[arm]['positive_top3_hits']+=judged['top3']=='yes'
        per_reviewer[r['reviewer_id']]={'completed_minimum_fields':completed,'reference_edited_after_outputs_cases':edited,
            'by_configuration':stats,'warning':'These are individual reviewer judgements. Do not label them adjudicated commercial accuracy. Positive ranking denominators include only coherent cases judged search-ready in the initial request, with sufficient pre-output evidence and known Top1/Top3 judgements for both arms. This strict subset excludes requests initially requiring follow-up; raw Top1/Top3 judgements across the remaining cases are reported separately.'}
    concordance={}
    if len(reviews)>=2:
        first,second=reviews[:2]
        shared=set(first.get('assessments',{}))&set(second.get('assessments',{}))&set(key['cases'])
        for field in ['coherence','correct_action','reference_valid']:
            concordance['reference_'+field]=agreement([(first['assessments'][cid].get('reference',{}).get(field),second['assessments'][cid].get('reference',{}).get(field)) for cid in shared])
        for arm in ['D','H']:
            pairs=[]
            for cid in sorted(shared):
                label=next(k for k,v in key['cases'][cid]['arms'].items() if v==arm)
                a=first['assessments'][cid].get(label,{}).get('overall');b=second['assessments'][cid].get(label,{}).get('overall')
                pairs.append((a,b))
                if a and b and a!=b:disagreements.append({'case_id':cid,'configuration':arm,'reviewer_1':first['reviewer_id'],'reviewer_2':second['reviewer_id'],'judgement_1':a,'judgement_2':b,'adjudicated_result':None,'adjudicator_id':'','evidence':''})
            concordance['overall_'+arm]=agreement(pairs)
    result={'reviewer_count':len(reviews),'two_distinct_reviewer_ids_present':len(reviews)>=2,
        'reviewer_independence_verified':False,
        'concordance_reviewer_ids':ids[:2] if len(ids)>=2 else [],
        'per_reviewer':per_reviewer,'concordance':concordance,'disagreements_to_adjudicate':disagreements,
        'adjudicated_commercial_accuracy':None,'limitations':['Identity and expertise are self-reported','Source evidence must be checked before final acceptance',
        'Purposive priority subset does not estimate random customer-population accuracy','Disagreements must be preserved and adjudicated separately']}
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('reviews',nargs='+');p.add_argument('--output',default=str(ROOT/'human_review_analysis.json'));a=p.parse_args()
    result=analyze(a.reviews);Path(a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Reviewer files analyzed:',result['reviewer_count'],'; adjudicated commercial accuracy remains pending')
