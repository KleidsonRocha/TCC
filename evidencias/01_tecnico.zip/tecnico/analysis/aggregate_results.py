"""Summarize the frozen ablation without promoting screening to human truth."""
import argparse
from collections import Counter,defaultdict
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import statistics

ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def percentile(values,q):
    if not values:return None
    x=sorted(values);pos=(len(x)-1)*q;a=int(pos);b=min(a+1,len(x)-1)
    return x[a]+(x[b]-x[a])*(pos-a)
def distribution(x):
    return {'n':len(x),'mean_s':statistics.mean(x) if x else None,'median_s':statistics.median(x) if x else None,
        'p95_s':percentile(x,.95),'sum_s':sum(x)}
def llm_content(c):
    b=c.get('response') or {};return (b.get('message') or {}).get('content',b.get('response',''))
def generation(c):
    b=c.get('response') or {};content=llm_content(c)
    try:json.loads(content);valid=True
    except (ValueError,TypeError):valid=False
    limit=(c.get('request',{}).get('options') or {}).get('num_predict',220)
    return {'valid_json':valid,'tokens':b.get('eval_count',0) or 0,
        'cut':b.get('done_reason')=='length' or bool(b.get('eval_count',0)>=limit and not valid),
        'wall_s':c.get('elapsed_s',0),'prompt_tokens':b.get('prompt_eval_count'),
        'prompt_eval_s':(b.get('prompt_eval_duration') or 0)/1e9,
        'generation_s':(b.get('eval_duration') or 0)/1e9,'error':bool(c.get('error'))}
def signature(r):
    turns=[]
    for t in r['turns']:
        body=t.get('response') or {};state=body.get('conversation_state') or {}
        turns.append({'user':t['user'],'assistant':t.get('assistant'),'criteria':state.get('criteria'),
            'items':state.get('items'),'pending':state.get('pending_slot'),'handoff':body.get('handoff'),
            'public_products':[(x.get('item_id'),x.get('title')) for a in body.get('actions',[]) if a.get('type')=='show_items' for x in a.get('items',[])]})
    return hashlib.sha256(json.dumps(turns,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def case_latency(r):return sum(t['latency_s'] for t in r['turns'])
def has_items(r):return bool(r.get('items'))
def residual(r):return any(t.get('llm_calls') or t.get('no_llm_residual_handoffs') for t in r['turns'])
def summary(rows):
    turns=[t for r in rows for t in r['turns']]
    calls=[generation(c) for t in turns for c in t.get('llm_calls',[])]
    return {'cases':len(rows),'turns':len(turns),'technical_error_cases':sum(any(t['status']>=500 for t in r['turns']) for r in rows),
        'technical_error_turns':sum(t['status']>=500 for t in turns),'domain_rejections':sum(t['status'] in [400,422] for t in turns),
        'searched_cases':sum(any(t.get('searches') for t in r['turns']) for r in rows),
        'items_presented_cases':sum(has_items(r) for r in rows),'screening':dict(Counter(r['screening'] for r in rows)),
        'stop_reasons':dict(Counter(r.get('stop_reason','fixed_replay') for r in rows)),
        'handoff_cases':sum(any((t.get('response',{}).get('handoff') or {}).get('required') for t in r['turns']) for r in rows),
        'repeated_question_cases':sum(r.get('stop_reason')=='repeated_question' for r in rows),
        'residual_exposed_cases':sum(residual(r) for r in rows),'no_llm_policy_turns':sum(bool(t.get('no_llm_residual_handoffs')) for t in turns),
        'turn_latency':distribution([t['latency_s'] for t in turns]),'case_latency':distribution([case_latency(r) for r in rows]),
        'llm_turn_latency':distribution([t['latency_s'] for t in turns if t.get('llm_calls')]),
        'llm_calls':len(calls),'llm_raw_json_complete':sum(c['valid_json'] for c in calls),
        'llm_cut_outputs':sum(c['cut'] for c in calls),'llm_generated_tokens':sum(c['tokens'] for c in calls),
        'llm_technical_call_errors':sum(c['error'] for c in calls),'llm_call_latency':distribution([c['wall_s'] for c in calls]),
        'llm_prompt_eval_latency':distribution([c['prompt_eval_s'] for c in calls]),
        'llm_generation_latency':distribution([c['generation_s'] for c in calls]),
        'backend_fallback_turns':sum(bool((t.get('backend_audit') or {}).get('llm_fallback_used')) for t in turns),
        'structural_case_passes':sum(bool(r.get('structural_pass')) for r in rows),
        'structural_turn_passes':sum(not t.get('expectation_failures') for t in turns if 'expectation_failures' in t),
        'golden_expected_field_passes':sum(bool(r.get('original_expected_field_pass')) for r in rows)}
def main(partial=False):
    rows=[]
    for p in sorted((ROOT/'runs').glob('rep_*/*/*/*.json')):
        r=read(p);r['_file']=str(p.relative_to(ROOT));rows.append(r)
    protocol=read(ROOT/'protocol.json');audit=read(ROOT/'input_audit.json')
    wanted=3*2*(371+170+27)
    if not partial:assert len(rows)==wanted,(len(rows),wanted)
    grouped=defaultdict(list);by_case={};per_rep={}
    for r in rows:
        grouped[r['suite'],r['repetition'],r['arm']].append(r)
        by_case[r['suite'],r['id'],r['repetition'],r['arm']]=r
    for (suite,rep,arm),items in grouped.items():
        if not partial:assert len(items)==protocol['suites'][suite]
        per_rep.setdefault(suite,{}).setdefault(str(rep),{})[arm]=summary(items)
    paired=[];stability={};cases=read(ROOT/'inputs/cases_371.json')
    for c in cases:
        reps=[]
        for rep in [1,2,3]:
            d=by_case.get(('categories',c['id'],rep,'D'));h=by_case.get(('categories',c['id'],rep,'H'))
            if not d or not h:continue
            reps.append({'repetition':rep,'D_screen':d['screening'],'H_screen':h['screening'],
                'D_items':has_items(d),'H_items':has_items(h),'D_searches':len(d.get('searches',[])),'H_searches':len(h.get('searches',[])),
                'D_stop':d.get('stop_reason'),'H_stop':h.get('stop_reason'),
                'D_latency_s':case_latency(d),'H_latency_s':case_latency(h),
                'latency_difference_H_minus_D_s':case_latency(h)-case_latency(d),
                'H_residual':residual(h),'D_residual':residual(d),
                'same_conversation':signature(d)==signature(h),
                'H_codes':[i['item_id'] for i in h.get('items',[])],'D_codes':[i['item_id'] for i in d.get('items',[])]})
        if not reps:continue
        paired.append({'id':c['id'],'group_code':c['group_code'],'initial_message':c['initial_message'],
            'repetitions':reps,'mean_paired_latency_difference_s':statistics.mean(r['latency_difference_H_minus_D_s'] for r in reps)})
    for suite in protocol['suites']:
        ids=sorted({r['id'] for r in rows if r['suite']==suite})
        stability[suite]={}
        for arm in ['D','H']:
            changed=[];tested=0
            for cid in ids:
                rs=[by_case[suite,cid,rep,arm] for rep in [1,2,3] if (suite,cid,rep,arm) in by_case]
                if len(rs)<3:continue
                tested+=1
                if len({signature(r) for r in rs})>1:changed.append(cid)
            stability[suite][arm]={'cases_with_three_repetitions':tested,'changed_conversation_cases':changed,'unchanged_cases':tested-len(changed)}
    table={}
    for rep in [1,2,3]:
        pairs=[x for c in paired for x in c['repetitions'] if x['repetition']==rep]
        exposed=[p for p in pairs if p['H_residual'] or p['D_residual']]
        table[str(rep)]={'pairs':len(pairs),'exposed_pairs':len(exposed),
            'identical_conversations':sum(p['same_conversation'] for p in pairs),
            'H_only_presented_items':sum(p['H_items'] and not p['D_items'] for p in pairs),
            'D_only_presented_items':sum(p['D_items'] and not p['H_items'] for p in pairs),
            'paired_case_latency_difference':distribution([p['latency_difference_H_minus_D_s'] for p in pairs]),
            'residual_paired_case_latency_difference':distribution([p['latency_difference_H_minus_D_s'] for p in exposed]),
            'screen_transitions':dict(Counter(p['D_screen']+' -> '+p['H_screen'] for p in pairs))}
    golden_clean={}
    excluded=set(audit['exact_initial_message_overlap']['golden_flow']['train'])|set(audit['exact_initial_message_overlap']['golden_flow']['validation'])
    for rep in [1,2,3]:
        golden_clean[str(rep)]={}
        for arm in ['D','H']:
            clean=[r for r in grouped.get(('golden_flow',rep,arm),[]) if r['id'] not in excluded]
            golden_clean[str(rep)][arm]={'n':len(clean),'passed':sum(r.get('original_expected_field_pass',False) for r in clean)}
    duplicate_clusters=defaultdict(list)
    # Normalize whitespace and case only here; preserve the audit's broader normalization separately.
    for c in paired:duplicate_clusters[' '.join(c['initial_message'].casefold().split())].append(c)
    unique_group_latency=[statistics.mean(c['mean_paired_latency_difference_s'] for c in cluster) for cluster in duplicate_clusters.values()]
    result={'generated_at':datetime.now(timezone.utc).isoformat(),'complete':len(rows)==wanted,
        'planned_case_records':wanted,'observed_case_records':len(rows),'per_repetition':per_rep,
        'paired_categories':table,'stability':stability,'golden_without_exact_overlap':golden_clean,
        'unique_initial_message_cluster_count':len(duplicate_clusters),
        'cluster_mean_paired_case_latency_difference':distribution(unique_group_latency),
        'human_commercial_accuracy':None,'human_reviewer_count':0,
        'notes':['Catalog coherence is automated screening, never human accuracy',
            '568 case IDs across suites are not necessarily independent requests',
            'Three repetitions do not create three times as many independent customers',
            'D is a conservative residual-handoff policy, not the best conceivable deterministic system',
            'Latency includes prefix-cache and shared-host effects; repetitions are reported separately']}
    write(ROOT/'summary.json',result);write(ROOT/'paired_category_results.json',paired)
    if not partial:assert not any(c.get('llm_calls') for r in rows if r['arm']=='D' for c in r['turns'])
    print(json.dumps({'complete':result['complete'],'records':len(rows),'planned':wanted,'human_accuracy':None},ensure_ascii=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--partial',action='store_true');args=p.parse_args();main(args.partial)
