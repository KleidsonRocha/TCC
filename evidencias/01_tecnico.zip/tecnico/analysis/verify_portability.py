"""Check the assembled manifest and rebuild documents using only its technical copy."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent if ROOT.name=='tecnico' else ROOT.parents[2]/'.tmp/Documents/avaliacao_final_projeto_20261026'
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
def main(check_only=False):
    names=['relatorio_avaliacao_final.html','relatorio_avaliacao_final.md','leitor_conversas.html']
    before={n:sha(OUT/n) for n in names}
    if not check_only:
        for script in ['build_report.py','build_case_reader.py']:
            p=subprocess.run([sys.executable,'-X','utf8',str(OUT/'tecnico/analysis'/script)],capture_output=True,text=True,encoding='utf-8')
            assert p.returncode==0,(script,p.stdout,p.stderr)
        assert before=={n:sha(OUT/n) for n in names},'Rebuilt documents differ from delivered bytes in this environment'
    manifest=json.loads((OUT/'manifest_entrega.json').read_text(encoding='utf-8'))
    for name,info in manifest['files'].items():
        assert (OUT/name).is_file() and sha(OUT/name)==info['sha256'],name
    records=list((OUT/'tecnico/runs').glob('rep_*/*/*/*.json'));assert len(records)==3408
    if not check_only:
        (ROOT/'qa/reproduction_checks.json').write_text(json.dumps({'passed':True,
            'scope':'Rebuild from the assembled technical copy in the recorded local environment; byte equivalence verified',
            'report_and_reader_sha256':before,'original_workspace_data_needed':False},indent=2),encoding='utf-8')
    print(json.dumps({'manifest_files_verified':len(manifest['files']),'case_records':len(records),
        'portable_rebuild_verified':not check_only,'check_only':check_only}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--check-only',action='store_true');main(p.parse_args().check_only)
