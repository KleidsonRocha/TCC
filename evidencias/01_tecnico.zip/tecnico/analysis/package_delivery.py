"""Copy complete evidence and verify frozen inputs; never package a partial study."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parents[2] / '.tmp/Documents/avaliacao_final_projeto_20261026'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def main():
    assert ROOT.name!='tecnico','The delivered package is already assembled; run assembly only from the original study workspace'
    summary = read(ROOT / 'summary.json')
    assert summary['complete'] and summary['observed_case_records'] == 3408
    assert (ROOT / 'runs/completed.json').exists()
    manifest = read(ROOT / 'freeze_manifest_v2.json')
    mismatches = [name for name, digest in manifest['files'].items()
                  if not (ROOT / name).is_file() or sha(ROOT / name) != digest]
    assert not mismatches, f'Frozen files changed: {mismatches}'
    before = (ROOT / 'active_services_before.txt').read_text(encoding='utf-8-sig').strip()
    after = (ROOT / 'active_services_after.txt').read_text(encoding='utf-8-sig').strip()
    recovery = (ROOT / 'recovery_20261027.json').exists()
    if recovery:
        assert read(ROOT / 'interruption_analysis.json')['complete']
        assert read(ROOT / 'recovery_warmup_20261027.json')['excluded_from_measurements']
    assert read(ROOT / 'database_verification.json')['effective_catalog_equals_pretest_freeze']
    checkpoint = (ROOT / 'services_after_engine_restart.txt').read_text(encoding='utf-8-sig').strip() if recovery else before
    assert checkpoint == after, 'Service image/start time changed within the resumed segment; investigate'
    before_images = {line.split()[0]: line.split()[1] for line in before.splitlines()}
    after_images = {line.split()[0]: line.split()[1] for line in after.splitlines()}
    assert before_images == after_images, 'Service image changed during the study'
    dest = OUT / 'tecnico'
    dest.mkdir(parents=True, exist_ok=True)
    (OUT / 'LEIA_PRIMEIRO.md').write_text('''# Avaliação final — estudo iniciado em 26/10/2026

1. Abra `relatorio_avaliacao_final.html` para metodologia, resultados e limites.
2. Use `leitor_conversas.html` para consultar todos os casos nas três repetições,
   comparar D/H e abrir os JSONs completos de conversas, buscas e tempos.
3. Encaminhe **somente `pacote_para_especialistas.zip`** aos dois profissionais
   qualificados, para revisão independente. As perguntas estão também em
   `para_especialistas/PERGUNTAS_PARA_O_ESPECIALISTA.md`.
4. Cada avaliador deve registrar sua interpretação antes de revelar A/B e
   exportar seu JSON. Há um lote inicial de 60 e acesso aos 371 casos.
   Mantenha a chave de identificação D/H e o pacote técnico com o autor até
   receber as revisões. As letras alternam por caso.
5. Consulte `tecnico/REPRODUCAO.md` para recalcular métricas, reexecutar o
   laboratório e incorporar formulários. Solicite também os dez novos pedidos
   do template com gabaritos congelados antes de rodar o sistema.

A bateria técnica contém 3408 execuções de caso: 371 categorias, 170 cenários
estruturais e 27 golden, duas configurações e três repetições. Os 604 testes
do agente e 33 do gateway também foram executados. Esses números não são
uma taxa de precisão comercial. A revisão humana está pendente e nenhum
formulário de especialista foi preenchido pelo agente.

`avaliacao_final_completa.zip` contém esta entrega para o autor, inclusive a
chave de identificação das configurações. Não o use como pacote de revisão cega.
Os pesos do modelo não foram duplicados; digest e dependências estão registrados.
`manifest_entrega.json` permite conferir os hashes dos arquivos entregues.
''', encoding='utf-8')
    trees = ['frozen', 'gateway_frozen', 'inputs', 'harness', 'analysis', 'runs', 'pilot', 'pilot_v2', 'runtime_logs']
    for name in trees:
        shutil.copytree(ROOT / name, dest / name, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    # QA fixtures use fictional answers. Ship checks only, never fictional reviews.
    (dest / 'qa').mkdir(exist_ok=True)
    for path in (ROOT / 'qa').glob('*checks.json'):
        shutil.copy2(path, dest / 'qa' / path.name)
    for path in ROOT.iterdir():
        if path.is_file() and path.suffix in {'.json', '.xml', '.txt', '.py', '.md'}:
            shutil.copy2(path, dest / path.name)
    forbidden = [p for p in dest.rglob('*') if p.is_file() and
                 (p.name == '.env' or p.suffix in {'.pem', '.key'} or p.name.startswith('review_QA'))]
    assert not forbidden, forbidden
    report=(OUT/'relatorio_avaliacao_final.html').read_text(encoding='utf-8')
    links=re.findall(r'href="([^"]+)"',report)
    assert links and all((OUT/name).is_file() for name in links)
    reader=(OUT/'leitor_conversas.html').read_text(encoding='utf-8')
    cards=json.loads(re.search(r'<script id="data" type="application/json">([\s\S]*?)</script>',reader).group(1))
    assert len(cards)==568
    raw_paths=[v['raw_file'] for c in cards for rep in c['reps'].values() for v in rep.values()]
    assert len(raw_paths)==len(set(raw_paths))==3408
    assert all((OUT/p).is_file() for p in raw_paths)
    turns=sum(len(v['turns']) for c in cards for rep in c['reps'].values() for v in rep.values())
    assert turns==sum(v['turns'] for suite in summary['per_repetition'].values() for rep in suite.values() for v in rep.values())
    (dest/'qa/delivery_checks.json').write_text(json.dumps({'passed':True,'case_ids':len(cards),
        'case_records':len(raw_paths),'turn_records':turns,'report_links_checked':len(links),
        'raw_file_links_checked':len(raw_paths),'browser_visual_QA':False},indent=2),encoding='utf-8')
    inventory = {str(p.relative_to(OUT)).replace('\\', '/'): {'sha256': sha(p), 'bytes': p.stat().st_size}
                 for p in sorted(OUT.rglob('*')) if p.is_file()
                 and p.name not in {'avaliacao_final_completa.zip', 'manifest_entrega.json'}}
    (OUT / 'manifest_entrega.json').write_text(json.dumps({
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'study_complete': True, 'case_records': 3408,
        'freeze_files_verified': len(manifest['files']),
        'service_images_unchanged': True,
        'services_unchanged_after_resumption_checkpoint': True,
        'external_interruption_and_engine_resumption_recorded': recovery,
        'human_review_status': 'pending; no fictional QA answers included',
        'files': inventory}, ensure_ascii=False, indent=2), encoding='utf-8')
    archive = OUT / 'avaliacao_final_completa.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file() and p != archive:
                z.write(p, str(p.relative_to(OUT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    with zipfile.ZipFile(OUT / 'pacote_para_especialistas.zip') as z:
        assert z.testzip() is None
        assert not any('analyst_key' in n or 'tecnico/' in n for n in z.namelist())
    print(json.dumps({'files': len(inventory), 'archive_bytes': archive.stat().st_size,
                      'frozen_hashes_verified': len(manifest['files']),
                      'zip_crc_verified': True}, ensure_ascii=False))

if __name__ == '__main__':
    main()
