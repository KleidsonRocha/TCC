"""Independent integrity checks on recorded measurements, not commercial scoring."""
import argparse
from collections import Counter
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))

def main(partial=False):
    protocol = read(ROOT / 'protocol.json')
    summary = read(ROOT / 'summary.json')
    manifest = read(ROOT / 'freeze_manifest_v2.json')
    for name, digest in manifest['files'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    records = []; paths = list((ROOT / 'runs').glob('rep_*/*/*/*.json'))
    call_starts = []; counts = Counter(); turns = Counter(); elapsed = Counter()
    errors = Counter(); calls = Counter()
    for path in paths:
        row = read(path)
        rep, suite, arm = path.relative_to(ROOT / 'runs').parts[:3]
        assert rep == f"rep_{row['repetition']}" and suite == row['suite'] and arm == row['arm']
        assert path.stem == row['id']
        assert datetime.fromisoformat(row['finished_at']) >= datetime.fromisoformat(row['started_at'])
        key = (suite, str(row['repetition']), arm)
        counts[key] += 1
        for turn in row['turns']:
            turns[key] += 1
            assert math.isfinite(turn['latency_s']) and turn['latency_s'] >= 0
            elapsed[key] += turn['latency_s']
            errors[key] += turn['status'] >= 500
            assert bool(turn['llm_calls']) == turn['llm_called']
            if arm == 'D': assert not turn['llm_calls']
            for call in turn['llm_calls']:
                calls[key] += 1
                assert arm == 'H'
                req = call['request']
                assert req['model'] == protocol['model']
                for option, value in protocol['generation'].items():
                    assert (req.get(option) if option == 'keep_alive' else req['options'].get(option)) == value
                assert call['elapsed_s'] >= 0
                call_starts.append(call['started_at'])
        records.append(row)
    assert len(set(call_starts)) == len(call_starts), 'Repeated inference timestamps require investigation'
    metric_groups_checked = 0
    for (suite, rep, arm), count in counts.items():
        measured = summary['per_repetition'][suite][rep][arm]
        if partial and measured['cases'] != count:
            continue  # Runner may have saved newer cases after the partial aggregate.
        assert measured['cases'] == count and measured['turns'] == turns[suite, rep, arm]
        assert measured['llm_calls'] == calls[suite, rep, arm]
        assert measured['technical_error_turns'] == errors[suite, rep, arm]
        assert math.isclose(measured['turn_latency']['sum_s'], elapsed[suite, rep, arm], rel_tol=1e-10)
        metric_groups_checked += 1
    pairs = read(ROOT / 'paired_category_results.json')
    unexpected = [(c['id'], r['repetition']) for c in pairs for r in c['repetitions']
                  if not r['D_residual'] and not r['H_residual'] and not r['same_conversation']]
    assert not unexpected, f'Non-residual conversations differed: {unexpected}'
    tests = {}
    for name, expected in [('agent', 604), ('gateway', 33)]:
        root = ET.parse(ROOT / f'{name}_tests.xml').getroot()
        cases = root.findall('.//testcase')
        assert len(cases) == expected
        assert not root.findall('.//failure') and not root.findall('.//error') and not root.findall('.//skipped')
        tests[name] = len(cases)
    if not partial:
        assert len(records) == 3408 and summary['complete']
        assert (ROOT / 'runs/completed.json').exists()
        planned_ids = {
            'categories': {c['id'] for c in read(ROOT / 'inputs/cases_371.json')},
            'structural': {c['id'] for c in read(ROOT / 'inputs/structural_170.json')['scenarios']},
            'golden_flow': {c['id'] for c in read(ROOT / 'inputs/golden_27.json')},
        }
        for suite, expected in protocol['suites'].items():
            for rep in ['1', '2', '3']:
                for arm in ['D', 'H']:
                    assert counts[suite, rep, arm] == expected
                    assert {r['id'] for r in records if r['suite']==suite and str(r['repetition'])==rep and r['arm']==arm} == planned_ids[suite]
    result = {'complete': not partial, 'records_checked': len(records),
              'frozen_files_checked': len(manifest['files']),
              'actual_inference_calls_checked': len(call_starts),
              'D_actual_inference_calls': 0,
              'nonresidual_conversation_differences': unexpected,
              'test_passes_verified': tests,
              'metric_suite_repetition_arm_groups_checked': metric_groups_checked,
              'metrics_independently_recomputed': ['counts', 'turn counts', 'LLM calls', 'technical errors', 'latency sums'],
              'commercial_accuracy_checked': False}
    (ROOT / 'verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--partial', action='store_true')
    main(p.parse_args().partial)
