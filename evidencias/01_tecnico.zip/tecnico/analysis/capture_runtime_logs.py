"""Archive isolated service logs, including excluded warmups and recovery diagnostics."""
from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[1]
def main():
    assert (ROOT/'runs/completed.json').exists(),'Capture final runtime logs only after measurements finish'
    dest=ROOT/'runtime_logs';dest.mkdir(exist_ok=True)
    records=[]
    for name in ['tcc-eval-ollama-20261026','tcc-eval-db-20261026','tcc-eval-redis-20261026']:
        result=subprocess.run(['docker','logs','--timestamps',name],capture_output=True,timeout=60)
        assert result.returncode==0,(name,result.stderr.decode(errors='replace'))
        for stream in ['stdout','stderr']:(dest/(name+'.'+stream+'.log')).write_bytes(getattr(result,stream))
        records.append({'container':name,'stdout_bytes':len(result.stdout),'stderr_bytes':len(result.stderr)})
    (ROOT/'runtime_logs_manifest.json').write_text(json.dumps({'captured_at':datetime.now(timezone.utc).isoformat(),
        'scope':'Isolated services only; includes pilots, warmups, official cases and restart diagnostics. Do not count all log entries as official measurements.',
        'records':records},indent=2),encoding='utf-8')
    print(json.dumps(records))
if __name__=='__main__':main()
