"""Verify every blinded transcript and seal the exact package made available to reviewers."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parents[2]/'.tmp/Documents/avaliacao_final_projeto_20261026'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    form=OUT/'para_especialistas/ficha_revisao_comercial.html'
    html=form.read_text(encoding='utf-8')
    data=json.loads(re.search(r'<script id="studyData" type="application/json">([\s\S]*?)</script>',html).group(1))
    assert data['study_id']=='TCC-20261026' and len(data['cases'])==371
    assert 'assessments' not in data
    assert sum(c['priority'] for c in data['cases'])==60
    key=read(ROOT/'analyst_key.json');groups=set()
    assert len(key['cases'])==371 and {c['id'] for c in data['cases']}==set(key['cases'])
    for card in data['cases']:
        mapping=key['cases'][card['id']]
        assert mapping['priority']==card['priority']
        if card['priority']:groups.add(mapping['group_code'])
        for label,arm in mapping['arms'].items():
            assert set(card[label])=={'turns','criteria','products'}
            raw=read(ROOT/'runs/rep_1/categories'/arm/(mapping['original_case_id']+'.json'))
            assert card[label]['turns']==[{'user':t['user'],'assistant':t['assistant']} for t in raw['turns']]
    assert len(groups)==24
    with zipfile.ZipFile(OUT/'pacote_para_especialistas.zip') as z:
        assert z.testzip() is None
        assert not any('analyst_key' in n or 'tecnico' in n for n in z.namelist())
        for name in z.namelist():
            assert z.read(name)==(OUT/name).read_bytes(),name
    script=re.search(r'<script>\s*([\s\S]*?)</script>',html).group(1)
    qa=(ROOT/'qa/ficha_revisao_comercial.html').read_text(encoding='utf-8')
    assert script==re.search(r'<script>\s*([\s\S]*?)</script>',qa).group(1),'Form logic differs from flow-tested QA version'
    (ROOT/'qa/actual_review_logic.js').write_text(script,encoding='utf-8')
    paths={'delivery/'+str(p.relative_to(OUT)).replace('\\','/'):p for p in (OUT/'para_especialistas').iterdir() if p.is_file()}
    paths['delivery/pacote_para_especialistas.zip']=OUT/'pacote_para_especialistas.zip'
    paths.update({'study/'+n:ROOT/n for n in ['analyst_key.json','review_selection.json','review_source_dossier.json']})
    hashes={name:sha(p) for name,p in sorted(paths.items())}
    seal=ROOT/'review_package_manifest.json'
    if seal.exists():assert read(seal)['files']==hashes,'Reviewer package changed after sealing'
    else:seal.write_text(json.dumps({'sealed_at':datetime.now(timezone.utc).isoformat(),
        'cases':371,'priority':60,'taxonomy_groups':24,'human_labels_prefilled':False,
        'files':hashes},ensure_ascii=False,indent=2),encoding='utf-8')
    result={'passed':True,'cases':371,'priority':60,'groups':24,
        'blinded_transcripts_checked':742,'zip_crc_and_members_verified':True,
        'same_logic_as_DOM_flow_test':True,'seal_files_checked':len(hashes),
        'live_browser_visual_check':False}
    (ROOT/'review_package_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))
if __name__=='__main__':main()
