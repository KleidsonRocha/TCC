"""Test with explicitly fictional isolated fixtures; never generate research labels."""
from copy import deepcopy
import json
from pathlib import Path
from analyze_human_reviews import analyze

ROOT = Path(__file__).resolve().parents[1]
qa = ROOT / 'qa'
key = {'study_id': 'QA-TCC-20261026', 'cases': {'QA-CASE': {'arms': {'A': 'D', 'B': 'H'}}}}
base = {'study_id': key['study_id'], 'reviewer_id': 'QA_ONLY_1', 'assessments': {'QA-CASE': {
    'reference_locked_at': 'QA_ONLY', 'reference': {'coherence': 'coherent', 'correct_action': 'search',
    'evidence': 'Fictional QA evidence; not real catalogue data', 'compatible_codes': 'QA-CODE',
    'no_match_truth': 'exists', 'evidence_strength': 'sufficient', 'reference_valid': 'valid'},
    'A': {'overall': 'adequate', 'top1': 'no_items', 'top3': 'no_items'},
    'B': {'overall': 'adequate', 'top1': 'compatible', 'top3': 'yes'}}}}
paths = [qa / f'fictional_review_test_{i}.json' for i in range(2)]
def run(first, second=None):
    paths[0].write_text(json.dumps(first), encoding='utf-8')
    if second is not None: paths[1].write_text(json.dumps(second), encoding='utf-8')
    return analyze(paths[:2 if second is not None else 1], key_override=key)
checks = []
second = deepcopy(base); second['reviewer_id'] = 'QA_ONLY_2'
second['assessments']['QA-CASE']['B']['overall'] = 'inadequate'
r = run(base, second)
assert r['adjudicated_commercial_accuracy'] is None and len(r['disagreements_to_adjudicate']) == 1
assert r['reviewer_independence_verified'] is False
checks.append('Distinct IDs do not certify independence or fabricate consensus/accuracy')
stats = r['per_reviewer']['QA_ONLY_1']['by_configuration']
assert stats['D']['source_sufficient_positive_rank_cases'] == stats['H']['source_sufficient_positive_rank_cases'] == 1
assert stats['H']['positive_top1_hits'] == 1 and stats['D']['positive_top1_hits'] == 0
checks.append('Positive ranking compares identical eligible paired cases')
unknown = deepcopy(base); unknown['assessments']['QA-CASE']['B']['top1'] = 'unknown'
r = run(unknown)
assert all(s['source_sufficient_positive_rank_cases'] == 0 for s in r['per_reviewer']['QA_ONLY_1']['by_configuration'].values())
checks.append('Unknown ranking in one arm excludes both arms from paired positive denominator')
edited = deepcopy(base); edited['assessments']['QA-CASE']['reference_edited_after_outputs'] = True
r = run(edited)
assert all(s['source_sufficient_positive_rank_cases'] == 0 for s in r['per_reviewer']['QA_ONLY_1']['by_configuration'].values())
checks.append('Reference edited after output exposure excluded from pre-output positive denominator')
contradiction = deepcopy(base); contradiction['assessments']['QA-CASE']['reference']['coherence'] = 'contradictory'
r = run(contradiction)
assert all(s['source_sufficient_positive_rank_cases'] == 0 for s in r['per_reviewer']['QA_ONLY_1']['by_configuration'].values())
checks.append('Contradictory initial requests excluded from strict search-ready positive denominator')
try:
    run(base, base)
    raise AssertionError('Duplicate reviewer should fail')
except ValueError: checks.append('Duplicate reviewer IDs rejected')
wrong = deepcopy(base); wrong['study_id'] = 'WRONG'
try:
    run(wrong)
    raise AssertionError('Wrong study should fail')
except ValueError: checks.append('Wrong study rejected')
# Leave fixtures clearly labeled, with valid fictional inputs, only in excluded QA directory.
run(base, second)
(qa / 'review_analysis_checks.json').write_text(json.dumps({'passed': True, 'checks': checks,
    'scope': 'Fictional QA fixtures only; excluded from research and delivery'}, indent=2), encoding='utf-8')
print(json.dumps({'passed': True, 'checks': checks}))
