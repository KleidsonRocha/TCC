"""Check preserved state and record an excluded warm-up after external interruption."""
import hashlib
import json
from pathlib import Path
import time
import httpx
from run_study import settings, now, PROTOCOL

root=Path('/study');s=settings()
manifest=json.loads((root/'freeze_manifest_v2.json').read_text())
for name,digest in manifest['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
tags=httpx.get(s.llm_base_url+'/api/tags',timeout=30).json()
expected='845dbda0ea48ed749caafd9e6037047aa19acfcfd82e704d7ca97d631a0b697e'
model=next(m for m in tags['models'] if m['name']==s.llm_model)
assert model['digest']==expected,model['digest']
start=time.perf_counter()
response=httpx.post(s.llm_base_url+'/api/generate',json={'model':s.llm_model,
    'prompt':'Responda OK.','stream':False,'keep_alive':'-1m',
    'options':{k:v for k,v in {**PROTOCOL['generation'],'num_predict':2}.items() if k!='keep_alive'}},timeout=240)
response.raise_for_status()
ps=httpx.get(s.llm_base_url+'/api/ps',timeout=30).json()
assert all(not m.get('size_vram',0) for m in ps.get('models',[])),'Expected CPU-only inference'
record={'recorded_at':now(),'excluded_from_measurements':True,'reason':'Rewarm preserved model after Docker/host interruption',
    'frozen_hashes_verified':len(manifest['files']),'model':model,'elapsed_s':time.perf_counter()-start,
    'response':response.json(),'loaded_models':ps}
(root/'recovery_warmup_20261027.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'excluded_warmup_completed':True,'model_digest_verified':expected,
    'CPU_only_verified':True,'frozen_hashes_verified':len(manifest['files'])}))
