import json
from pathlib import Path
import psycopg
from psycopg.rows import dict_row
from app.infra.postgres_conninfo import build_catalog_conninfo
from run_study import settings

root=Path('/study');codes=set()
cases=json.loads((root/'inputs/cases_371.json').read_text())
for c in cases:
    if c.get('reference'):codes.add(str(c['reference']['cd_item']))
for p in (root/'runs/rep_1/categories').glob('*/*.json'):
    for item in json.loads(p.read_text()) .get('items',[]):codes.add(str(item['item_id']))
with psycopg.connect(build_catalog_conninfo(settings()),row_factory=dict_row) as conn:
    conn.execute('SET TRANSACTION READ ONLY')
    products=conn.execute('SELECT * FROM soccol.item_search_candidates WHERE cd_item=ANY(%s)',(sorted(codes),)).fetchall()
    apps=conn.execute('SELECT * FROM soccol.item_search_applications WHERE id_item=ANY(%s) ORDER BY id_item,application_id',([p['id_item'] for p in products],)).fetchall()
(root/'review_source_dossier.json').write_text(json.dumps({'source':'frozen 2026-10-19 snapshot','products':products,'applications':apps},ensure_ascii=False,indent=2),encoding='utf-8')
print('Review source exported',len(products),'products',len(apps),'applications')
