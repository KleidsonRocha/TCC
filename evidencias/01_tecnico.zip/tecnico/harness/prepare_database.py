import gzip
import hashlib
import json
from pathlib import Path
from dataclasses import asdict
from datetime import datetime,timezone
import psycopg
from app.config import Settings
from app.infra.postgres_conninfo import build_catalog_conninfo
from app.infra.pre_search_catalog_pg import PostgresPreSearchCatalogProvider
from scripts.catalog.apply_catalog_alias_updates import apply_updates
from scripts.erp.export_search_snapshot import COLUMNS
import logging

ROOT=Path('/study')
settings=Settings(_env_file=None,CATALOG_DB_HOST='tcc-eval-db-20261026',
    CATALOG_DB_NAME='presearch',CATALOG_DB_USER='presearch',CATALOG_DB_PASSWORD='avaliacao-local',
    ERP_DB_ENABLED=False,PRE_SEARCH_REVIEW_CAPTURE_ENABLED=False)
assert settings.catalog_db_host=='tcc-eval-db-20261026'
assert not (ROOT/'database_prepared.json').exists(),'Do not overwrite a prepared evaluation database'
manifest=json.loads((ROOT/'inputs/source_snapshot/manifest.json').read_text())
with psycopg.connect(build_catalog_conninfo(settings)) as conn:
    conn.execute('SET LOCAL statement_timeout=\'10min\'')
    conn.execute('TRUNCATE soccol.item_search_applications,soccol.item_search_candidates')
    counts={}
    for name in ['candidates','applications']:
        path=ROOT/'inputs/source_snapshot'/f'{name}.csv.gz'
        assert hashlib.sha256(path.read_bytes()).hexdigest()==manifest['files'][path.name]['sha256']
        with gzip.open(path,'rb') as f,conn.cursor() as cur:
            with cur.copy(f"COPY soccol.item_search_{name} ({', '.join(COLUMNS[name])}) FROM STDIN WITH (FORMAT CSV,HEADER TRUE)") as copy:
                while chunk:=f.read(1048576):copy.write(chunk)
        counts[name]=conn.execute(f'SELECT count(*) FROM soccol.item_search_{name}').fetchone()[0]
        assert counts[name]==manifest['files'][path.name]['rows']
        conn.execute(f'ANALYZE soccol.item_search_{name}')
        print(name,counts[name],flush=True)
    update_counts=apply_updates(conn,Path('db/init'))
    for name in ['pre_search_review_interaction','pre_search_fine_tuning_dataset_record']:
        assert conn.execute(f'SELECT count(*) FROM {name}').fetchone()[0]==0
    concepts=conn.execute('SELECT count(*) FROM pre_search_family_concept WHERE is_active').fetchone()[0]
    decisions=conn.execute('SELECT count(*) FROM pre_search_alias_decision WHERE is_active').fetchone()[0]
catalog=PostgresPreSearchCatalogProvider(settings=settings,logger=logging.getLogger('freeze')).load()
def serial(x):
    if isinstance(x,dict):return {k:serial(v) for k,v in sorted(x.items())}
    if isinstance(x,set):return sorted(serial(v) for v in x)
    if isinstance(x,(tuple,list)):return [serial(v) for v in x]
    return x
(ROOT/'effective_catalog.json').write_text(json.dumps(serial(asdict(catalog)),ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'database_prepared.json').write_text(json.dumps({'prepared_at':datetime.now(timezone.utc).isoformat(),
    'host':settings.catalog_db_host,'counts':counts,'seed_update':update_counts,'active_concepts':concepts,
    'active_alias_decisions':decisions,'review_and_training_records':0,'source_manifest':manifest},ensure_ascii=False,indent=2),encoding='utf-8')
print('Database prepared',concepts,decisions,flush=True)
