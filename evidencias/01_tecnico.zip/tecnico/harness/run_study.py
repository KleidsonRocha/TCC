"""Preregistered paired ablation. Production code is imported from read-only /app."""
from __future__ import annotations
import argparse
import asyncio
from collections import Counter
from copy import deepcopy
from datetime import datetime,timezone
import hashlib
import json
import logging
from pathlib import Path
import time
import traceback
import uuid
import httpx
import psycopg
from psycopg.rows import dict_row
from pydantic import ValidationError
from app.config import Settings
from app.api.schemas.contract_v1 import AgentRequestV1
from app.core.domain.models import ConversationState
from app.core.domain.pre_search import PreSearchValidation
from app.core.domain.errors import InvalidMessageError,UnsupportedSchemaVersionError,PreSearchServiceUnavailableError,SearchPartsServiceUnavailableError
from app.core.usecases.process_agent_request import ProcessAgentRequestUseCase
from app.infra.pre_search_catalog_pg import resolve_pre_search_catalog
from app.infra.pre_search_validator_llm import LLMPreSearchValidator
from app.infra.pre_search_review_queue_pg import NoOpPreSearchReviewRecorder
from app.infra.erp_search_tools_pg import resolve_search_tools
from app.infra.postgres_conninfo import build_catalog_conninfo
from app.infra.pre_search_benchmark import evaluate_case
from scripts.eval.evaluate_category_search import RecordingTools,SourceInspector,answer_question,displayed_items,application_matches
from scripts.eval.run_real_respond_battery import normalize_response,evaluate_expectations

ROOT=Path('/study');LOG=logging.getLogger('final-evaluation')
logging.basicConfig(level=logging.ERROR)
PROTOCOL=json.loads((ROOT/'protocol.json').read_text())
def now():return datetime.now(timezone.utc).isoformat()
def save(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str),encoding='utf-8');tmp.replace(path)

class AuditValidator(LLMPreSearchValidator):
    def __init__(self,*,arm,**kwargs):
        super().__init__(**kwargs);self.arm=arm;self.calls=[];self.residual_handoffs=[]
    def _post_chat_or_generate(self,**kwargs):
        assert self.arm=='H','Deterministic arm must never reach inference'
        request=deepcopy(kwargs['payload'])
        request['options'].update(PROTOCOL['generation'])
        request['options'].pop('keep_alive',None)
        kwargs['payload']=request
        start=time.perf_counter();record={'started_at':now(),'request':request};self.calls.append(record)
        try:
            raw,endpoint=super()._post_chat_or_generate(**kwargs)
            record.update(response=raw,endpoint=endpoint)
            return raw,endpoint
        except Exception as exc:
            record['error']={'type':type(exc).__name__,'message':str(exc)};raise
        finally:record['elapsed_s']=time.perf_counter()-start
    def validate(self,message_text,*,last_messages=None,conversation_state=None):
        if self.arm=='H':
            return super().validate(message_text,last_messages=last_messages,conversation_state=conversation_state)
        # Identical deterministic preparation from the frozen validate prelude.
        # The intervention is a declared human handoff at the residual boundary,
        # not a simulated provider error and not a fabricated LLM JSON response.
        self._last_audit_info.set(None);context=last_messages or []
        current=self._normalize_pending_follow_up_current_criteria(message_text=message_text,
            criteria=self._dictionary_extractor.extract(message_text,last_messages=[]),conversation_state=conversation_state)
        year_answer=self._year_answer_to_model_question(message_text=message_text,conversation_state=conversation_state)
        if year_answer is not None:return year_answer
        safety=self._request_safety_confirmation(message_text=message_text,criteria=current,conversation_state=conversation_state)
        if safety is not None:
            self._set_deterministic_safety_audit(safety);return safety
        seed=self._dictionary_extractor.extract(message_text,last_messages=context)
        seed=self._apply_pending_follow_up_answer_to_context(criteria=seed,current_criteria=current,
            conversation_state=conversation_state,message_text=message_text)
        seed=self._merge_dictionary_with_conversation_state(dictionary_criteria=seed,conversation_state=conversation_state)
        self.residual_handoffs.append({'message':message_text,'seed':seed.model_dump(mode='json')})
        self._last_audit_info.set({'pre_search_path':'deterministic_residual_handoff',
            'no_llm_policy_applied':True,'llm_output_valid':None,'llm_fallback_used':False})
        return self._build_no_decision_handoff(criteria=seed,missing_fields=[],confidence=0.0)

class AuditUseCase(ProcessAgentRequestUseCase):
    def __init__(self,**kwargs):super().__init__(**kwargs);self.presearch_values=[]
    async def _validate_pre_search(self,**kwargs):
        value=await super()._validate_pre_search(**kwargs)
        self.presearch_values.append(value[0].model_dump(mode='json'))
        return value

def settings():
    return Settings(_env_file=None,APP_ENV='dev',CATALOG_DB_HOST='tcc-eval-db-20261026',
        CATALOG_DB_USER='presearch',CATALOG_DB_PASSWORD='avaliacao-local',CATALOG_DB_NAME='presearch',
        ERP_DB_ENABLED=False,ERP_FALLBACK_DB_ENABLED=True,PRE_SEARCH_REVIEW_CAPTURE_ENABLED=False,
        LLM_BASE_URL='http://tcc-eval-ollama-20261026:11434',LLM_MODEL='qwen2.5:7b',
        LLM_TEMPERATURE=0,LLM_NUM_PREDICT=220,LLM_KEEP_ALIVE='-1m',LLM_TIMEOUT_MS=240000,
        LLM_MAX_CONCURRENT_REQUESTS=1,ERP_SEARCH_MAX_CONCURRENT_REQUESTS=1,LLM_WARMUP_ENABLED=False)

def components(s,catalog,arm):
    validator=AuditValidator(arm=arm,settings=s,logger=LOG,catalog=catalog)
    tools=RecordingTools(resolve_search_tools(settings=s,logger=LOG,catalog=catalog))
    use=AuditUseCase(tools=tools,pre_search_validator=validator,settings=s,logger=LOG,
        review_recorder=NoOpPreSearchReviewRecorder())
    return validator,tools,use

async def turn(use,validator,tools,message,state,history,cid,version='1.0'):
    started=time.perf_counter();a,b,c,d=len(validator.calls),len(tools.searches),len(use.presearch_values),len(validator.residual_handoffs)
    row={'started_at':now(),'user':message,'schema_version':version}
    try:
        payload=AgentRequestV1(schema_version=version,trace_id=uuid.uuid4().hex,conversation_id=cid,
            channel={'name':'isolated-final-evaluation'},message={'text':message},business={'branch_id':1},
            context={'last_messages':history[-20:],'conversation_state':state})
        row['request']=payload.model_dump(mode='json')
        value=await use.execute(payload)
        row.update(response=value.model_dump(mode='json'),status=200)
    except Exception as exc:
        status=400 if isinstance(exc,(InvalidMessageError,UnsupportedSchemaVersionError)) else (
            422 if isinstance(exc,ValidationError) else 503 if isinstance(exc,(PreSearchServiceUnavailableError,SearchPartsServiceUnavailableError)) else 500)
        row.update(status=status,error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()},response={})
    row.update(latency_s=time.perf_counter()-started,finished_at=now(),llm_calls=deepcopy(validator.calls[a:]),
        searches=deepcopy(tools.searches[b:]),presearch_values=deepcopy(use.presearch_values[c:]),
        no_llm_residual_handoffs=deepcopy(validator.residual_handoffs[d:]),backend_audit=use._validator_audit_info())
    row['llm_called']=bool(row['llm_calls']);row['assistant']=normalize_response(row['response'])['reply_text']
    assert validator.arm!='D' or not row['llm_calls']
    return row

def inspector_case(case):
    # Current inspector's legacy group fallback uses the old spelling 'group'.
    # Translate only this evaluation metadata, preserving original input text.
    return {**case,'level':'group' if case.get('level')=='category' else case.get('level')}

async def category(case,s,catalog,arm,inspector):
    validator,tools,use=components(s,catalog,arm)
    state=None;history=[];turns=[];returned=[];supplied=dict(case.get('initial_facts',{}));seen=set()
    message=case['initial_message'];basis='initial_message';stop='turn_limit';cid='evaluation-'+uuid.uuid4().hex
    for i in range(8):
        record=await turn(use,validator,tools,message,state,history,cid)
        record.update(turn=i+1,answer_basis=basis);turns.append(record)
        if record['status']!=200:stop='technical_error';break
        body=record['response'];normal=normalize_response(body);state=normal['conversation_state']
        items=displayed_items(body,tools.searches)
        if items:
            checked=await asyncio.to_thread(inspector.inspect,items,inspector_case(case),supplied)
            record['items_source_inspection']=checked;returned.extend(checked);stop='items_presented';break
        history.extend([{'role':'user','text':message},{'role':'assistant','text':record['assistant']}])
        if normal['handoff_required']:stop='human_handoff';break
        message,basis,_=answer_question(case,state,normal['actions'],supplied)
        if not message:stop=basis;break
        key=(state.get('pending_slot'),message)
        if key in seen:stop='repeated_question';break
        seen.add(key)
    if returned:screen='catalog_coherent_screen' if not any(i.get('suspicions') for i in returned) else 'catalog_mismatch_suspected'
    elif stop=='technical_error':screen='technical_error'
    elif not case.get('source_item_count'):screen='reference_subcategory_empty'
    else:screen='no_item_presented_requires_review'
    return {'id':case['id'],'input':case,'turns':turns,'items':returned,'supplied_facts':supplied,
        'searches':deepcopy(tools.searches),'stop_reason':stop,'screening':screen,'human_review_required':True}

async def structural(case,s,catalog,arm):
    validator,tools,use=components(s,catalog,arm)
    state=None;history=[];turns=[];cid='structural-'+uuid.uuid4().hex
    for i,item in enumerate(case['turns']):
        record=await turn(use,validator,tools,item['message'],state,history,cid,item.get('schema_version','1.0'))
        record['turn']=i+1;record['expected']=item['expect']
        normal=normalize_response(record['response'])
        record['expectation_failures']=evaluate_expectations(item['expect'],record['status'],normal,'agent')
        turns.append(record)
        if record['status']==200:
            state=normal['conversation_state']
            history.extend([{'role':'user','text':item['message']},{'role':'assistant','text':record['assistant']}])
    return {'id':case['id'],'input':case,'turns':turns,
        'structural_pass':all(not t['expectation_failures'] for t in turns),
        'screening':'structural_regression','human_review_required':bool(case.get('review_required'))}

async def golden(case,s,catalog,arm):
    validator,tools,use=components(s,catalog,arm)
    record=await turn(use,validator,tools,case['message.text'],case.get('context.conversation_state'),
        case.get('context.last_messages',[]),'golden-'+uuid.uuid4().hex)
    evaluation=None
    if record['presearch_values']:
        value=PreSearchValidation.model_validate(record['presearch_values'][0])
        evaluation=evaluate_case(value,case['expected'])
    return {'id':case['id'],'input':case,'turns':[record],'evaluation':evaluation,
        'original_expected_field_pass':bool(evaluation and evaluation['case_pass']),
        'screening':'golden_flow_expected_fields','human_review_required':True}

def arm_order(suite,case_id,rep):
    bit=int(hashlib.sha256((suite+'/'+case_id).encode()).hexdigest(),16)%2
    if rep==2:bit=1-bit
    elif rep==3:bit=int(hashlib.sha256(('round3/'+suite+'/'+case_id).encode()).hexdigest(),16)%2
    return ['D','H'] if bit==0 else ['H','D']

async def main(args):
    assert (ROOT/'database_sealed.json').exists(),'Seal DB after control tests before measurements'
    s=settings();catalog=resolve_pre_search_catalog(settings=s,logger=LOG)
    inspector=SourceInspector(build_catalog_conninfo(s),catalog=catalog)
    suites={'categories':json.loads((ROOT/'inputs/cases_371.json').read_text()),
        'structural':json.loads((ROOT/'inputs/structural_170.json').read_text())['scenarios'],
        'golden_flow':json.loads((ROOT/'inputs/golden_27.json').read_text())}
    if args.mode=='pilot':
        suites={k:v[:1] for k,v in suites.items()}
        all_categories=json.loads((ROOT/'inputs/cases_371.json').read_text())
        suites['categories']+= [c for c in all_categories if c['id']=='group-10']
    base=ROOT/('pilot_v2' if args.mode=='pilot' else 'runs')
    if not (base/'environment.json').exists():
        tags=httpx.get(s.llm_base_url+'/api/tags',timeout=30).json()
        show=httpx.post(s.llm_base_url+'/api/show',json={'model':s.llm_model},timeout=30).json()
        save(base/'environment.json',{'started_at':now(),'tags':tags,'model_details':show,
            'settings':{'llm_model':s.llm_model,'generation':PROTOCOL['generation'],'source':'isolated frozen DB',
                'llm_timeout_ms':s.llm_timeout_ms,'review_capture':False},
            'cpuinfo':Path('/proc/cpuinfo').read_text()[:2500]})
        start=time.perf_counter()
        warm=httpx.post(s.llm_base_url+'/api/generate',json={'model':s.llm_model,'prompt':'Responda OK.',
            'stream':False,'keep_alive':'-1m','options':{k:v for k,v in {**PROTOCOL['generation'],'num_predict':2}.items() if k!='keep_alive'}},timeout=240)
        warm.raise_for_status()
        save(base/'excluded_warmup.json',{'elapsed_s':time.perf_counter()-start,'response':warm.json()})
    reps=1 if args.mode=='pilot' else PROTOCOL['planned_repetitions']
    progress=[]
    for suite,cases in suites.items():
        if args.suite and suite!=args.suite:continue
        for index,case in enumerate(cases):
            for rep in range(1,reps+1):
                for arm in arm_order(suite,case['id'],rep):
                    path=base/f'rep_{rep}'/suite/arm/(case['id']+'.json')
                    if path.exists():continue
                    began=now()
                    result=await ({'categories':category,'structural':structural,'golden_flow':golden}[suite])(
                        case,s,catalog,arm,*([inspector] if suite=='categories' else []))
                    result.update(arm=arm,repetition=rep,suite=suite,started_at=began,finished_at=now())
                    save(path,result)
                    event={'rep':rep,'suite':suite,'arm':arm,'index':index+1,'planned':len(cases),'id':case['id'],
                        'turns':len(result['turns']),'llm_calls':sum(len(t['llm_calls']) for t in result['turns']),
                        'technical_errors':sum(t['status']>=500 for t in result['turns']),
                        'screening':result['screening'],'finished_at':now()}
                    with (base/'events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(event)+'\n')
                    save(base/'progress.json',event)
                    print(json.dumps(event),flush=True)
    save(base/'completed.json',{'completed_at':now(),'repetitions':reps,'suites':list(suites),'mode':args.mode})

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['pilot','official'],default='official')
    parser.add_argument('--suite',choices=['categories','structural','golden_flow']);args=parser.parse_args()
    asyncio.run(main(args))
