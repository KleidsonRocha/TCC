import hashlib
import json
from collections import defaultdict,Counter
from pathlib import Path
import re
import psycopg
from psycopg.rows import dict_row
from app.infra.postgres_conninfo import build_catalog_conninfo
from app.infra.pre_search_catalog_pg import resolve_pre_search_catalog
from app.infra.pre_search_dictionary_extractor import DictionaryPreSearchExtractor
from app.infra.pre_search_family_curation import source_identity_matches
from app.infra.pre_search_text import normalize_pre_search_text as norm
from scripts.eval.evaluate_category_search import application_matches
from run_study import settings,LOG

ROOT=Path('/study');s=settings();catalog=resolve_pre_search_catalog(settings=s,logger=LOG)
extractor=DictionaryPreSearchExtractor(catalog=catalog)
cases=json.loads((ROOT/'inputs/cases_371.json').read_text())
golden=json.loads((ROOT/'inputs/golden_27.json').read_text())
structural=json.loads((ROOT/'inputs/structural_170.json').read_text())['scenarios']
def initial_record(r):
    if isinstance(r.get('user_payload'),dict):
        return r['user_payload'].get('message_text')
    for k in ['input_message_text','message_text','message.text']:
        if r.get(k):return r[k]
    value=r.get('input') or {}
    if isinstance(value,dict):
        for k in ['message_text','message.text','input_message_text']:
            if value.get(k):return value[k]
    return None
split_messages={};split_keys={}
for split in ['train','validation','test']:
    records=[json.loads(line) for line in (ROOT/f'inputs/training_reference/{split}.records.jsonl').read_text().splitlines() if line]
    values=[initial_record(r) for r in records]
    if any(v is None for v in values):
        raise ValueError(('Unknown training record schema',list(records[0])))
    split_messages[split]={norm(v) for v in values}
    split_keys[split]={'records':len(records),'unique_initial_messages':len(split_messages[split])}
overlap={}
for suite,rows,gettext in [('categories',cases,lambda r:r['initial_message']),
        ('golden_flow',golden,lambda r:r['message.text']),('structural',structural,lambda r:r['turns'][0]['message'])]:
    overlap[suite]={split:[r['id'] for r in rows if norm(gettext(r)) in texts] for split,texts in split_messages.items()}
duplicates=defaultdict(list)
for c in cases:duplicates[norm(c['initial_message'])].append(c['id'])
codes=sorted({str(c['reference']['cd_item']) for c in cases if c.get('reference')})
with psycopg.connect(build_catalog_conninfo(s),row_factory=dict_row) as conn:
    conn.execute('SET TRANSACTION READ ONLY')
    items=conn.execute('SELECT * FROM soccol.item_search_candidates WHERE cd_item=ANY(%s)',(codes,)).fetchall()
    apps=conn.execute('SELECT * FROM soccol.item_search_applications WHERE id_item=ANY(%s)',([i['id_item'] for i in items],)).fetchall()
by_code={str(i['cd_item']):i for i in items};by_item=defaultdict(list)
for a in apps:by_item[a['id_item']].append(a)
audit=[]
for case in cases:
    ref=case.get('reference') or {};code=str(ref.get('cd_item') or '')
    source=by_code.get(code);flags=[]
    canonical=extractor.canonicalize_part_query(case['family'])
    extracted=extractor.extract(case['initial_message'])
    if not ref:flags.append('no_reference_product')
    elif not source:flags.append('reference_code_missing_from_frozen_source')
    if canonical is None:flags.append('family_canonical_mapping_unresolved')
    if source and canonical and not source_identity_matches(source,canonical,catalog):
        flags.append('reference_scope_or_component_identity_requires_review')
    facts={k:v for k,v in (case.get('initial_facts') or {}).items() if k in {'vehicle_model','vehicle_brand','vehicle_year','engine'}}
    matches=[a for a in by_item.get((source or {}).get('id_item'),[]) if application_matches(a,facts)] if facts else []
    if source and facts and not matches:flags.append('reference_no_same_application_for_initial_facts')
    text=norm(case['initial_message'])
    for family,positive,negative in [('side',r'\mdireit[oa]',r'\mesquerd[oa]'),('position',r'\mdianteir[oa]',r'\mtraseir[oa]')]:
        if re.search(positive.replace(r'\m',r'\b'),text) and re.search(negative.replace(r'\m',r'\b'),text):
            flags.append(f'multiple_{family}_terms_requires_human_interpretation')
    if canonical and extracted.part_query and extracted.part_query!=canonical:
        flags.append('request_title_and_taxonomy_resolve_to_different_families')
    audit.append({'id':case['id'],'family':case['family'],'group_code':case['group_code'],
        'initial_message':case['initial_message'],'reference_code':code or None,
        'canonical_taxonomy_family':canonical,'dictionary_request_family':extracted.part_query,
        'source_code_exists':bool(source),'same_application_matches':len(matches),
        'flags':flags,'human_reference_approved':None})
result={'source':'frozen_snapshot','scope':'Automatic reference screening only, no human labels created',
    'total_cases':len(cases),'with_reference':sum(bool(c.get('reference')) for c in cases),
    'distinct_reference_codes':len(codes),'source_codes_found':len(by_code),
    'unique_normalized_initial_messages':len(duplicates),'duplicate_initial_message_groups':{m:ids for m,ids in duplicates.items() if len(ids)>1},
    'flags':dict(Counter(f for a in audit for f in a['flags'])),'cases':audit,
    'split_sizes':split_keys,'exact_initial_message_overlap':overlap,
    'split_message_intersections':{a+'__'+b:sorted(split_messages[a]&split_messages[b]) for a,b in [('train','validation'),('train','test'),('validation','test')]},
    'limitations':['No semantic paraphrase independence established','Automatic identity screening is not commercial certification',
        'Original messages were not rewritten; invalid references remain quarantined for human review, not converted into true labels']}
(ROOT/'input_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'reference_source_details.json').write_text(json.dumps({'products':items,'applications':apps},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in {'cases','duplicate_initial_message_groups','split_message_intersections'}},ensure_ascii=False,indent=2))
