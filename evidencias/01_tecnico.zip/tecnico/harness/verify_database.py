"""Read-only check that control tests and measurements preserved the frozen source."""
from dataclasses import asdict
import hashlib
import json
import logging
from pathlib import Path
import psycopg
from run_study import settings, now
from app.infra.postgres_conninfo import build_catalog_conninfo
from app.infra.pre_search_catalog_pg import PostgresPreSearchCatalogProvider

root = Path('/study'); s = settings()
assert s.catalog_db_host == 'tcc-eval-db-20261026'

def serial(value):
    if isinstance(value, dict): return {k: serial(v) for k, v in sorted(value.items())}
    if isinstance(value, set): return sorted(serial(v) for v in value)
    if isinstance(value, (tuple, list)): return [serial(v) for v in value]
    return value

catalog = PostgresPreSearchCatalogProvider(settings=s, logger=logging.getLogger('verify')).load()
actual = json.loads(json.dumps(serial(asdict(catalog))))
expected = json.loads((root / 'effective_catalog.json').read_text(encoding='utf-8'))
assert actual == expected, 'Effective catalog differs from pre-control-test freeze'
private = ['pre_search_review_interaction', 'pre_search_review_revision',
           'pre_search_fine_tuning_dataset_header', 'pre_search_fine_tuning_dataset_record',
           'pre_search_fine_tuning_run']
with psycopg.connect(build_catalog_conninfo(s)) as conn:
    read_only = conn.execute('SHOW default_transaction_read_only').fetchone()[0]
    assert read_only == 'on'
    source = {name: conn.execute(f'SELECT count(*) FROM soccol.item_search_{name}').fetchone()[0]
              for name in ['candidates', 'applications']}
    excluded = {name: conn.execute(f'SELECT count(*) FROM {name}').fetchone()[0] for name in private}
manifest = json.loads((root / 'inputs/source_snapshot/manifest.json').read_text())
assert all(source[n] == manifest['files'][n + '.csv.gz']['rows'] for n in source)
assert all(n == 0 for n in excluded.values())
result = {'verified_at': now(), 'effective_catalog_equals_pretest_freeze': True,
          'canonical_effective_catalog_sha256': hashlib.sha256(json.dumps(actual, sort_keys=True,
              separators=(',', ':')).encode()).hexdigest(),
          'read_only': read_only, 'source_rows': source, 'excluded_private_table_rows': excluded}
(root / 'database_verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result))
