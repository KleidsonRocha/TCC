import re
from dataclasses import dataclass
from typing import Any

from app.core.domain.pre_search_catalog import PreSearchCatalog
from app.core.domain.pre_search import SearchCriteria
from app.infra.pre_search_text import (
    canonicalize_longitudinal_direction,
    normalize_pre_search_text,
)
from app.infra.pre_search_part_code import (
    compile_part_code_patterns,
    has_literal_part_code_evidence,
    is_valid_part_code_candidate,
    normalize_part_code_candidate,
)


@dataclass(frozen=True)
class _AliasCandidate:
    canonical: str
    alias: str
    token_count: int
    char_count: int


@dataclass(frozen=True)
class _ScoredAliasCandidate:
    candidate: _AliasCandidate
    similarity: float
    distance: int


@dataclass(frozen=True)
class RequestIntent:
    """The safe, affirmative portion of one customer request.

    It deliberately has a small scope: resolve explicit replacements and
    directional negations, but expose any other negation to the validator so
    the backend can ask instead of searching on a guess.
    """

    text: str
    unresolved_reason: str | None = None


class DictionaryPreSearchExtractor:
    _MIN_FUZZY_TOKEN_LENGTH = 4
    _SINGLE_TOKEN_FUZZY_GAP = 0.05
    _MULTI_TOKEN_FUZZY_GAP = 0.03
    _COMPOSITE_PART_PATTERNS = (
        (r'\bkit\s+(?:de\s+)?reparo\s+(?:d[eo]\s+)?amortecedor\b', 'kit reparo amortecedor'),
        (r'\bconjunto\s+(?:d[eo]\s+)?amortecedor\b', 'conjunto amortecedor'),
        (r"\bpolia(?:s)?\s+(?:\d{1,2}pk\s+)?(?:da\s+|de\s+)?bomba\s+(?:d(?:a|e)?['\s]+)?agua\b", "polia bomba de agua"),
        (r"\btapa[- ]?po\s+(?:(?:do|de)\s+)?cilindro\s+(?:de\s+)?roda\b", "tapa po cilindro de roda"),
        (r"\brolamentos?\s+(?:(?:do|de)\s+)?amortecedor(?:es)?\b", "rolamento de suspensao"),
        (r"\bkit\s+corrente\s+(?:da|de)?\s*bomba\s+(?:de\s+)?oleo\b", "kit corrente bomba de oleo"),
        (r"\bjunta\s+(?:do|da|de)?\s*cabecote\b", "junta do cabecote"),
        (r"\baditivo\s+(?:do|para\s+o)?\s*radiador\b", "aditivo radiador"),
    )
    _PRODUCT_BRAND_ALIASES = {
        "NGK": ("ngk",),
        "Nakata": ("nakata",),
        "Cofap": ("cofap",),
        "Valeo": ("valeo",),
    }

    def __init__(self, *, catalog: PreSearchCatalog) -> None:
        self._part_patterns = list(catalog.part_patterns)
        self._ambiguous_part_aliases = set(catalog.ambiguous_part_aliases)
        self._brand_aliases = dict(catalog.brand_aliases)
        self._model_aliases = dict(catalog.model_aliases)
        self._variant_aliases_by_model = dict(catalog.variant_aliases_by_model)
        self._part_code_patterns = compile_part_code_patterns(catalog.part_code_patterns)
        self._part_alias_candidates = self._build_alias_candidates(self._part_patterns)
        self._max_part_alias_tokens = max(
            (candidate.token_count for candidate in self._part_alias_candidates),
            default=1,
        )

    def extract(
        self,
        message_text: str,
        *,
        last_messages: list[dict[str, Any]] | None = None,
    ) -> SearchCriteria:
        normalized_message = normalize_pre_search_text(message_text)
        intent = self.resolve_request_intent(message_text)
        normalized_context = self._build_context_text(last_messages)

        primary = self._extract_from(intent.text, raw_text=intent.text)
        fallback = self._extract_from(normalized_context, raw_text=normalized_context)
        return self._merge(primary=primary, fallback=fallback)

    def resolve_request_intent(self, message_text: str) -> RequestIntent:
        """Keep an explicit replacement and flag negative requests we cannot prove.

        For example, ``nao quero radiador, quero filtro de oleo`` has one
        affirmative target.  A bare ``nao quero radiador`` does not, so it
        must never become an automated catalog search.
        """
        normalized = normalize_pre_search_text(message_text)
        if not normalized:
            return RequestIntent(text="")

        replacement = re.search(
            r"\bnao\s+(?:quero|preciso|procuro|busco)\s+[^,;.!?]+"
            r"\s*(?:[,;.!?]|\bmas\b)\s*(?:agora\s+)?"
            r"(?:quero|preciso|procuro|busco)\s+(.+)$",
            normalized,
        )
        if replacement:
            return self.resolve_request_intent(replacement.group(1).strip())

        # A direction negated after an affirmative direction is resolved by
        # _extract_position; it is not a negative part request.
        without_directions = re.sub(
            r"\bnao\s+(?:e\s+)?(?:dianteir[oa]s?|traseir[oa]s?|front|rear)\b",
            "",
            normalized,
        ).strip()
        if re.search(r"\bnao\s+(?:quero|preciso|procuro|busco)\b", without_directions):
            return RequestIntent(text=normalized, unresolved_reason="unresolved_negation")
        if re.search(r'\bcom\s+abs\b', normalized) and re.search(r'\bsem\s+abs\b', normalized):
            return RequestIntent(text=normalized, unresolved_reason='contradictory_attribute')
        if (
            without_directions not in {"nao sei", "nao", "nao tenho certeza"}
            and re.search(r"\b(?:nao\s+e\s+\S+|nao\s+\d{1,2}\.\d)\b", without_directions)
        ):
            return RequestIntent(text=normalized, unresolved_reason="unresolved_negation")
        correction = re.search(
            r"\b(?:corrija|corrigindo|correcao)\b\s*[,;:-]?\s*(?:e\s+)?(.+)$",
            normalized,
        )
        if correction and correction.group(1).strip():
            return self.resolve_request_intent(correction.group(1).strip())
        if re.search(r"\b(?:corrija|corrigindo|correcao)\b", normalized):
            return RequestIntent(text=normalized, unresolved_reason="unresolved_correction")
        # Different items can legitimately have different directions. Check
        # each explicit item span, rather than flattening the whole request.
        spans = self._part_spans(normalized)
        segments = [normalized[a[0]:b[0]] for a, b in zip(spans, spans[1:])]
        segments.append(normalized[spans[-1][0]:] if spans else normalized)
        for segment in segments:
            affirmative = re.sub(
                r"\bnao\s+(?:e\s+)?(?:diant|tras|esq|dir|dianteir[oa]s?|traseir[oa]s?|esquerd[oa]s?|direit[oa]s?)\b",
                "", segment,
            )
            if (
                re.search(r"\b(?:diant|dianteir[oa]s?)\b", affirmative)
                and re.search(r"\b(?:tras|traseir[oa]s?)\b", affirmative)
            ) or (
                re.search(r"\besquerd[oa]s?\b", affirmative)
                and re.search(r"\bdireit[oa]s?\b", affirmative)
            ):
                return RequestIntent(text=normalized, unresolved_reason="contradictory_direction")
        return RequestIntent(text=normalized)

    def canonicalize_part_query(self, value: str | None) -> str | None:
        normalized_value = normalize_pre_search_text(value)
        if not normalized_value:
            return None
        if normalized_value in {key for key, _ in self._part_patterns}:
            return normalized_value
        return self._extract_part_query(normalized_value)

    def ambiguous_part_alias(self, text: str) -> str | None:
        normalized = normalize_pre_search_text(text)
        matches = [alias for alias in self._ambiguous_part_aliases
                   if re.search(rf'\b{re.escape(alias)}\b', normalized)]
        if not matches:
            return None
        best = max(matches, key=lambda value: (len(value.split()), len(value)))
        exact = self._extract_exact_part_query_match(normalized)
        if exact and (exact.token_count, exact.char_count) > (len(best.split()), len(best)):
            return None
        return best

    def needs_component_confirmation(self, part_query: str | None) -> bool:
        protected = {canonical for _, canonical in self._COMPOSITE_PART_PATTERNS}
        known = {part for part, _ in self._part_patterns}
        return bool(part_query and (part_query in protected or part_query.startswith('conjunto ')) and part_query not in known)

    def extract_items(self, message_text: str) -> list[SearchCriteria]:
        """Extract independent part requests without crossing vehicle evidence.

        Vehicle attributes belong to the clause where they occur.  The only
        exception is an explicit common application at the end of a request,
        such as ``radiador e pastilha para Gol 2010``: in that form every
        earlier item is explicitly governed by the same final vehicle phrase.
        """
        intent = self.resolve_request_intent(message_text)
        normalized = intent.text
        if not normalized or intent.unresolved_reason:
            return []
        anchored_items = self._extract_items_from_part_spans(normalized)
        if anchored_items:
            return anchored_items

        clauses = [part.strip() for part in re.split(r"[,;]|\s+e\s+", normalized) if part.strip()]
        shared_vehicle = self._extract_explicit_shared_vehicle(clauses)
        items: list[SearchCriteria] = []
        seen: set[tuple[object, ...]] = set()
        for clause in clauses:
            part_query = self._extract_part_query(clause)
            if not part_query:
                continue
            local = self._extract_from(clause, raw_text=clause)
            values = local.model_dump(exclude_none=False)
            for field_name in (
                "vehicle_brand",
                "vehicle_model",
                "vehicle_year",
                "engine",
            ):
                if values.get(field_name) in (None, "", []) and shared_vehicle:
                    values[field_name] = getattr(shared_vehicle, field_name)
            item = SearchCriteria.model_validate(values)
            key = self._item_identity_key(item)
            if key not in seen:
                seen.add(key)
                items.append(item)
        return items

    def _extract_items_from_part_spans(self, normalized: str) -> list[SearchCriteria]:
        """Use each non-overlapping catalog alias as an item boundary.

        Commercial requests often list pieces with only spaces between them.
        Splitting on conjunctions reduces that list to one family. Exact alias
        spans preserve the catalog vocabulary while the text between spans
        remains local to the corresponding item.
        """
        anchors = self._part_spans(normalized)
        if len(anchors) < 2:
            return []

        prefix = self._extract_from(normalized[: anchors[0][0]], raw_text=normalized[: anchors[0][0]])
        suffix = self._extract_from(normalized[anchors[-1][1] :], raw_text=normalized[anchors[-1][1] :])
        shared_vehicle = self._shared_vehicle_outside_part_spans(prefix=prefix, suffix=suffix)
        items: list[SearchCriteria] = []
        seen: set[tuple[object, ...]] = set()
        for index, (start, _end, candidate) in enumerate(anchors):
            next_start = anchors[index + 1][0] if index + 1 < len(anchors) else len(normalized)
            segment = normalized[start:next_start]
            local = self._extract_from(segment, raw_text=segment)
            values = local.model_dump(exclude_none=False)
            values["part_query"] = candidate.canonical
            quantity = self._extract_quantity_before_part(normalized, start)
            if quantity is not None:
                values["quantity"] = quantity
            # Only an item without its own application inherits a shared one.
            if shared_vehicle is not None and not values.get("vehicle_model") and not values.get("vehicle_brand"):
                for field in ("vehicle_brand", "vehicle_model", "vehicle_year", "engine"):
                    if values.get(field) in (None, "", []):
                        values[field] = getattr(shared_vehicle, field)
            item = SearchCriteria.model_validate(values)
            key = self._item_identity_key(item)
            if key not in seen:
                seen.add(key)
                items.append(item)
        return items

    def _part_spans(self, normalized: str) -> list[tuple[int, int, _AliasCandidate]]:
        """Protect a component from aliases contained inside its name."""
        matches: list[tuple[int, int, _AliasCandidate]] = []
        for pattern, canonical in self._COMPOSITE_PART_PATTERNS:
            for match in re.finditer(pattern, normalized):
                alias = match.group()
                matches.append((match.start(), match.end(), _AliasCandidate(
                    canonical=canonical, alias=alias,
                    token_count=len(alias.split()), char_count=len(alias),
                )))
        for candidate in self._part_alias_candidates:
            for match in re.finditer(rf"\b{re.escape(candidate.alias)}\b", normalized):
                matches.append((match.start(), match.end(), candidate))
        matches.sort(key=lambda item: (item[0], -(item[1] - item[0])))
        anchors: list[tuple[int, int, _AliasCandidate]] = []
        for match in matches:
            if anchors and match[0] < anchors[-1][1]:
                continue
            anchors.append(match)
        return anchors

    @staticmethod
    def _shared_vehicle_outside_part_spans(
        *,
        prefix: SearchCriteria,
        suffix: SearchCriteria,
    ) -> SearchCriteria | None:
        vehicle_fields = ("vehicle_brand", "vehicle_model", "vehicle_year", "engine")
        prefix_has_vehicle = any(getattr(prefix, field_name) is not None for field_name in vehicle_fields)
        suffix_has_vehicle = any(getattr(suffix, field_name) is not None for field_name in vehicle_fields)
        if prefix_has_vehicle and not suffix_has_vehicle:
            return prefix
        if suffix_has_vehicle and not prefix_has_vehicle:
            return suffix
        return None

    @staticmethod
    def _extract_quantity_before_part(text: str, part_start: int) -> int | None:
        # A short count immediately before a catalog alias is explicit list
        # evidence ("2 disco de freio"). Years and engine sizes cannot match
        # this bounded form.
        prefix = text[max(0, part_start - 16) : part_start]
        explicit_quantity = DictionaryPreSearchExtractor._extract_quantity(prefix)
        if explicit_quantity is not None:
            return explicit_quantity
        match = re.search(r"\b([1-9])\s+(?:(?:kit|jogo|par)\s*)?$", prefix)
        if match:
            return int(match.group(1))
        if re.search(r"\bpar\s+(?:de\s+)?$", prefix):
            return 2
        return None

    @staticmethod
    def _item_identity_key(item: SearchCriteria) -> tuple[object, ...]:
        """Keep repetitions that differ in vehicle or product criteria."""
        return tuple(item.model_dump(exclude_none=False).items())

    def _extract_explicit_shared_vehicle(
        self,
        clauses: list[str],
    ) -> SearchCriteria | None:
        """Recognize only a trailing vehicle application shared by all items."""
        if len(clauses) < 2:
            return None

        local_criteria = [self._extract_from(clause, raw_text=clause) for clause in clauses]
        vehicle_fields = ("vehicle_brand", "vehicle_model", "vehicle_year", "engine")
        final = local_criteria[-1]
        if not any(getattr(final, field_name) is not None for field_name in vehicle_fields):
            return None
        if any(
            any(getattr(criteria, field_name) is not None for field_name in vehicle_fields)
            for criteria in local_criteria[:-1]
        ):
            return None
        # The final clause must contain a part too. A bare value after "e" is
        # not enough evidence that it applies to every previous item.
        if not final.part_query:
            return None
        return final

    def has_exact_part_query_match(
        self,
        *,
        message_text: str,
        canonical_part_query: str | None,
    ) -> bool:
        normalized_text = normalize_pre_search_text(message_text)
        normalized_canonical = normalize_pre_search_text(canonical_part_query)
        if not normalized_text or not normalized_canonical:
            return False
        for pattern, canonical in self._COMPOSITE_PART_PATTERNS:
            if re.search(pattern, normalized_text) and canonical == normalized_canonical:
                return canonical in {part for part, _ in self._part_patterns}
        match = self._extract_exact_part_query_match(normalized_text)
        return bool(match and match.canonical == normalized_canonical)

    def _extract_from(self, normalized_text: str, *, raw_text: str) -> SearchCriteria:
        # An explicit application after a product description owns its vehicle
        # fields. Model/year tokens in the title remain product context.
        vehicle_text = normalized_text
        for marker in re.finditer(r"\b(?:para|pro|pra)\s+(?:(?:o|a)\s+)?", normalized_text):
            suffix = normalized_text[marker.end():]
            if self._extract_vehicle_model(suffix):
                vehicle_text = suffix
        vehicle_brand = self._extract_vehicle_brand(vehicle_text)
        vehicle_model = self._extract_vehicle_model(vehicle_text, prefer_first=vehicle_text != normalized_text)
        vehicle_year = self._extract_year(vehicle_text)
        if vehicle_year is None and vehicle_model:
            # In catalog requests a two-digit year immediately follows a known
            # model ("Gol 98") frequently enough to be useful. Restrict it to
            # 1980--1999 so a quantity, valve count or displacement is never
            # promoted to an application year.
            short_year = re.search(r"\b(8\d|9\d)\b", vehicle_text)
            if short_year:
                vehicle_year = 1900 + int(short_year.group(1))
        exact_part_match = self._extract_exact_part_query_match(normalized_text)
        quantity = self._extract_quantity(normalized_text)
        if quantity is None and exact_part_match is not None:
            alias_match = re.search(
                rf"\b{re.escape(exact_part_match.alias)}\b",
                normalized_text,
            )
            if alias_match is not None:
                quantity = self._extract_quantity_before_part(
                    normalized_text,
                    alias_match.start(),
                )
        return SearchCriteria(
            part_query=self._extract_part_query(normalized_text),
            part_code=self._extract_part_code(
                raw_text,
                vehicle_brand=vehicle_brand,
                vehicle_model=vehicle_model,
                vehicle_year=vehicle_year,
            ),
            preferred_product_brand=self._extract_preferred_product_brand(normalized_text),
            vehicle_brand=vehicle_brand,
            vehicle_model=vehicle_model,
            vehicle_year=vehicle_year,
            engine=self._extract_engine(vehicle_text),
            side=self._extract_side(normalized_text),
            position=self._extract_position(normalized_text),
            axle=self._extract_axle(normalized_text),
            variant=self._extract_catalog_variant(vehicle_text, vehicle_model) or self._extract_variant(vehicle_text),
            fuel=self._extract_fuel(vehicle_text) if vehicle_model else None,
            transmission=self._extract_transmission(vehicle_text),
            abs=self._extract_abs(normalized_text),
            quantity=quantity,
        )

    @staticmethod
    def _merge(*, primary: SearchCriteria, fallback: SearchCriteria) -> SearchCriteria:
        same_vehicle = not primary.vehicle_model or not fallback.vehicle_model or primary.vehicle_model == fallback.vehicle_model
        same_component = not primary.part_query or not fallback.part_query or primary.part_query == fallback.part_query
        return SearchCriteria(
            part_query=primary.part_query or fallback.part_query,
            part_code=primary.part_code or fallback.part_code,
            preferred_product_brand=(
                primary.preferred_product_brand or fallback.preferred_product_brand
            ),
            vehicle_brand=primary.vehicle_brand or fallback.vehicle_brand,
            vehicle_model=DictionaryPreSearchExtractor._merge_vehicle_model(
                primary.vehicle_model,
                fallback.vehicle_model,
            ),
            vehicle_year=primary.vehicle_year or fallback.vehicle_year,
            engine=primary.engine or fallback.engine,
            side=primary.side or fallback.side,
            position=primary.position or fallback.position,
            axle=primary.axle or fallback.axle,
            variant=primary.variant or fallback.variant,
            fuel=primary.fuel or (fallback.fuel if same_vehicle else None),
            transmission=primary.transmission or (fallback.transmission if same_vehicle else None),
            abs=primary.abs if primary.abs is not None else (fallback.abs if same_component else None),
            quantity=primary.quantity or fallback.quantity,
        )

    @staticmethod
    def _merge_vehicle_model(primary: str | None, fallback: str | None) -> str | None:
        if primary and not DictionaryPreSearchExtractor._is_year_like_model(primary):
            return primary
        return fallback or primary

    @staticmethod
    def _is_year_like_model(value: str | None) -> bool:
        return bool(re.fullmatch(r"(19\d{2}|20\d{2})", str(value or "").strip()))

    def _extract_part_query(self, text: str) -> str | None:
        for pattern, canonical in self._COMPOSITE_PART_PATTERNS:
            if re.search(pattern, text):
                return canonical
        if self.ambiguous_part_alias(text):
            return None
        # Preserve the requested component before resolving a contained family.
        # An unknown kit/support must not silently become the radiator itself.
        component = re.search(
            r"\b(tampas?|kits?|mangueiras?|suportes?|reparos?|conjuntos?)\s+"
            r"(?:(?:de|do|da|dos|das)\s+)?([^,;]+)", text
        )
        if component:
            exact_component = self._extract_exact_part_query_match(text)
            if (
                exact_component and exact_component.token_count > 1
                and exact_component.alias.split()[0].rstrip("s") == component.group(1).rstrip("s")
            ):
                return exact_component.canonical
            target = self._extract_exact_part_query_match(component.group(2))
            if target:
                phrase = component.group(1) + " " + target.alias
                full_match = self._extract_exact_part_query_match(phrase)
                if (
                    full_match and full_match.token_count > 1
                    and full_match.alias.split()[0].rstrip("s") == component.group(1).rstrip("s")
                ):
                    return full_match.canonical
                return phrase
        exact_match = self._extract_exact_part_query_match(text)
        fuzzy_match = self._extract_fuzzy_part_query_match(text)
        if exact_match and fuzzy_match:
            if self._should_prefer_fuzzy_part_match(
                exact_match=exact_match,
                fuzzy_match=fuzzy_match,
            ):
                return fuzzy_match.candidate.canonical
            return exact_match.canonical
        if exact_match:
            return exact_match.canonical
        if fuzzy_match:
            return fuzzy_match.candidate.canonical
        return None

    def _extract_exact_part_query_match(self, text: str) -> _AliasCandidate | None:
        best_match: _AliasCandidate | None = None
        for candidate in self._part_alias_candidates:
            if not re.search(rf"\b{re.escape(candidate.alias)}\b", text):
                continue
            if best_match is None or (
                candidate.token_count,
                candidate.char_count,
            ) > (
                best_match.token_count,
                best_match.char_count,
            ):
                best_match = candidate
        return best_match

    def _extract_fuzzy_part_query_match(self, text: str) -> _ScoredAliasCandidate | None:
        tokens = self._tokenize(text)
        if not tokens or not self._part_alias_candidates:
            return None

        windows_by_size = self._build_token_windows(
            tokens=tokens,
            max_window_size=self._max_part_alias_tokens,
        )
        best_by_canonical: dict[str, _ScoredAliasCandidate] = {}

        for candidate in self._part_alias_candidates:
            candidate_windows = windows_by_size.get(candidate.token_count, ())
            if not candidate_windows:
                continue
            best_score_for_alias: _ScoredAliasCandidate | None = None
            for window in candidate_windows:
                score = self._score_part_alias_window(candidate=candidate, window=window)
                if score is None:
                    continue
                scored_candidate = _ScoredAliasCandidate(
                    candidate=candidate,
                    similarity=score[0],
                    distance=-score[1],
                )
                if best_score_for_alias is None or self._scored_alias_sort_key(
                    scored_candidate
                ) > self._scored_alias_sort_key(best_score_for_alias):
                    best_score_for_alias = scored_candidate
            if best_score_for_alias is None:
                continue

            current_best = best_by_canonical.get(candidate.canonical)
            if current_best is None or self._scored_alias_sort_key(
                best_score_for_alias
            ) > self._scored_alias_sort_key(current_best):
                best_by_canonical[candidate.canonical] = best_score_for_alias

        if not best_by_canonical:
            return None

        ranked = sorted(
            best_by_canonical.values(),
            key=self._scored_alias_sort_key,
            reverse=True,
        )
        best_score = ranked[0]
        if len(ranked) > 1:
            second_score = ranked[1]
            min_gap = (
                self._MULTI_TOKEN_FUZZY_GAP
                if best_score.candidate.token_count > 1
                else self._SINGLE_TOKEN_FUZZY_GAP
            )
            if (best_score.similarity - second_score.similarity) < min_gap:
                return None
        return best_score

    def _extract_vehicle_model(self, text: str, *, prefer_first: bool = False) -> str | None:
        best_match: tuple[int, ...] | None = None
        best_model: str | None = None
        for model, aliases in self._model_aliases.items():
            for alias in aliases:
                candidate = str(alias or "").strip()
                if not candidate:
                    continue
                match = re.search(rf"\b{re.escape(candidate)}\b", text)
                if match is None:
                    continue

                score = ((-match.start(),) if prefer_first else ()) + self._model_alias_score(candidate)
                if best_match is None or score > best_match:
                    best_match = score
                    best_model = model
        return best_model

    def _extract_vehicle_brand(self, text: str) -> str | None:
        for brand, aliases in self._brand_aliases.items():
            for alias in aliases:
                if re.search(rf"\b{re.escape(alias)}\b", text):
                    return brand
        return None

    @classmethod
    def _extract_preferred_product_brand(cls, text: str) -> str | None:
        for brand, aliases in cls._PRODUCT_BRAND_ALIASES.items():
            if any(re.search(rf"\b{re.escape(alias)}\b", text) for alias in aliases):
                return brand
        return None

    @staticmethod
    def _extract_year(text: str) -> int | None:
        match = re.search(r"\b(19\d{2}|20\d{2})\b", text)
        if not match:
            return None
        return int(match.group(1))

    @staticmethod
    def _model_alias_score(alias: str) -> tuple[int, int, int]:
        alias_text = str(alias or "").strip()
        has_letters = 1 if re.search(r"[a-zA-Z]", alias_text) else 0
        is_year_token = 1 if re.fullmatch(r"(19\d{2}|20\d{2})", alias_text) else 0
        return (
            has_letters,
            0 if is_year_token else 1,
            len(alias_text),
        )

    @staticmethod
    def _extract_engine(text: str) -> str | None:
        explicit = re.search(r"\bmotor\s+([1-9][0-9]?\.[0-9])\b", text)
        if explicit:
            return explicit.group(1)
        match = re.search(r"\b([1-6]\.[0-9])\b", text)
        if not match:
            return None
        return match.group(1)

    @staticmethod
    def _extract_side(text: str) -> str | None:
        text = re.sub(r'\bnao\s+(?:e\s+)?(?:esq|dir|esquerd[oa]|direit[oa])\b','',text)
        has_left = bool(re.search(r"\b(?:le|esq|esquerd[oa])\b", text))
        has_right = bool(re.search(r"\b(?:ld|dir|direit[oa])\b", text))
        if has_left and has_right:
            return None
        if has_left:
            return "left"
        if has_right:
            return "right"
        return None

    @staticmethod
    def _extract_position(text: str) -> str | None:
        # "eixo dianteiro/traseiro" belongs to axle, not position.
        if re.search(r"\b(eixo\s+diant|eixo\s+dianteir[oa]|eixo\s+tras|eixo\s+traseir[oa])\b", text):
            return None
        affirmative_text = re.sub(
            r"\bnao\s+(?:e\s+)?(?:diant|tras|dianteir[oa]|traseir[oa]|front|rear)\b",
            "",
            text,
        )
        return canonicalize_longitudinal_direction(affirmative_text)

    @staticmethod
    def _extract_axle(text: str) -> str | None:
        if re.search(r"\b(eixo dianteir[oa]|eixo diant)\b", text):
            return "front"
        if re.search(r"\b(eixo traseir[oa]|eixo tras)\b", text):
            return "rear"
        return None

    @staticmethod
    def _extract_variant(text: str) -> str | None:
        oil_viscosity = re.search(r"\b(\d{1,2})\s*w\s*-?\s*(\d{2})\b", text)
        if oil_viscosity:
            return f"{oil_viscosity.group(1)}W{oil_viscosity.group(2)}"

        return None

    @staticmethod
    def _extract_fuel(text: str) -> str | None:
        for value in ('flex', 'diesel', 'gasolina', 'etanol'):
            if re.search(rf'\b{value}\b', text):
                return value
        return None

    @staticmethod
    def _extract_transmission(text: str) -> str | None:
        # Manual may describe the pump/tool, not the vehicle transmission.
        if re.search(r'\bdualogic\b', text):
            return 'dualogic'
        if re.search(r'\b(?:cambio|transmissao)\s+(?:automatic[oa]|at)\b', text):
            return 'automatico'
        if re.search(r'\b(?:cambio|transmissao)\s+(?:manual|mt)\b', text):
            return 'manual'
        return None

    @staticmethod
    def _extract_abs(text: str) -> bool | None:
        if re.search(r'\b(?:sem|s\s*/|nao tem|nao possui)\s*abs\b', text):
            return False
        if re.search(r'\b(?:com|c\s*/)\s*abs\b', text):
            return True
        return None

    def _extract_catalog_variant(self, text: str, model: str | None) -> str | None:
        matches = {
            variant for variant, alias in self._variant_aliases_by_model.get(normalize_pre_search_text(model), [])
            if re.search(rf"\b{re.escape(alias)}\b", text)
        }
        return next(iter(matches)) if len(matches) == 1 else None

    @staticmethod
    def _extract_quantity(text: str) -> int | None:
        # A bare number is never enough in automotive text: it may be a year,
        # model, engine displacement, valve count or product specification.
        explicit_patterns = (
            r"\b(\d{1,3})\s*(?:unid(?:ade|ades)?|pecas?|itens?|unidades?)\b",
            r"\b(\d{1,3})\s*x\s*(?:pecas?|itens?|unid(?:ade|ades)?)\b",
            r"\b(?:quantidade|qtd|qtde)\s*[:=]?\s*(\d{1,3})\b",
        )
        for pattern in explicit_patterns:
            match = re.search(pattern, text)
            if match:
                value = int(match.group(1))
                if 1 <= value <= 50:
                    return value
        return None

    def _extract_part_code(
        self,
        text: str,
        *,
        vehicle_brand: str | None,
        vehicle_model: str | None,
        vehicle_year: int | None,
    ) -> str | None:
        for pattern in self._part_code_patterns:
            for match in pattern.finditer(text or ""):
                candidate = normalize_part_code_candidate(match.group(0))
                if not has_literal_part_code_evidence(
                    candidate,
                    message_text=text,
                ):
                    continue
                if not is_valid_part_code_candidate(
                    candidate,
                    compiled_patterns=self._part_code_patterns,
                    vehicle_brand=vehicle_brand,
                    vehicle_model=vehicle_model,
                    vehicle_year=vehicle_year,
                ):
                    continue
                return candidate
        return None

    @staticmethod
    def _build_context_text(last_messages: list[dict[str, Any]] | None) -> str:
        if not last_messages:
            return ""
        merged_text: list[str] = []
        for message in last_messages:
            role = str(message.get("role", "")).strip().lower()
            if role and role != "user":
                continue
            text = str(message.get("text", "")).strip()
            if text:
                merged_text.append(text)
        return normalize_pre_search_text(" ".join(merged_text))

    @staticmethod
    def _build_alias_candidates(
        part_patterns: list[tuple[str, tuple[str, ...]]],
    ) -> tuple[_AliasCandidate, ...]:
        candidates: list[_AliasCandidate] = []
        seen: set[tuple[str, str]] = set()
        for canonical, aliases in part_patterns:
            canonical_text = str(canonical or "").strip().lower()
            if not canonical_text:
                continue
            for alias in (canonical_text, *aliases):
                alias_text = str(alias or "").strip().lower()
                if not alias_text:
                    continue
                key = (canonical_text, alias_text)
                if key in seen:
                    continue
                seen.add(key)
                candidates.append(
                    _AliasCandidate(
                        canonical=canonical_text,
                        alias=alias_text,
                        token_count=len(alias_text.split()),
                        char_count=len(alias_text),
                    )
                )
        return tuple(sorted(candidates, key=lambda item: (item.token_count, item.char_count), reverse=True))

    @staticmethod
    def _tokenize(text: str) -> list[str]:
        return [token for token in re.findall(r"[a-z0-9]+", text or "") if token]

    @classmethod
    def _build_token_windows(
        cls,
        *,
        tokens: list[str],
        max_window_size: int,
    ) -> dict[int, tuple[str, ...]]:
        windows: dict[int, list[str]] = {}
        if not tokens:
            return {}
        upper_bound = max(1, min(max_window_size, len(tokens)))
        for window_size in range(1, upper_bound + 1):
            values = [
                " ".join(tokens[start : start + window_size])
                for start in range(0, len(tokens) - window_size + 1)
            ]
            windows[window_size] = values
        return {size: tuple(values) for size, values in windows.items()}

    @classmethod
    def _score_part_alias_window(
        cls,
        *,
        candidate: _AliasCandidate,
        window: str,
    ) -> tuple[float, int, int] | None:
        if not window or window == candidate.alias:
            return None
        if candidate.char_count < cls._MIN_FUZZY_TOKEN_LENGTH:
            return None
        if len(window) < cls._MIN_FUZZY_TOKEN_LENGTH:
            return None
        if not cls._matching_initials(candidate.alias, window):
            return None

        max_distance = cls._max_part_alias_distance(candidate)
        if abs(candidate.char_count - len(window)) > max_distance:
            return None

        distance = cls._damerau_levenshtein_distance(candidate.alias, window)
        if distance <= 0 or distance > max_distance:
            return None

        similarity = 1.0 - (distance / max(candidate.char_count, len(window)))
        min_similarity = cls._min_part_alias_similarity(candidate)
        if similarity < min_similarity:
            return None

        return (round(similarity, 4), -distance, candidate.token_count)

    @staticmethod
    def _matching_initials(alias: str, window: str) -> bool:
        alias_tokens = alias.split()
        window_tokens = window.split()
        if len(alias_tokens) != len(window_tokens):
            return False
        return all(
            alias_token and window_token and alias_token[0] == window_token[0]
            for alias_token, window_token in zip(alias_tokens, window_tokens)
        )

    @staticmethod
    def _max_part_alias_distance(candidate: _AliasCandidate) -> int:
        if candidate.token_count > 1:
            return 2 if candidate.char_count <= 14 else 3
        if candidate.char_count <= 5:
            return 1
        return 2

    @staticmethod
    def _min_part_alias_similarity(candidate: _AliasCandidate) -> float:
        if candidate.token_count > 1:
            return 0.84 if candidate.char_count <= 14 else 0.8
        if candidate.char_count <= 5:
            return 0.8
        return 0.82

    @staticmethod
    def _should_prefer_fuzzy_part_match(
        *,
        exact_match: _AliasCandidate,
        fuzzy_match: _ScoredAliasCandidate,
    ) -> bool:
        fuzzy_candidate = fuzzy_match.candidate
        if fuzzy_match.similarity < 0.9:
            return False
        if fuzzy_candidate.token_count > exact_match.token_count:
            return True
        return fuzzy_candidate.char_count >= (exact_match.char_count + 4)

    @staticmethod
    def _scored_alias_sort_key(match: _ScoredAliasCandidate) -> tuple[float, int, int, int]:
        return (
            match.similarity,
            -match.distance,
            match.candidate.token_count,
            match.candidate.char_count,
        )

    @staticmethod
    def _damerau_levenshtein_distance(left: str, right: str) -> int:
        left_text = str(left or "")
        right_text = str(right or "")
        if left_text == right_text:
            return 0
        if not left_text:
            return len(right_text)
        if not right_text:
            return len(left_text)

        previous_previous_row: list[int] | None = None
        previous_row = list(range(len(right_text) + 1))

        for left_index, left_char in enumerate(left_text, start=1):
            current_row = [left_index]
            for right_index, right_char in enumerate(right_text, start=1):
                insertion = current_row[right_index - 1] + 1
                deletion = previous_row[right_index] + 1
                substitution = previous_row[right_index - 1] + (0 if left_char == right_char else 1)
                current = min(insertion, deletion, substitution)

                if (
                    previous_previous_row is not None
                    and left_index > 1
                    and right_index > 1
                    and left_char == right_text[right_index - 2]
                    and left_text[left_index - 2] == right_char
                ):
                    current = min(current, previous_previous_row[right_index - 2] + 1)

                current_row.append(current)
            previous_previous_row = previous_row
            previous_row = current_row

        return previous_row[-1]
