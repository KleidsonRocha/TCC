from typing import Any, Literal

from pydantic import BaseModel, Field

from app.core.domain.models import ConversationState


class ChannelInfo(BaseModel):
    name: str | None = None


class MessagePayload(BaseModel):
    text: str = Field(max_length=2_000)


class ContextMessage(BaseModel):
    role: Literal["user", "assistant"] | str
    text: str = Field(max_length=2_000)


class ConversationContext(BaseModel):
    last_messages: list[ContextMessage] = Field(default_factory=list, max_length=20)
    conversation_state: ConversationState | None = None


class RuntimeInfo(BaseModel):
    locale: str | None = None
    timezone: str | None = None


class BusinessInfo(BaseModel):
    branch_id: int


class AgentRequestV1(BaseModel):
    schema_version: str = Field(max_length=16)
    trace_id: str = Field(max_length=128)
    conversation_id: str = Field(max_length=256)
    message: MessagePayload
    business: BusinessInfo
    channel: ChannelInfo | None = None
    context: ConversationContext | None = None
    runtime: RuntimeInfo | None = None


class ReplyPayload(BaseModel):
    text: str


class HandoffPayload(BaseModel):
    required: bool = False
    reason: str | None = None


class ToolTracePayload(BaseModel):
    used_tools: list[str] = Field(default_factory=list)
    latency_ms: float = 0.0
    stage_latency_ms: dict[str, float] = Field(default_factory=dict)
    pre_search_path: str | None = None


class AgentResponseV1(BaseModel):
    schema_version: str = "1.0"
    trace_id: str
    conversation_id: str
    reply: ReplyPayload
    actions: list[dict[str, Any]] = Field(default_factory=list)
    handoff: HandoffPayload = Field(default_factory=HandoffPayload)
    confidence: float = Field(
        0.0, ge=0.0, le=1.0,
        description="Indicador heurístico do fluxo de atendimento, não calibrado. "
        "Não representa probabilidade de encaixe, preço ou estoque. "
        "A relevância dos candidatos é indicada separadamente por score.",
    )
    tool_trace: ToolTracePayload
    conversation_state: ConversationState | None = None
    item_results: list[dict[str, Any]] | None = None
