"""Apply versioned lexical aliases without replacing catalog or review data.

Default is a rollback preview. Schema comes from the consolidated bootstrap.
"""

import argparse
import csv
from pathlib import Path

import psycopg

from app.config import Settings
from app.infra.postgres_conninfo import build_catalog_conninfo
from app.infra.pre_search_text import normalize_pre_search_text


def apply_updates(conn, root: Path) -> dict[str, int]:
    sql = (root / "pre_search_init.sql").read_text(encoding="utf-8")
    schema = sql.split("-- BEGIN VARIANT ALIAS SCHEMA", 1)[1].split("-- END VARIANT ALIAS SCHEMA", 1)[0]
    conn.execute(schema)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS pre_search_part_family_scope (
            family_key TEXT NOT NULL,
            source_group_code INTEGER NOT NULL,
            source_subgroup_code INTEGER NOT NULL,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_by TEXT NOT NULL DEFAULT 'seed',
            PRIMARY KEY (family_key, source_group_code, source_subgroup_code)
        )
    """)
    counts = {"part_aliases": 0, "variant_aliases": 0, "family_scopes": 0, "part_rules": 0}
    curation_schema = sql.split('-- BEGIN FAMILY CURATION SCHEMA', 1)[1].split('-- END FAMILY CURATION SCHEMA', 1)[0]
    conn.execute(curation_schema)
    with (root / 'csv/pre_search_family_concept.csv').open(encoding='utf-8', newline='') as source:
        for row in csv.DictReader(source, delimiter=';'):
            columns = list(row)
            values = []
            for key, value in row.items():
                if key in {'source_families', 'aliases'}:
                    value = value.split('|') if value else []
                elif key.startswith('needs_') or key == 'generic_ambiguous_parts':
                    value = value.lower() == 'true' if value else None
                values.append(value or None if key == 'title_pattern' else value)
            conn.execute('INSERT INTO pre_search_family_concept (' + ','.join(columns) + ') VALUES ('
                + ','.join(['%s'] * len(columns)) + ') ON CONFLICT (family_key) DO UPDATE SET '
                + ','.join(key+'=EXCLUDED.'+key for key in columns if key != 'family_key') + ',is_active=TRUE', values)
    with (root / 'csv/pre_search_alias_decision.csv').open(encoding='utf-8', newline='') as source:
        for row in csv.DictReader(source):
            conn.execute('''INSERT INTO pre_search_alias_decision (alias_normalized,family_key,reason)
                VALUES (%s,%s,%s) ON CONFLICT (alias_normalized) DO UPDATE SET
                family_key=EXCLUDED.family_key,reason=EXCLUDED.reason,is_active=TRUE''',
                (row['alias_normalized'], row['family_key'] or None, row['reason']))
    with (root / 'csv/pre_search_family_scope.csv').open(encoding='utf-8', newline='') as source:
        scope_rows = list(csv.DictReader(source))
    for row in scope_rows:
        family, group, subgroup = row['family_key'], int(row['source_group_code']), int(row['source_subgroup_code'])
        conn.execute(
            """INSERT INTO pre_search_part_family_scope
               (family_key, source_group_code, source_subgroup_code, updated_by)
               VALUES (%s,%s,%s,'seed_csv') ON CONFLICT
               (family_key, source_group_code, source_subgroup_code)
               DO UPDATE SET is_active=TRUE,updated_at=NOW(),updated_by='seed_csv'""",
            (family, group, subgroup),
        )
        counts["family_scopes"] += 1
    with (root / "csv/pre_search_part_rule.csv").open(encoding="utf-8", newline="") as source:
        for row in csv.DictReader(source, delimiter=";"):
            conn.execute(
                """INSERT INTO pre_search_part_rule
                   (part_type_id,is_generic,needs_side,needs_position,needs_axle,needs_engine,needs_variant,updated_by)
                   SELECT pt.id,%s,%s,%s,%s,%s,%s,'seed_csv'
                   FROM pre_search_part_type pt JOIN pre_search_part_group pg ON pg.id=pt.part_group_id
                   WHERE pg.source_group_code=%s AND pt.source_subgroup_code=%s
                   ON CONFLICT (part_type_id) DO UPDATE SET
                     is_generic=EXCLUDED.is_generic,needs_side=EXCLUDED.needs_side,
                     needs_position=EXCLUDED.needs_position,needs_axle=EXCLUDED.needs_axle,
                     needs_engine=EXCLUDED.needs_engine,needs_variant=EXCLUDED.needs_variant,
                     updated_at=NOW(),updated_by='seed_csv'""",
                (
                    row["is_generic"].lower() == "true",
                    row["needs_side"].lower() == "true",
                    row["needs_position"].lower() == "true",
                    row["needs_axle"].lower() == "true",
                    row["needs_engine"].lower() == "true",
                    row["needs_variant"].lower() == "true",
                    int(row["cd_grupo"]),
                    int(row["part_type_id"]),
                ),
            )
            counts["part_rules"] += 1
    with (root / "csv/pre_search_part_alias.csv").open(encoding="utf-8", newline="") as source:
        for row in csv.DictReader(source):
            target = conn.execute(
                """SELECT pt.id FROM pre_search_part_type pt JOIN pre_search_part_group pg
                   ON pg.id=pt.part_group_id WHERE pg.source_group_code=%s
                   AND pt.source_subgroup_code=%s""",
                (int(row["cd_grupo"]), int(row["cd_subgrupo"])),
            ).fetchone()
            if target is None:
                raise ValueError(f"Familia ausente: {row['cd_grupo']}/{row['cd_subgrupo']}")
            conn.execute(
                """INSERT INTO pre_search_part_alias (part_type_id,alias,alias_normalized,updated_by)
                   VALUES (%s,%s,%s,'seed_csv') ON CONFLICT (part_type_id,alias_normalized)
                   DO UPDATE SET alias=EXCLUDED.alias,is_active=TRUE,updated_by='seed_csv',updated_at=NOW()""",
                (target[0], row["alias"], normalize_pre_search_text(row["alias"])),
            )
            counts["part_aliases"] += 1
    with (root / "csv/pre_search_variant_alias.csv").open(encoding="utf-8", newline="") as source:
        for row in csv.DictReader(source):
            model = normalize_pre_search_text(row["model_normalized"])
            if conn.execute("SELECT 1 FROM pre_search_model WHERE name_normalized=%s", (model,)).fetchone() is None:
                raise ValueError(f"Modelo ausente: {model}")
            conn.execute(
                """INSERT INTO pre_search_variant_alias (model_normalized,variant,alias_normalized)
                   VALUES (%s,%s,%s) ON CONFLICT (model_normalized,alias_normalized)
                   DO UPDATE SET variant=EXCLUDED.variant,is_active=TRUE""",
                (model, row["variant"], normalize_pre_search_text(row["alias_normalized"])),
            )
            counts["variant_aliases"] += 1
    return counts


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    with psycopg.connect(build_catalog_conninfo(Settings()), autocommit=True) as conn:
        with conn.transaction(force_rollback=not args.apply):
            counts = apply_updates(conn, Path("db/init"))
    print({"applied": args.apply, **counts})


if __name__ == "__main__":
    main()
