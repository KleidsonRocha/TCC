import logging

import pytest

from app.config import Settings
from app.core.domain.errors import SearchPartsServiceUnavailableError
from app.core.domain.pre_search import SearchCriteria
from app.infra.erp_search_tools_pg import (
    FallbackErpSearchTools,
    PostgresErpSearchTools,
    resolve_search_tools,
)
from app.infra import erp_search_tools_pg


class _FakeCursor:
    def __init__(self, rows):
        self.rows = rows
        self.executed_sql = None
        self.executed_params = None

    def execute(self, sql, params):
        self.executed_sql = sql
        self.executed_params = params

    def fetchall(self):
        return self.rows

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


class _FakeConnection:
    def __init__(self, cursor):
        self._cursor = cursor

    def cursor(self):
        return self._cursor

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


class _SequenceCursor(_FakeCursor):
    def __init__(self, responses):
        super().__init__([])
        self.responses = iter(responses)
        self.calls = []

    def execute(self, sql, params):
        super().execute(sql, params)
        self.calls.append((sql, params))
        response = next(self.responses)
        if isinstance(response, Exception):
            raise response
        self.rows = response


@pytest.mark.parametrize('available', [True, False])
def test_contextual_follow_up_proof_is_read_only_exact_and_does_not_relax(monkeypatch, available):
    cursor = _SequenceCursor([[{'option_exists': available}]])
    options=[]
    def connect(*args, **kwargs):
        options.append(kwargs['options'])
        return _FakeConnection(cursor)
    monkeypatch.setattr(erp_search_tools_pg, 'psycopg', type('Driver', (), {'connect': staticmethod(connect)}))
    monkeypatch.setattr(erp_search_tools_pg, 'dict_row', object())
    criteria=SearchCriteria(part_query='semi eixo', vehicle_model='S10',vehicle_year=2017,engine='2.5',side='left',axle='front')
    tools=PostgresErpSearchTools(settings=_settings(),logger=logging.getLogger('test'))
    value='LTZ 2.5 FLEX 4X4 CD AT'
    result=tools.resolve_follow_up_value(criteria=criteria,field='variant',value=value)
    assert result==(value if available else None)
    assert len(cursor.calls)==1
    sql,params=cursor.calls[0]
    assert params['vehicle_model_norm']=='s10' and params['vehicle_year']==2017
    assert params['engine_norm']=='2.5' and params['variant_norm']==value.lower()
    assert criteria.side=='left' and criteria.axle=='front'
    assert params['limit']==1
    assert 'item_search_candidates' not in sql and 'variant_name' in sql
    assert 'item_search_applications' in sql
    assert 'default_transaction_read_only=on' in options[0]
    assert criteria.variant is None


def test_contextual_follow_up_failure_uses_existing_source_fallback():
    class Source:
        def __init__(self,fail):self.fail=fail;self.calls=0
        def resolve_follow_up_value(self,**kw):
            self.calls+=1
            if self.fail:raise SearchPartsServiceUnavailableError('unavailable')
            return kw['value']
    primary,fallback=Source(True),Source(False)
    tools=FallbackErpSearchTools(primary=primary,fallback=fallback,logger=logging.getLogger('test'))
    assert tools.resolve_follow_up_value(criteria=SearchCriteria(),field='variant',value='ELX RST III')=='ELX RST III'
    assert primary.calls==fallback.calls==1


def test_contextual_follow_up_zero_is_not_source_failure():
    class Source:
        def __init__(self):self.calls=0
        def resolve_follow_up_value(self,**kw):self.calls+=1;return None
    primary,fallback=Source(),Source()
    tools=FallbackErpSearchTools(primary=primary,fallback=fallback,logger=logging.getLogger('test'))
    assert tools.resolve_follow_up_value(criteria=SearchCriteria(),field='variant',value='unknown') is None
    assert primary.calls==1 and fallback.calls==0


@pytest.mark.parametrize('field,value', [('vehicle_model','4X4'),('variant','x'*201),('engine','')])
def test_contextual_follow_up_rejects_unsupported_or_unbounded_input(field,value):
    tools=PostgresErpSearchTools(settings=_settings(),logger=logging.getLogger('test'))
    assert tools.resolve_follow_up_value(criteria=SearchCriteria(),field=field,value=value) is None


@pytest.mark.parametrize("directions", [
    {"side": "right"}, {"position": "front"},
    {"side": "right", "position": "front"},
])
@pytest.mark.parametrize("recovered", [True, False])
def test_directional_fallback_retries_once_preserving_other_criteria(
    monkeypatch, directions, recovered,
):
    strict_trace = {"raw_candidates_count": 3, "ranked_candidates_count": 0}
    relaxed_trace = {"ranked_candidates_count": int(recovered)}
    relaxed_rows = [{"item_code": None, "search_diagnostics": relaxed_trace}]
    if recovered:
        relaxed_rows.append({"item_code": "531.2124", "title": "BIELETA S10 LD/LE", "score": 0.64})
    cursor = _SequenceCursor([
        [{"item_code": None, "search_diagnostics": strict_trace}], relaxed_rows,
    ])
    monkeypatch.setattr(erp_search_tools_pg, "psycopg", type("Driver", (), {
        "connect": staticmethod(lambda *args, **kwargs: _FakeConnection(cursor)),
    }))
    monkeypatch.setattr(erp_search_tools_pg, "dict_row", object())
    criteria = SearchCriteria(
        part_query="bieletas", vehicle_brand="Chevrolet", vehicle_model="S10",
        vehicle_year=2009, engine="2.4", variant="LT", axle="front",
        preferred_product_brand="Nakata", quantity=2, **directions,
    )
    before = criteria.model_dump()
    tools = PostgresErpSearchTools(settings=_settings(), logger=logging.getLogger("test"))
    items = tools.search_parts("bieleta S10", 1, criteria)

    assert [item.item_id for item in items] == (["531.2124"] if recovered else [])
    assert len(cursor.calls) == 2
    strict_sql, strict_params = cursor.calls[0]
    relaxed_sql, relaxed_params = cursor.calls[1]
    for field in directions:
        assert f"%({field}_pattern)s" in strict_sql
        assert f"%({field}_pattern)s" not in relaxed_sql
        assert relaxed_params["score_" + field] == 0
    for key in ("part_query_norm", "vehicle_brand_norm", "vehicle_model_norm", "vehicle_year",
                "engine_norm", "variant_norm", "axle_like", "accessory_head_pattern",
                "preferred_product_brand_like", "limit"):
        assert relaxed_params[key] == strict_params[key]
    assert criteria.model_dump() == before
    diagnostics = tools.get_last_search_diagnostics()
    fallback = diagnostics["directional_fallback"]
    assert fallback["relaxed_fields"] == list(directions)
    assert fallback["requested_criteria"] == criteria.model_dump(exclude_none=True)
    assert fallback["strict_search_diagnostics"] == strict_trace
    assert fallback["results_count"] == int(recovered)
    assert "side" not in diagnostics["criteria"]
    assert "position" not in diagnostics["criteria"]


@pytest.mark.parametrize("criteria,rows", [
    (SearchCriteria(part_query="bieletas", side="right"),
     [{"item_code": "OK", "title": "BIELETA DIREITA", "score": 0.7}]),
    (SearchCriteria(part_query="bieletas"), []),
    (SearchCriteria(part_query="bieletas", axle="front"), []),
])
def test_directional_fallback_does_not_repeat_success_or_non_directional_search(monkeypatch, criteria, rows):
    cursor = _SequenceCursor([rows])
    monkeypatch.setattr(erp_search_tools_pg, "psycopg", type("Driver", (), {
        "connect": staticmethod(lambda *args, **kwargs: _FakeConnection(cursor)),
    }))
    monkeypatch.setattr(erp_search_tools_pg, "dict_row", object())
    tools = PostgresErpSearchTools(settings=_settings(), logger=logging.getLogger("test"))
    tools.search_parts("bieleta", 1, criteria)
    assert len(cursor.calls) == 1


@pytest.mark.parametrize("responses", [
    [RuntimeError("strict query failed")],
    [[], RuntimeError("relaxed query failed")],
])
def test_directional_fallback_preserves_service_unavailable_on_query_error(monkeypatch, responses):
    cursor = _SequenceCursor(responses)
    monkeypatch.setattr(erp_search_tools_pg, "psycopg", type("Driver", (), {
        "connect": staticmethod(lambda *args, **kwargs: _FakeConnection(cursor)),
    }))
    monkeypatch.setattr(erp_search_tools_pg, "dict_row", object())
    tools = PostgresErpSearchTools(settings=_settings(), logger=logging.getLogger("test"))
    with pytest.raises(SearchPartsServiceUnavailableError):
        tools.search_parts("bieleta", 1, SearchCriteria(part_query="bieletas", side="right"))
    assert len(cursor.calls) == len(responses)
    assert tools.get_last_search_diagnostics() is None


def _settings() -> Settings:
    return Settings(
        APP_ENV="test",
        LOG_LEVEL="INFO",
        AGENT_PORT=8001,
        DEFAULT_LOCALE="pt-BR",
        DEFAULT_TIMEZONE="America/Sao_Paulo",
        ERP_DB_ENABLED=True,
        ERP_DB_HOST="10.15.1.23",
        ERP_DB_PORT=5430,
        ERP_DB_NAME="soccol",
        ERP_DB_USER="flextotal",
        ERP_DB_PASSWORD="flextotal",
    )


def test_postgres_erp_tools_maps_rows_to_part_items(monkeypatch: pytest.MonkeyPatch) -> None:
    diagnostics = {
        "raw_candidates_count": 3,
        "rejected_candidates": [{"item_id": "CAP", "reason": "item_refinement_filter"}],
        "ranked_candidates": [{
            "item_id": "022.1505",
            "score_breakdown": {"family": 0.32, "total": 0.88},
        }],
    }
    rows = [
        {
            "item_code": "022.1505",
            "title": "COXIM AMORTECEDOR FORD ECOSPORT DIANTEIRO C/ROL.",
            "score": 0.88,
            "applications": [{
                "application_id": 10,
                "vehicle_brand": "Ford",
                "vehicle_model": "Ecosport",
                "year_start": 2003, "year_end": 2012, "year_open_end": False,
                "engines": ["1.6"], "variants": ["XLS"],
                "injections": [], "transmissions": ["MANUAL"],
            }],
            "vehicle_model_motor_names": "2.0 de outra aplicacao, ignorado",
            "search_diagnostics": diagnostics,
        },
        {"item_code": "022.1553", "title": "COXIM AMORTECEDOR FORD ECOSPORT C/ROL.", "score": 0.81},
        {"item_code": None, "title": None, "score": None, "search_diagnostics": diagnostics},
    ]
    cursor = _FakeCursor(rows)

    connect_kwargs = {}

    class _FakePsycopg:
        @staticmethod
        def connect(*args, **kwargs):
            connect_kwargs.update(kwargs)
            return _FakeConnection(cursor)

    monkeypatch.setattr(erp_search_tools_pg, "psycopg", _FakePsycopg)
    monkeypatch.setattr(erp_search_tools_pg, "dict_row", object())

    tools = PostgresErpSearchTools(settings=_settings(), logger=logging.getLogger("test"))
    items = tools.search_parts(
        query="coxim ecosport 2008 1.6",
        branch_id=1,
        criteria=SearchCriteria(
            part_query="coxins",
            vehicle_brand="Ford",
            vehicle_model="Ecosport",
            vehicle_year=2008,
            engine="1.6",
        ),
    )

    assert [item.item_id for item in items] == ["022.1505", "022.1553"]
    assert tools.get_last_search_diagnostics()["ranked_candidates"] == diagnostics["ranked_candidates"]
    assert tools.get_last_search_diagnostics()["backend"] == "erp_postgres"
    assert tools.get_last_search_diagnostics()["criteria"]["vehicle_year"] == 2008
    tools.get_last_search_diagnostics()["raw_candidates_count"] = 0
    assert tools.get_last_search_diagnostics()["raw_candidates_count"] == 3
    assert items[0].score == 0.88
    assert items[0].attributes == {
        "application": ["Ford Ecosport 2003 a 2012"],
        "variant": ["XLS"],
        "engine": ["1.6"],
        "transmission": ["MANUAL"],
        "position": ["Dianteiro"],
        "feature": ["Com rolamento"],
    }
    assert "FROM soccol.item_search_candidates" in cursor.executed_sql
    assert cursor.executed_params["limit"] == 50
    assert "FROM soccol.item_search_applications" in cursor.executed_sql
    assert "vehicle_model_motor_names" not in cursor.executed_sql
    assert cursor.executed_params["vehicle_model_norm"] == "ecosport"
    assert cursor.executed_params["vehicle_year"] == 2008
    assert cursor.executed_params["part_query_norm"] == "coxins"
    assert connect_kwargs["client_encoding"] == "UTF8"


@pytest.mark.parametrize("viscosity", ["5W40", "5w-40", "5 W 40"])
def test_oil_viscosity_filters_product_without_requiring_vehicle_application(viscosity):
    sql, params = PostgresErpSearchTools._build_search_sql(
        criteria=SearchCriteria(part_query="lubrificantes", variant=viscosity), limit=10,
    )
    assert "%(oil_viscosity_pattern)s" in sql
    assert "unnest(a.variants) AS variant_name" not in sql
    assert "WHERE matched.applications IS NOT NULL" not in sql
    assert params["application_filter_fields"] == []
    assert "variant" in params["item_refinement_fields"]
    assert params["ranking_has_variant"] is False
    assert params["part_code_norm"] is None


@pytest.mark.parametrize("family,variant", [
    ("amortecedores suspensao", "JOY"), ("radiador", "5W40"), ("lubrificantes", "GLX"),
])
def test_non_viscosity_variants_still_require_vehicle_application(family, variant):
    sql, params = PostgresErpSearchTools._build_search_sql(
        criteria=SearchCriteria(part_query=family, variant=variant), limit=10,
    )
    assert "oil_viscosity_pattern" not in params
    assert "unnest(a.variants) AS variant_name" in sql
    assert "WHERE matched.applications IS NOT NULL" in sql
    assert params["application_filter_fields"] == ["variant"]


def test_oil_viscosity_preserves_explicit_vehicle_and_code_filters():
    sql, params = PostgresErpSearchTools._build_search_sql(
        criteria=SearchCriteria(part_query="lubrificantes", variant="5W40",
                                vehicle_model="Gol", vehicle_year=2010, part_code="TEX-3117"),
        limit=10,
    )
    assert "lower(cd_item) = %(part_code_norm)s" in sql
    assert "WHERE matched.applications IS NOT NULL" in sql
    assert params["part_code_norm"] == "tex-3117"
    assert params["application_filter_fields"] == ["vehicle_model", "vehicle_year"]


def test_search_sql_emits_internal_trace_and_conservative_score_breakdown() -> None:
    sql, params = PostgresErpSearchTools._build_search_sql(
        criteria=SearchCriteria(
            part_query="radiador",
            vehicle_model="Gol",
            vehicle_year=2010,
            engine="1.0",
            preferred_product_brand="NGK",
        ),
        limit=10,
    )

    assert "identity_candidates AS MATERIALIZED" in sql
    assert "rejected_candidates AS" in sql
    assert "search_diagnostics" in sql
    assert "score_breakdown" in sql
    assert "'injection', 0.0" in sql
    assert "'transmission', 0.0" in sql
    assert params["application_filter_fields"] == ["vehicle_model", "vehicle_year", "engine"]
    assert params["preferred_product_brand_bonus"] == 0.08


def test_postgres_erp_tools_raises_service_unavailable_on_connection_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class _FailingPsycopg:
        @staticmethod
        def connect(*args, **kwargs):
            raise RuntimeError("connection refused")

    monkeypatch.setattr(erp_search_tools_pg, "psycopg", _FailingPsycopg)
    monkeypatch.setattr(erp_search_tools_pg, "dict_row", object())

    tools = PostgresErpSearchTools(settings=_settings(), logger=logging.getLogger("test"))

    with pytest.raises(SearchPartsServiceUnavailableError):
        tools.search_parts(
            query="coxim ecosport 2008",
            branch_id=1,
            criteria=SearchCriteria(part_query="coxim", vehicle_model="Ecosport", vehicle_year=2008),
        )


def test_fallback_erp_tools_uses_fallback_when_primary_is_unavailable() -> None:
    class _FailingTools:
        def search_parts(self, query, branch_id, criteria=None):
            raise SearchPartsServiceUnavailableError("offline")

    class _FallbackTools:
        def search_parts(self, query, branch_id, criteria=None):
            return ["fallback-result"]

    tools = FallbackErpSearchTools(
        primary=_FailingTools(),
        fallback=_FallbackTools(),
        logger=logging.getLogger("test"),
    )

    items = tools.search_parts(query="coxim ecosport 2008 1.6", branch_id=1)

    assert items == ["fallback-result"]


def test_resolve_search_tools_returns_local_fallback_backend_when_erp_disabled() -> None:
    settings = Settings(
        APP_ENV="test",
        LOG_LEVEL="INFO",
        AGENT_PORT=8001,
        DEFAULT_LOCALE="pt-BR",
        DEFAULT_TIMEZONE="America/Sao_Paulo",
        ERP_DB_ENABLED=False,
        ERP_FALLBACK_DB_ENABLED=True,
    )

    tools = resolve_search_tools(settings=settings, logger=logging.getLogger("test"))

    assert isinstance(tools, PostgresErpSearchTools)


def test_postgres_erp_tools_sql_uses_exact_code_match_without_part_query() -> None:
    sql, params = PostgresErpSearchTools._build_search_sql(
        criteria=SearchCriteria(part_code="C.178"),
        limit=10,
    )

    assert "lower(cd_item) = %(part_code_norm)s" in sql
    assert params["part_code_norm"] == "c.178"
    assert params["part_query"] is None


def test_product_brand_is_a_soft_ranking_preference_not_a_required_filter() -> None:
    sql, params = PostgresErpSearchTools._build_search_sql(
        criteria=SearchCriteria(
            part_query="velas de ignicao automotivas",
            preferred_product_brand="NGK",
            vehicle_model="Gol",
            vehicle_year=2010,
        ),
        limit=10,
    )

    where_clause = sql.split("), ranked AS (", 1)[0]
    assert "preferred_product_brand_like" not in where_clause
    assert "preferred_product_brand_rank" in sql
    assert "has_preferred_product_brand" in sql
    assert params["preferred_product_brand_like"] == "%NGK%"


def test_curated_family_id_does_not_require_canonical_words_in_title() -> None:
    sql, params = PostgresErpSearchTools._build_search_sql(
        criteria=SearchCriteria(
            part_query="amortecedores suspensao",
            vehicle_model="Gol",
            vehicle_year=2010,
            engine="1.0",
            position="front",
        ),
        family_ids=[(2, 1)],
        require_family_title_identity=False,
        limit=50,
    )

    eligible_clause = sql.split("), matched_items AS (", 1)[0]
    assert "cd_grupo = %(family_group_0)s" in eligible_clause
    assert "cd_subgrupo = %(family_subgroup_0)s" in eligible_clause
    assert "family_token_" not in eligible_clause
    assert "family_head_pattern" not in eligible_clause
    assert params["family_group_0"] == 2
    assert params["family_subgroup_0"] == 1


def test_batente_plural_family_identity_matches_singular_erp_title() -> None:
    sql, params = PostgresErpSearchTools._build_search_sql(
        criteria=SearchCriteria(part_query="batentes"),
        family_ids=[(1, 3), (2, 5)],
        limit=10,
    )

    assert "family_token_0" in sql
    assert params["family_token_0"] == r"\mbatentes?\M"


def test_coxim_family_rejects_non_coxim_titles_from_noisy_erp_subgroup() -> None:
    sql, params = PostgresErpSearchTools._build_search_sql(
        criteria=SearchCriteria(
            part_query="coxins",
            vehicle_model="EcoSport",
            vehicle_year=2008,
            position="front",
        ),
        family_ids=[(4, 2)],
        require_family_title_identity=True,
        limit=50,
    )

    eligible_clause = sql.split("), matched_items AS (", 1)[0]
    assert "family_head_pattern" in eligible_clause
    assert params["family_head_pattern"] == r"\mcoxi[mn]\M"


def test_position_is_filtered_as_dianteiro_not_as_eixo_dianteiro() -> None:
    sql, params = PostgresErpSearchTools._build_search_sql(
        criteria=SearchCriteria(
            part_query="coxins",
            vehicle_model="EcoSport",
            vehicle_year=2008,
            position="front",
        ),
        limit=10,
    )

    where_clause = sql.split("), matched_items AS (", 1)[0]
    assert "position_pattern" in where_clause
    assert "axle_like" not in where_clause
    assert params["position_like"] == "%dianteir%"
    assert params["has_axle"] is False


def test_resolve_search_tools_returns_postgres_backend_when_enabled() -> None:
    settings = Settings(
        APP_ENV="test",
        LOG_LEVEL="INFO",
        AGENT_PORT=8001,
        DEFAULT_LOCALE="pt-BR",
        DEFAULT_TIMEZONE="America/Sao_Paulo",
        ERP_DB_ENABLED=True,
        ERP_FALLBACK_DB_ENABLED=False,
    )
    tools = resolve_search_tools(settings=settings, logger=logging.getLogger("test"))

    assert isinstance(tools, PostgresErpSearchTools)
