# Historico Consolidado Do Projeto

Consolidado em 14/09/2026 a partir dos relatorios antigos, do backlog legado e
dos relatos duplicados de problemas e solucoes. Estado atual em
[PROGRESS.md](PROGRESS.md), decisoes vigentes em [DECISIONS.md](DECISIONS.md)
e todo trabalho pendente em [TODO.md](TODO.md).

Os numeros abaixo pertencem as versoes e ambientes indicados. HTTP 200,
assertions estruturais e acerto comercial sao medidas diferentes. Resultados
historicos nao comprovam a qualidade da versao atual em producao.

## Material Academico E Relatorios Mantidos Localmente Em 19/10/2026

A pedido do usuario, `Documents/` foi movido para `.tmp/Documents/` na raiz,
com 942 arquivos preservados. PDF e diagrama academicos tambem sairam do
versionamento; os relatorios e ZIPs ja ignorados acompanharam a mudanca.
O historico Git permanece intacto e os guias atuais seguem versionados.

## Reteste Da VPS Revela Grafia E Sugestao De Motor Em 19/10/2026

Depois do deploy confirmado pelo usuario, Clio retornou SK-813, mas as mensagens
com `semieixo` tiveram handoff: o alias conhecido era `semi eixo`. Incluidas as
formas juntas singular/plural, preservando a familia diferencial especializada.
O FH 460 2016 recebeu sugestao D13K460 (catalogado a partir de 2023), recusada
ao responder. Corrigida a exibicao por intervalo de ano, sem afrouxar a validacao
da resposta. Apos o complemento, prints do usuario (19/10, 15:35-15:37)
mostraram S10 com versao integral retornando KJH0309; Gol com `nao sei`
encaminhando sem loop; FH oferecendo apenas D 13 C 460, aceitando a resposta
e concluindo sem resultado, sem apresentar a presilha. Aceite parcial desses
tres fluxos, sem auditoria dos trace_ids/filtros internos ou garantia comercial.
Palio e contradicoes ainda exigem reteste externo.

## Limpeza Documental Em 19/10/2026

Retiradas do versionamento a analise de estrutura de 13/03 e o relato de
problemas de 17/03 em `Documents/`, alem dos rascunhos iniciais do gateway
`estrutura.md` e `esqueleto.md`. Esses textos descreviam interfaces superadas
e repetiam informacoes dos guias atuais e deste historico. Copias locais
preservadas e ignoradas; arquivos continuam recuperaveis no historico Git.
Codigo, testes, datasets, snapshots e material academico foram mantidos.

## Correcao De Identidade E Follow-Up De 19/10/2026

No lote seguinte, curadoria de aliases/scopes e refinamentos tipados foram
implantados no Docker local, com backup e sem recriar volumes. Os 21 aliases
conflitantes receberam decisoes explicitas; kits/reparos/conjuntos nao viram
pecas avulsas. Auditoria dos 86 handoffs retirou exigencia direcional padrao
somente de quatro familias. ABS negativo, combustivel, cambio e versao passaram
a ter significado separado, preservado entre agente e gateway/Redis.

A inspecao do reteste detectou uma presilha classificada como caixa de bateria
no ERP. A busca passou a exigir a identidade completa da caixa; a prova do motor
FH 460 foi separada da existencia da peca, evitando perguntar novamente um
motor ja comprovado. Suite final: 593 testes do agente e 33 do gateway aprovados.
Estado e evidencias em [PROGRESS.md](PROGRESS.md#curadoria-e-refinamentos-no-docker-local-em-19102026).
Nao representa deploy na VPS, aceite externo Omni/Convert ou ganho nas 371 conversas.

A auditoria do modelo base revelou que nomes internos de componentes e
modelos/anos em titulos podiam substituir o pedido; respostas de versao eram
lidas como outro modelo, e o motor textual do FH 460 voltava a ser solicitado.
Corrigidos o extractor e a reconciliacao pelo campo pendente, com prova
contextual somente leitura no mesmo contrato ERP. Contradicoes interrompem a
busca; componentes sem identidade curada pedem esclarecimento. A LLM continua
residual e os filtros de aplicacao permanecem obrigatorios.

O teste no snapshot tambem identificou que o catalogo abreviava o motor para
`D 13 C 460`; o valor completo com `12.8` passou a exigir prova e ser preservado.
Regressoes em testes unitarios/API e oito cenarios na bateria estrutural.
Suite final com PostgreSQL habilitado: 546 aprovados, nenhum ignorado.
Controles no snapshot: oito turnos HTTP e tres sondas de extracao aprovados.
Corrigida ainda a integridade de seis casos antigos do golden sem `message`
e a assertion que dependia da ordem do arquivo, mantendo criterios e gabaritos.

Este lote foi concluido localmente; nao representa deploy nem nova medida de
cobertura comercial dos 371 casos. Evidencias em
[PROGRESS.md](PROGRESS.md#identidade-e-follow-up-concluidos-localmente-em-19102026),
motivo em [decisao 47](DECISIONS.md#47-preservar-identidade-e-governar-follow-up-pelo-contexto)
e implantacao/curadoria pendentes em [TODO.md](TODO.md).

## Experimento LoRA Em GPU De 19/10/2026

- Executado fine-tuning de `Qwen/Qwen2.5-7B-Instruct` com LoRA em BF16,
  sem quantizacao 4-bit (`load_in_4bit=false`); esta execucao nao foi QLoRA.
  GPU RTX PRO 6000 Blackwell Server Edition com 96 GB de VRAM. Dataset:
  128 exemplos de treino, 19 de validacao e 16 de teste retido. Duas epocas,
  32 passos, cerca de 172,6 s e `eval_loss=0,37199`. O teste retido nao foi
  o conjunto dos 27 golden desta comparacao.
- Comparacao entre o backbone Hugging Face original, com adapter desabilitado,
  e o mesmo backbone com adapter. Ambos em BF16, greedy e limite de 220
  tokens; nao foi comparacao direta com o artefato quantizado do Ollama ativo.
  Backend/avaliadores locais, GPU por tunel privado, mesmo codigo e snapshot
  congelados (52.798 produtos/1.779.443 aplicacoes).
- Executados 371 casos por categoria/subcategoria e 27 golden por modelo:
  796 registros e 1.169 turnos ponta a ponta, sem erros operacionais.
  O golden tambem avaliou o validador isoladamente. Nas categorias, a LLM
  participou de 71/371 conversas e houve 80 chamadas por modelo; o restante
  do atendimento foi predominantemente deterministico.

| Medida | Original | Adapter LoRA |
| --- | ---: | ---: |
| Golden isolado aprovado | 27/27 | 24/27 |
| Golden sem coincidencia exata de mensagem com treino | 21/21 | 18/21 |
| JSON bruto incompleto por limite de 220 tokens, nas categorias | 23/80 | 44/80 |
| Tempo medio por turno, nas categorias | 2,900 s | 3,435 s |
| Tempo medio por turno que chamou LLM | 13,489 s | 17,346 s |
| Conversas com itens coerentes com o cadastro | 133/371 | 131/371 |
| Suspeitas de item incorreto | 4 | 3 |
| Conversas com divergencia de filtros veiculares conhecidos | 16 | 13 |

- As tres regressoes isoladas foram oleo 5W40, viscosidade com hifen e
  multi-item radiador/bandeja. No fluxo completo, esses casos tiveram as
  mesmas respostas e buscas nos dois modelos pelo caminho deterministico.
  Os pequenos ganhos pontuais nao sustentaram promocao do adapter.
- Limites: seis mensagens golden coincidem exatamente com o treino; ausencia
  de coincidencia nos outros 21 nao exclui parafrases ou estruturas comuns.
  O avaliador nao reprova genericamente slots extras. Uma conversa por
  entrada nao cobre todo o estoque/aplicacoes, e coerencia com cadastro
  exige revisao comercial. Tempos descrevem uma rodada com tunel; os cortes
  foram observados sob o limite de 220 tokens.
- A tentativa inicial foi interrompida por incompatibilidade do LMFE 0.11.3
  com schema booleano. Apos correcao semanticamente equivalente, todas as
  rodadas oficiais foram reiniciadas. A tentativa inicial permanece
  identificada e excluida das metricas finais.
- Artefatos reunidos em
  [`fine_tuning_gpu/experimento_qwen_2026-10-19`](../fine_tuning_gpu/experimento_qwen_2026-10-19/LEIA-ME.md):
  pesos base, adapter, checkpoints/otimizador, dataset, manifestos, codigo,
  snapshots, logs e comparacoes completas. Inventario SHA-256 de 1.213
  arquivos/17,5 GB verificado localmente; hashes de modelo e treino conferidos
  contra a VPS. Leitura em
  [comparison.html](../fine_tuning_gpu/experimento_qwen_2026-10-19/comparacao/comparison.html)
  e [comparison.md](../fine_tuning_gpu/experimento_qwen_2026-10-19/comparacao/comparison.md).
- Conclusao: nesta configuracao, o fine-tuning nao trouxe melhoria geral.
  O experimento esta concluido; o modelo ativo foi preservado. Importacao
  do adapter no Ollama, auditorias adicionais e nova adaptacao ficam adiadas,
  sem serem declaradas implementadas. Por orientacao do usuario, a prioridade
  volta a avaliacao comercial e as correcoes deterministicas; retomada
  condicionada a lacuna residual comprovada e avaliacao independente.

## Marco E Abril: Baseline E Curadoria

### 22/09/2026 - Reranking Local E Atualizacao Da Stack

- Implementada corroboracao de ano, motor e versao antes do LIMIT, com
  penalidades auditaveis para conflitos explicitos; aliases JOY e SURF passam
  pelo catalogo. Pesos iniciais nao representam probabilidades calibradas.
- Comparacao com baseline de 21/09: `real_036_t1`, B.47895 da 3a para a 1a
  posicao; `real_041_t1`, AMD0358 da 4a para a 1a; `real_042_t2`, YM6160 da
  1a para a 4a. Nos dois primeiros, tambem foi corrigida a extracao da versao.
- ERP quente e snapshot produziram a mesma ordem nas tres consultas. A
  verificacao registrou criterios, diagnostico e ordem antes/depois nos logs
  locais; isso nao mede Top-1/Top-3 da populacao.
- 233 testes focados aprovados; golden ampliado para 45 casos, com 90/90
  verificacoes de contrato/SQL aprovadas. Fixtures de marca foram isoladas
  para nao alterar as expectativas do conjunto original de auditoria.
- Amostra API de seis turnos: quatro concluidos, `real_041_t2` e
  `real_041_t3` excederam 90 s. A execucao esta registrada nos logs locais.
- Backup PostgreSQL local validado por `pg_restore -l` antes da carga aditiva:
  `.tmp/before_reranking_20260922.dump`; 2419 aliases de pecas e dois de versao
  aplicados sem apagar volumes. Agente, gateway e interface reconstruidos
  localmente. Nenhuma alteracao aplicada na VPS.
- O smoke final de `real_036_t1` pela API do agente passou em 1,1 s, preservou
  PARATI 2008/SURF e devolveu B.47895 no topo; artefato em
  `.tmp/eval/real_036_reranking_20260922.json`.
- Os follow-ups de `real_041` foram correlacionados: `t2` e `t3` levavam 140,6
  s e 115,3 s no Ollama, embora a busca ERP fosse valida. O refinamento
  direcional apos busca concluida passou a ser deterministico. Nova execucao
  3/3: 1,34 s, 1,57 s e 1,10 s; artefato em
  `.tmp/eval/real_041_followup_latency_20260922.json`.
- O relatorio consolidado da bateria de 346 turnos registrou 341 respostas
  estruturais, 35 listas e queda de empate total de 100% para 57,1%. As falhas
  determinísticas restantes foram documentadas como divida pós-fine-tuning,
  sem reabrir pesos ou gates de busca nesta etapa.


| Data | Evidencia | Consequencia |
| --- | --- | --- |
| 25/03/2026 | Bateria real: 50 pedidos, 48 HTTP 200, 27 `request_info`, 17 `show_items`, 4 handoffs e 2 erros HTTP. Media 39,28 s; maximo 67,88 s. | Faltavam regras consistentes de familia, follow-up, ranking e tratamento de falhas. |
| 15/04/2026 | Primeira revisao: 76 interacoes pendentes em 47 conversas, 9 handoffs e quatro grupos de duplicidades exatas. | Revisao inicial era sugestao de curadoria; nao autorizava promocao automatica para treino. |
| 17/04/2026 | Comparacao de tres modelos base no MVP, golden set e bateria de 50 pedidos. `gemma3:12b` interrompido, com chamadas de 185â€“203 s. | Manter baseline mensuravel antes de treinar ou trocar o modelo. |

Comparativo de abril, anterior as correcoes deterministicas posteriores:

| Modelo | Decisao MVP | Casos aprovados no golden | Media do golden | Media da bateria real |
| --- | ---: | ---: | ---: | ---: |
| `qwen2.5:7b` | 35,0% | 100,0% | 33,50 s | 55,24 s |
| `qwen3:8b` | 15,0% | 100,0% | 45,24 s | 45,99 s |
| `llama3.1:8b` | 20,0% | 84,62% | 39,90 s | 43,57 s |

Os tres tiveram 48 respostas HTTP 200. O relatorio considerou Qwen3 candidato
de equilibrio, mantendo Qwen2.5 como baseline conservador; Llama perdeu em
campos faltantes e pergunta seguinte. A divergencia entre MVP e golden exige
avaliar cobertura e expectativas antes de interpretar percentuais.

## Julho A Setembro: Regras, Estado E Latencia

- **13/07:** bloqueio de `part_code` inventado, exemplificado por `FREIO-2010`;
  codigos exigem proveniencia. Ajustadas regras de eixo/lado de filtros no
  catalogo e bootstrap. Suite evoluiu de 136 para 148 testes.
- **14/07:** busca completa passou a usar `deterministic_bypass`, com latencia
  por etapa. Na mesma maquina, `radiador Gol 2010 1.0` caiu de 71,67 s para
  1,31 s; follow-up `1.0`, de 46,73 s para 0,93 s. Suite: 159 testes.
- **27/08:** `deterministic_ask` usa campos obrigatorios e opcoes do catalogo.
  Comparacao pareada de 50 casos, Qwen2.5 em CPU: chamadas LLM 31 -> 12;
  media total 23,15 -> 10,84 s; mediana 31,41 -> 0,74 s. Nos 19 casos
  transferidos, media 35,33 -> 0,72 s. P95 total 42,94 -> 43,90 s: a cauda
  da LLM continuou alta. Cinco respostas ganharam opcoes governadas de motor.
  Suite daquele bloco: 187 testes.
- **27/08:** `no_match` passou a preservar criterios e permitir nova tentativa,
  sem declarar incompatibilidade mecanica ou encaminhar automaticamente.
  Desambiguacao persiste candidatos/atributos e filtra respostas sucessivas.
- **27â€“28/08:** bateria estrutural ampliada para 135 cenarios/164 turnos, com
  27 cenarios exigindo revisao humana. Runner passou a excluir respostas
  futuras do contexto. Smoke omnichannel: 30 cenarios/65 turnos, todos HTTP
  200, zero falhas estruturais e zero vazamento temporal; mediana 36,4 s,
  media 28,9 s e P95 55,9 s. Foram 43 chamadas LLM, 12 perguntas
  deterministicas, 6 buscas com bypass e 4 desambiguacoes. Isso nao
  significava 100% de acerto semantico/comercial.
- **08/09:** revisao visual por conversa/turno, edicao multi-item, historico
  de revisoes e reabertura. Corrigidos lado para velas/aditivos e eixo para
  anti-chama. Estado continua no Redis do `docker-comm`; testes diretos na
  API precisam reenviar o estado retornado.
- **11/09:** follow-up `2008` preserva ano, sem virar modelo Peugeot 2008;
  direcao respeita o campo pendente. Coxins exigem posicao, nao eixo;
  pastilhas nao exigem motor como campo obrigatorio.

## Auditoria Especialista De 11/09/2026

Avaliacao anterior ao contrato ERP v2: **6/10 como prototipo de TCC e 4/10
para prontidao de producao**. Notas qualitativas de engenharia, nao metricas
estatisticas ou notas recalculadas apos as correcoes.

Evidencias: 261 testes automatizados; smoke estrutural 30/30 turnos; bateria
adicional exclusivamente automotiva com 15 cenarios/23 turnos, todos HTTP 200,
mas com erros funcionais. Conferidos 43 arquivos Python contra a imagem, sem
diferenca. A janela de logs mostrou 22 buscas `erp_postgres`, sem fallback.

| Prioridade original | Achado e reproducao | Situacao apos 14/09 |
| --- | --- | --- |
| P1 | `radiador Gol 2010 1.0` aceitava `AUD-REAL`, `AUD-GOLF`, `AUD-CROSS` e `AUD-CAP`: substring, anos agregados, atributos cruzados e acessorio. | Corrigido por identidade e aplicacao; somente `AUD-REAL` aceito no golden SQL. |
| P1 | `pastilha traseira ... nao dianteira` virou dianteira; `nao quero radiador, quero filtro` incluiu radiador. | Pendente: negacao antes do bypass. |
| P1 | `radiador Gol 2010 1.0 e radiador Corsa 2011 1.4` perdeu item e misturou veiculo/ano/motor. | Pendente: identidade e contexto por item. |
| P1 | Bandeja sem lado pesquisada; `esquerda` afetou item errado; codigo simulado `ZZ-12345` da LLM chegou a ferramenta. | Pendente: gate/proveniencia por item e follow-up. |
| P1 | Corrigir Gol para Corsa durante desambiguacao manteve candidatos antigos. | Pendente: invalidar candidatos ao mudar criterios. |
| P1 | `SearchPartsServiceUnavailableError` simulada virou HTTP 200 com `no_match_retry`. | Pendente: separar falha de ausencia de produto. |
| P1 | `/health` excedeu 3 s durante inferencia e respondeu em 24 ms depois. | Pendente: remover I/O bloqueante e isolar auditoria por requisicao. |
| P1 para exposicao | Revisao retornou 200 sem chave administrativa; portas publicadas em todas as interfaces. Firewall externo nao auditado. | Pendente: autenticacao e limites de acesso/entrada. |
| P2 | `zetec rocam` e `nao sei a motorizacao` repetiram pergunta; `4 velas NGK` nao reconhecido; descricao funcional fixou familia sem confirmar. | Pendente: motor textual, lexical e confirmacao de familia. |
| P2 | Benchmark aprovava campos extras incorretos; entrada exportada para treino omitia estado/regras do runtime. | Pendente: avaliacao e paridade treino/runtime. |

Outros casos: `Honda Gol` aceito sem confirmar conflito; codigo inexistente
recebeu ausencia sem produto inventado; radiador -> sem ar -> opcao 1
funcionou. LLM em CPU: mediana 40,78 s em nove amostras, entre 34,64 e
81,87 s. GPU nao resolve os erros de intencao ou concorrencia. Os criterios
de aceitacao dos achados abertos permanecem no [TODO](TODO.md).

## Correcao Da Busca Em 14/09/2026

Contrato passou a separar item e aplicacao. Modelo exato, ano individual,
fim aberto explicito e motor da propria aplicacao sao filtrados juntos.
Identidade de familia precede ranking; tampas, kits e mangueiras continuam
pesquisaveis por sua propria familia. Somente aplicacoes aprovadas fornecem
atributos de desambiguacao.

Validacao anterior a limpeza documental: 343 testes, incluindo 38 casos
automotivos nos SELECTs externos e apos COPY (76 verificacoes). Snapshot
exportado do banco quente em 14/09, 12:43 UTC: **52.798 itens e 1.776.907
aplicacoes**, UTF-8, dois CSVs gzip, manifesto e checksums. A exportacao
original consultou tabelas de origem pelos SELECTs do contrato; o exportador
atual consulta diretamente as views instaladas.

Quatro pedidos passaram pela API real com catalogo e fallback locais:
radiador Gol 2010 1.0 retornou quatro radiadores; tampa desse radiador retornou
`TC-7018`; coxim de amortecedor dianteiro EcoSport 2008 1.6 retornou cinco
coxins; radiador Golf 2010 1.6 retornou zero, sem substituir por Gol. Busca
local entre 19,92 e 48,50 ms; configuracao ERP + fallback teve 188,38 ms de
busca e 846,24 ms total no pedido de radiador. Sao amostras pontuais,
nao um novo benchmark de latencia.

Tabelas anteriores em `search_snapshot_backup_38555ef20e3c`; imagem anterior
com tag `docker-agent-docker-agent:before-erp-v2-20260914`. O usuario informou
a instalacao do SQL no banco quente. Implantacao na VPS permanece no backlog.

## Curadoria E Treinamento

Fila `pre_search_review_interaction` separada do dataset formal
(`pre_search_fine_tuning_dataset_header/record`) e das runs. Revisar, promover
e exportar continua obrigatorio antes do treino. Snapshots antigos com
pergunta/campos faltantes obsoletos em alvos `search` recebem normalizacao
documentada no metadata do exportador.

Export validado do `pre-search-ft-v1`: 122 exemplos de treino, 15 de validacao
e 15 de teste em UTF-8; 13 testes focados passaram. Auditoria de 11/09:
zero runs. Isso comprova preparacao do fluxo, sem comprovar ganho de adapter.
Teste retido, comparacao com baseline e promocao controlada seguem no backlog.

## Organizacao Dos Arquivos

Consolidados aqui: `PROBLEMAS_E_SOLUCOES.md`, `TODO_OLD.md`, historico de
`PROGRESS.md` e os sete arquivos de relatorios de marco, abril, agosto e
setembro. O prompt de abertura repetia README/AGENTS e foi removido.
Pendencias antigas continuam no TODO atual ou como hipoteses adiadas.

Datasets ativos e roteiro de validacao humana permanecem em
[assets/datasets](assets/datasets/README.md). Novos relatorios ficam em
`.tmp/eval/`; resultados interpretados entram nos documentos. Bootstrap local
em `db/init/pre_search_init.sql`. DDL do ERP e material operacional fora do
Git. O avaliador aceita copia local por `--integration-sql` para auditar
SELECTs de origem sem aplicar DDL no banco quente. Instrucoes em
[integracao ERP](guide/erp_search_integration.md).

## Consolidacao Em 16/09/2026

- Busca apresenta ate 10 candidatos diretamente e preserva uma janela de ate 50
  linhas para paginacao. Refinamento tambem termina com ate 10 opcoes. Titulos originais e
  acentos sao preservados; preco e estoque nao sao inferidos do catalogo.
- Familias compostas e quantidade auditadas por regressao: polia da bomba
  d'agua, kit corrente da bomba de oleo, junta do cabecote, quantidade explicita
  e ausencia de quantidade inferida de ano, modelo, motor ou cilindrada.
- Significado publico de confidence e alcance de branch_id documentados no
  guia ERP; calibracao, ranking rotulado e integracao comercial seguem pendentes.

- Negacao, conflitos de veiculo, itens independentes, gate por item, follow-up
  do item ativo e invalidacao de candidatos foram concluidos. A suite local
  passou com 369 testes; golden LLM 25/25 e bateria estrutural 164/166.
- Catalogo: 338 tipos, 2.274 aliases e 6.822 variacoes. A cobertura
  deterministica nao ambigua atingiu 6.741/6.765 (99,65%).
- Foram importadas 98 interacoes webchat da VPS. Das 86 pendentes, 73 foram
  descartadas, 13 revisadas e 11 promovidas. O dataset final ficou com 131
  treino, 16 validacao e 16 teste, exportado em ZIP para a futura GPU.
- O gate e a proveniencia passaram a ser calculados para cada item antes da
  consulta; pendencias guardam o item ativo e correcoes invalidam candidatos e
  estado derivados dos filtros anteriores. O trainer avalia e salva checkpoint
  a cada 10 passos, adequado ao tamanho atual do dataset.
- A subida limpa por Compose foi validada. O proxy publicado usa
  `127.0.0.1:8002` para o `docker-comm`, pois a porta publica 8000 ja era
  usada pelo Portainer; o DNS do Streamlit foi demonstrado.

## Validacao Visual De Busca Em 17/09/2026

- Resultados com uma a dez opcoes passaram a ser apresentados diretamente, sem
  exigir que o cliente escolha um unico codigo quando todas as alternativas podem
  servir. Consultas maiores exibem dez itens por pagina e aceitam `ver mais`.
- A reavaliacao da desambiguacao de muitos resultados foi concluida: a busca
  preserva ate 50 candidatos; discriminadores so aparecem quando dividem os
  resultados; selecao, negacao, refinamento, mudanca de assunto, paginacao e
  limite de tentativas conservam o mesmo `ConversationState`.
- A interface preservou UTF-8 nas mensagens publicas e nos titulos do catalogo;
  a normalizacao permaneceu restrita a comparacao interna. A preferencia por marca
  comercial ausente passou a ser explicada sem ocultar alternativas compativeis.
- O fluxo de `coxim` passou a confirmar primeiro `motor/cambio` ou `amortecedor`,
  evitando misturar as duas familias. O teste real tambem revelou que uma opcao
  textual sugerida (`zetec rocam`) ainda repete a pergunta de motorizacao; essa
  correcao permanece no TODO.
- Os prints de radiador, pastilha, amortecedor e filtro confirmaram a apresentacao
  e a paginacao, mas mostraram empates de `score` entre todos os candidatos. Por
  isso, ranking, top-1/top-3 e calibracao continuam pendentes de rotulos humanos.


## Baseline Humano De Recuperacao E Ranking Em 17/09/2026

O relatorio local `relatorios/relatorio_preliminar_ranking_e_plano_implementacao.docx`
revisou a rodada `regression` de `real_omnichannel_battery_250`. Sao resultados
preliminares comparados com respostas observacionais de vendedores, e nao um
gabarito formal de compatibilidade ou disponibilidade.

- A execucao registrou 139/139 respostas HTTP 200, 136 turnos com referencia
  humana, media de 26,06 s, mediana de 33,89 s, p95 de 56,52 s e maximo de
  116,73 s. PASS estrutural mede apenas o contrato do fluxo, nao o acerto
  comercial.
- Houve 20 turnos com lista de produtos, totalizando 96 candidatos revisados.
  Nos casos determinaveis, Top-1 foi 7/16 (43,8%; Wilson 95%: 23,1%--66,8%) e
  Top-3 foi 11/15 (73,3%; Wilson 95%: 48,0%--89,1%). A diferenca indica que o
  item util e recuperado em parte dos casos, mas frequentemente nao ocupa a
  primeira posicao.
- Todos os 20 rankings revisados tiveram empate total de `score`. O indicador
  atual nao ordena aplicacao exata, ano, motor, versao e caracteristicas como
  I-Motion, ABS, atuador ou pivo de maneira discriminativa.
- Entre 23 respostas `no_match`, 14 tiveram forte evidencia observacional de
  falso negativo. Entre os 19 casos determinaveis, a taxa foi 14/19 (73,7%;
  Wilson 95%: 51,2%--88,2%). Os exemplos incluem alias ausente (`rolamento`
  versus `cubo com rolamento`), familia normalizada incorretamente e perda de
  contexto multi-item.
- As falhas se agrupam em identidade de familia/composicao (`quadro de
  suspensao` retornando amortecedor; `junta` retornando bomba ou tampa),
  atributos e slots indevidos, preservacao de contexto e decomposicao de
  pedidos multi-item. Esses grupos precedem qualquer ajuste de pesos de ranking.
- A rodada passou a ser baseline da proxima versao. Cada correcao deve incluir
  regressao dos casos reais correspondentes e repetir a mesma bateria, sem usar
  as respostas humanas como regras automaticas do runtime.

## Consolidacao De Entregas Em 21/09/2026

- A VPS passou a consultar o ERP quente autenticado pelo backend
  `erp_postgres`; conectividade, autorizacao de rede e objetos v2 foram
  verificados. O snapshot local v2 permanece como contingencia e reproducao,
  sem substituir a fonte operacional.
- Indisponibilidade do ERP foi separada de ausencia de produto: item unico
  recebe HTTP 503, enquanto pedido multiplo conserva erro por item para nova
  tentativa. Telemetria e captura de revisao distinguem falha de `no_match`.
- Inferencia, consulta PostgreSQL e fila de revisao sairam do event loop, com
  limites de concorrencia, timeout e auditoria local por requisicao. Regressao
  focada confirmou que uma inferencia lenta nao bloqueia `/health` nem outra
  conversa deterministica.
- O motor textual passou a ser validado contra as opcoes de modelo e ano do
  catalogo; listas comerciais sao decompostas por aliases sem misturar veiculo,
  quantidade ou atributos de itens distintos. As regressÃµes focadas passaram
  com 146 testes.
- O prompt residual agora declara fontes e precedencia de evidencia, e o
  backend continua sendo a autoridade final. Perguntas publicas foram
  unificadas em esquerdo/direito, dianteiro/traseiro e eixo dianteiro/traseiro;
  165 testes focados passaram nessa revisao.
- Checklist de deploy, backup, restauracao e `/health`, alem do fluxo sem GPU,
  foram exercitados. A bateria comercial longa e a beta pelo canal real seguem
  como trabalho futuro, pois validacao estrutural nao substitui rotulo humano.

## Deploy Protegido E Beta Inicial Da VPS Em 21/09/2026

- O Compose foi aplicado na VPS com agente, catalogo, Ollama e Streamlit
  restritos a `127.0.0.1`; Redis deixou de publicar `6379`. A verificacao de
  listeners confirmou que portas internas do TCC nao estavam em `0.0.0.0`, e
  Nginx continuou atendendo o dominio HTTPS do chat.
- O agente iniciou com `APP_ENV=production`, catalogo carregado e backend
  `erp_postgres` habilitado. O warm-up sincrono do modelo reteve o startup e
  foi temporariamente desativado na VPS; a correcao versionada o move para
  tarefa de fundo.
- Dois fluxos reais pelo `docker-comm` confirmaram Redis e continuidade de
  conversa: selecao de filtro de oleo para Corsa e desambiguacao de coxim da
  EcoSport por posicao, versao e candidato. A evidencia e beta de
  infraestrutura/fluxo, nao certificacao de compatibilidade comercial.

## Continuidade Segura E Cobertura Lexical Em 21/09/2026

- **Problema:** uma resposta explicita `nao sei` a uma pergunta de motor podia
  ir para a LLM e voltar a perguntar a mesma motorizacao.
- **Correcao local:** o estado pendente reconhece desconhecimento e encerra em
  handoff deterministico, preservando os criterios que o cliente ja informou.
  A regressao cobre `radiador Gol 2010 -> nao sei a motorizacao`.
- **Problema:** a familia comercial curta `velas` nao era um alias catalogado,
  e `4 velas NGK para Gol 2010 1.0` perdia a quantidade nua antes da familia.
- **Correcao local:** aliases auditaveis de `vela` e `velas` foram adicionados
  a velas de ignicao automotivas; quantidade, marca preferida e marca de
  veiculo permanecem campos independentes. A regressao estrutural registra a
  mensagem completa para a proxima rodada.

## Instrumentacao De Busca E Politica De Desempate Em 21/09/2026

- **Evidencia:** a avaliacao humana preliminar apontou empate total nos 20
  rankings observados. A resposta final sozinha nao mostrava se a causa era
  recuperacao, exclusao por aplicacao ou ordenacao.
- **Correcao local:** `search_diagnostics` passou a registrar a amostra de
  candidatos brutos, rejeitados, filtrados e ranqueados, seus motivos e o
  `score_breakdown`; a captura fica limitada e segue apenas para log e revisao.
- **Politica:** filtros de identidade e aplicacao continuam obrigatorios. A
  marca comercial preferida e o unico desempate com evidencia explicita do
  cliente; pesos para injecao, transmissao, complemento e atributos comerciais
  ficam em zero ate a proxima avaliacao rotulada.
- **Regressao pendente de execucao:** o golden case
  `ranking_trace_preferred_brand_and_rejections` cobre candidato acessorio,
  aplicacoes rejeitadas e preferencia NGK. Nenhum teste foi executado nesta
  entrega, por solicitacao do usuario.

## Correlacao Da Bateria Real Com A Captura De Revisao Em 22/09/2026

- **Problema:** a bateria de respostas reais guardava o texto e os candidatos
  publicos, mas nao a trilha interna usada pelo ERP. Assim, Top-1, Top-3,
  rejeicoes e empates continuavam sem causa observavel no mesmo relatorio.
- **Correcao local:** cada turno agora le a captura protegida por `trace_id` e
  grava `search_diagnostics` no JSON gerado; os Markdown resumem contagens e
  o primeiro item ranqueado. No caminho via gateway, a correlacao usa o id que
  o `docker-comm` devolve.
- **Limite:** a evidencia so aparece quando avaliador e catalogo compartilham
  a rede da fila de revisao; `unavailable` indica que a coleta deve ser
  repetida no ambiente integrado, nao uma falha comercial do atendimento.
- **Validacao focal:** os 12 testes do executor passaram em container. Uma
  execucao integrada de `legacy_001` registrou 310 candidatos brutos, 306
  rejeitados, quatro filtrados e quatro ranqueados no artefato local, sem
  expor essa trilha na resposta HTTP do chat.

## Troca De Familia Durante Follow-Up Em 22/09/2026

- **Problema:** com uma pergunta pendente para polia, a nova familia
  `rolamentos` de `real_004` ainda podia deixar o proximo ano associado ao
  item anterior. `real_001` e `real_046` tambem expunham termos compostos
  incompletos no catalogo.
- **Correcao local:** uma familia explicita, reconhecida por alias exato,
  substitui o item ativo do `ConversationState`; o proximo atributo completa a
  nova familia. `bucha estabilizador` e `junta da tampa de valvula` foram
  cadastradas como aliases das familias existentes, e plurais direcionais sao
  reconhecidos.
- **Regressoes:** o dataset estrutural agora inclui `real_001_regression`,
  `real_004_regression` e `real_046_regression`. Seis testes focados passaram
  em container; a bateria completa permanece pendente da rodada conjunta.

## Recuperacao De Turno Apos Espera HTTP Em 30/09 E 01/10/2026

- **Problema:** a Convert encerra o bloco HTTP apos 40 s; repetir uma chamada
  com `$last_message` pode enviar texto vazio ou um `room_id` diferente.
- **Entrega:** `docker-comm` identifica a primeira solicitacao por origem,
  conversa, filial e texto normalizado. Um worker continua a chamada ao agente
  apos o encerramento da conexao. O Redis guarda o estado do turno, uma concessao
  renovavel e a resposta final por 300 s; chamadas repetidas consultam o mesmo
  turno sem atualizar o historico novamente. Depois de ate 35 s de espera,
  uma chamada ainda pendente devolve `status=processing` e `trace_id`.
- **Recuperacao:** a Convert pode repetir `POST /test/send` apenas com
  `trace_id`, sem depender de `$last_message` ou do `room_id` atual. O endpoint
  recupera o identificador original da conversa e nunca inicia novo trabalho
  nesse modo. Um turno expirado devolve 404; um turno interrompido, 409.
- **Evidencia operacional:** em 30/09, a chamada HTTP de teste retornou 200;
  os logs da VPS registraram `test_send_turn_finished` e
  `test_send_processed` com o mesmo trace e `result_source=cached`. Em 01/10,
  o fluxo publicado na Convert entregou perguntas, opcoes sugeridas e listas
  de produtos em conversas de radiador Gol 2010, coxim EcoSport 2008 e
  pastilha Onix 2018. Naquela data, esses testes ainda nao encerravam a matriz
  da Categoria 1C; o encerramento foi confirmado pelo usuario em 02/10/2026.
- **Limite conhecido:** sem ID unico da mensagem fornecido pela Convert, duas
  mensagens iguais na mesma conversa e filial dentro dos cinco minutos podem
  compartilhar a chave. A validacao de concorrencia, reinicio, expiracao e
  handoff permanece no [TODO.md](TODO.md).

## Contrato De Etapa E Apresentacao Na Convert Em 01/10/2026

- **Entrega no gateway:** `status` separa espera de conclusao. Em resultado
  concluido, `stage` indica `transfer_to_human`, `more_info`,
  `mostrar_produtos` ou `fallback`; `items_text` apresenta codigos e titulos
  numerados, e `actions` e `items` continuam disponiveis no JSON.
- **Entrega na mensagem:** opcoes de `request_info` sao acrescentadas ao
  `reply` como `Opcoes sugeridas`, para aparecer no bloco de mensagem da
  Convert. Isso foi observado no canal interno em 01/10, junto com listas de
  produtos para as consultas de radiador, coxim e pastilha.
- **Pendente em 01/10:** confirmar na Convert todas as saidas de `stage`,
  inclusive transferencia humana e contingencia. As Categorias 1B e 1C foram
  encerradas por confirmacao do usuario em 02/10/2026, conforme registro abaixo.

## Categorias 1B E 1C Concluidas Na VPS/Convert Em 02/10/2026

- **Aceite:** o usuario informou que a integracao foi resolvida e solicitou
  retirar as duas categorias do TODO. O encerramento se baseia nos testes
  realizados pelo usuario na VPS/Omni/Convert e em sua confirmacao dos cenarios
  controlados; nao houve nova execucao de testes pelo agente nesta atualizacao.
- **Categoria 1B:** roteamento de `$.stage` para `$estado_ia` no fluxo publicado,
  com `more_info`, `mostrar_produtos`, `transfer_to_human` e `fallback`;
  espera/consulta por `trace_id` enquanto `processing`, envio da resposta
  somente em `completed`, apresentacao dos produtos e transferencia humana
  sem continuar perguntas automaticas.
- **Categoria 1C:** validacao ponta a ponta aceita pelo usuario. O escopo
  encerrado inclui chamadas repetidas concorrentes, repeticao durante o
  processamento, recuperacao do resultado pronto, expiracao de cinco minutos,
  falha/timeout do agente, reinicio durante processamento, atualizacao unica
  do historico, handoff e mensagens diferentes na mesma conversa; inclui
  tambem espera inicial, novas consultas em `processing`, entrega final,
  etapas conversacionais e limite de tentativas/expiracao na Convert.
- **Evidencia discutida:** o relato dos logs de oito turnos registra HTTP 200
  e resultado armazenado, com continuidade da mesma conversa em tres turnos
  e respostas de cerca de 1 a 3,5 segundos. Essa amostra cobre o caminho rapido;
  os cenarios controlados restantes sao registrados pela confirmacao do usuario.
- **Consequencia:** Categorias 1B e 1C removidas do backlog ativo; preparacao
  de fine-tuning controlado em GPU passa a ser o proximo bloco. Contrato e
  justificativa permanecem em [DECISIONS.md](DECISIONS.md).

## Prioridade 4 Concluida Via Sistema Interno Em 02/10/2026

- **Escopo original:** integrar WhatsApp com webhook proprio, identificacao
  por telefone e envio direto pela API da Meta no `docker-comm`.
- **Entrega adotada:** o usuario esclareceu que montou uma integracao
  funcionalmente equivalente usando o sistema interno Omni/Convert para
  conectar o canal. Esse intermediario cuida do transporte; o TCC usa o
  contrato HTTP, conversa persistente, filial e respostas estruturadas.
- **Aceite:** Prioridade 4 encerrada pela confirmacao do usuario, em conjunto
  com a validacao operacional das Categorias 1B e 1C. Nao houve nova execucao
  de testes nem auditoria do conector interno nesta atualizacao documental.
- **Consequencia:** removida a prioridade do TODO. Webhook proprio e cliente
  direto da Meta foram substituidos pelo caminho via sistema interno;
  a escolha e suas responsabilidades ficam na decisao 45 de
  [DECISIONS.md](DECISIONS.md).

## Anos Do Catalogo E Follow-Up De Motor Corrigidos Na VPS Em 01/10/2026

- **Falha observada:** `ZETEC ROCAM`, oferecido como opcao para radiador da
  EcoSport 2008, repetia a pergunta de motorizacao. Os dois turnos tinham o
  mesmo `conversation_id`; o segundo caiu na LLM e voltou com `engine` ausente.
- **Causa:** as quatro linhas desse motor na VPS tinham `year_from=20` e
  `year_to=20`. A auditoria encontrou ano inicial invalido nas 10.834 linhas
  de motores. O CSV montado na VPS tinha datas completas, o SQL versionado
  extrai quatro digitos e o banco local tinha zero anos invalidos.
- **Correcao operacional:** backup do banco e recriacao dos volumes da stack.
  O novo PostgreSQL registrou 10.834 motores, zero anos iniciais ou finais
  invalidos. O warm-up do `qwen2.5:7b` concluiu e `ollama ps` mostrou o modelo
  residente com `UNTIL Forever`.
- **Reteste no canal Navi:** em conversa nova, `radiador da EcoSport 2008` levou
  a pergunta de motor; `ZETEC ROCAM` avancou para a busca e devolveu tres
  itens, sem repetir a pergunta. O teste comprova o fluxo, nao a compatibilidade
  comercial individual dos tres itens. A filtragem das opcoes de motor por ano
  continua no [TODO.md](TODO.md).
