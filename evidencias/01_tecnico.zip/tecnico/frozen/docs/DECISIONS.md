# Registro De Decisoes Tecnicas

## Viscosidade De Oleo Sem Ampliar O Payload Em 14/10/2026

- Manter viscosidade em `SearchCriteria.variant`, sem adicionar campo ao
  contrato de comunicacao, estado ou dataset de treinamento.
- Interpretar o valor como especificacao do produto somente para a familia
  `lubrificantes` e formato completo de viscosidade. Buscar no nome e titulo
  do item, com limites de palavra e tolerancia a espacos/hifen.
- Preservar demais filtros, codigos exatos e versoes veiculares de outras
  familias. Registrar viscosidade como refinamento do item, sem corroboracao
  de versao veicular no ranking.

Motivo: `TEX-3117` tem `5W40` na descricao, mas `TODOS` na versao de sua
aplicacao no snapshot. O filtro anterior confundia especificacao de oleo com
versao de veiculo. A correcao pertence a busca deterministica, nao ao treino.

## Fallback Direcional Condicional Em 02/10/2026

- Pesquisar primeiro com todos os criterios validados. Quando nao houver
  produtos e existir `side` ou `position`, executar uma unica tentativa no
  mesmo backend sem esses dois campos; preservar os demais filtros.
- Nao alterar o pedido original nem somar pesos dos campos retirados no
  ranking ampliado. Manter o prazo externo existente para a busca completa.
- Registrar a tentativa estrita e os criterios efetivos em
  `directional_fallback`, somente no diagnostico interno.
- Avisar ao cliente que a pesquisa foi ampliada e pedir confirmacao de
  lado/posicao. Permitir desambiguacao por esses campos quando necessario.

Motivo: descricoes incompletas ou abreviadas no ERP podem gerar falsos
negativos nos filtros direcionais. Uma segunda consulta condicional amplia
a recuperacao sem duplicar toda busca, sem LLM adicional e sem tratar os
resultados ampliados como prova da direcao solicitada.

Este documento concentra os motivos das escolhas principais do projeto. O objetivo e evitar que a justificativa fique espalhada entre backlog, relatorios e historico de execucao.

## 1. Catalogo deterministico no Postgres como fonte de verdade

Decisao:

- usar o Postgres como fonte unica para regras de negocio, aliases, familias de peca e parametros de decisao

Motivo:

- permite governanca explicita das regras
- facilita auditoria e reproducao
- evita espalhar conhecimento de dominio em codigo hardcoded

Consequencia:

- o runtime depende do banco corretamente bootstrapado
- mudancas estruturais exigem refletir `db/init/pre_search_init.sql` e os CSVs reais em `db/init/csv/`

## 2. Bootstrap real versionado no repositorio

Decisao:

- manter os CSVs reais de bootstrap em `db/init/csv/`
- remover templates duplicados de `docs/assets/`

Motivo:

- reduz ambiguidade entre exemplo e dado operacional
- simplifica a reproducao do ambiente em outra maquina
- evita divergencia entre documentacao e bootstrap real

## 3. LLM como validador e orquestrador, nao como decisor isolado

Decisao:

- executar extracao deterministica antes da LLM
- enviar `dictionary_seed_criteria` e `score_policy` para a LLM
- recalcular o gate de `search` no backend apos a resposta da LLM

Motivo:

- reduz risco de alucinacao
- preserva rastreabilidade das regras de negocio
- melhora consistencia em casos com campos obrigatorios como `engine`, `side` e `position`

## 4. Gate backend para liberar `search`

Decisao:

- a LLM pode sugerir `search`, mas a decisao final depende do backend validar score e campos obrigatorios

Motivo:

- evita liberar busca cedo demais
- protege o sistema de respostas otimistas ou inconsistentes da LLM
- separa claramente regra deterministica de comportamento linguistico

## 5. Captura, revisao e promocao antes do fine-tuning

Decisao:

- manter `pre_search_review_interaction` como fila bruta de interacoes reais
- promover apenas casos revisados para `pre_search_fine_tuning_dataset_record`

Motivo:

- impede que ruido operacional vire treino automaticamente
- preserva qualidade metodologica do dataset
- separa evento real de verdade supervisionada curada

### Revisao visual agrupada por conversa

Decisao:

- mostrar a conversa completa no Streamlit, mas revisar e persistir o rotulo por interacao
- retirar a conversa da fila pendente somente quando todos os seus turnos tiverem sido revisados ou descartados
- manter `reviewed` separado de `promoted`, sem transformar uma avaliacao humana diretamente em dado de treino
- expor a operacao por uma API administrativa do `docker-agent`, opcionalmente protegida por chave, sem dar acesso direto do Streamlit ao Postgres

Motivo:

- o contexto multi-turno e necessario para julgar follow-ups e contraperguntas
- a granularidade por interacao preserva o formato atual do dataset e a rastreabilidade
- a separacao entre revisao e promocao cria uma segunda barreira de qualidade antes do fine-tuning
- a API concentra validacao, concorrencia e transicoes de estado no servico dono dos dados

Complemento multi-item:

- persistir `predicted_items` e `reviewed_items` sem substituir `criteria`
- revisar cada item com decisao, campos faltantes e pergunta proprios
- manter a estrutura curada em `expected_items` na promocao e exportar os criterios em `items` no contrato supervisionado
- permitir reabertura somente de `reviewed` ou `discarded`, registrando o estado anterior em `pre_search_review_revision`
- bloquear reabertura de exemplos ja promovidos ate a retirada explicita do dataset

## 6. Fine-tuning com SFT + LoRA/QLoRA

Decisao:

- usar `supervised fine-tuning` sobre o modelo base
- aplicar `LoRA`
- preferir `QLoRA` quando houver GPU compativel

Motivo:

- o projeto possui dataset supervisionado estruturado, nao dataset de preferencias
- `QLoRA` reduz custo computacional e memoria
- viabiliza experimentos em GPU unica, sem exigir full fine-tuning do backbone inteiro

Alternativas nao escolhidas como abordagem principal:

- full fine-tuning: custo desproporcional para o escopo do projeto
- RLHF/DPO: menos aderentes ao tipo de dado disponivel
- ajuste somente por prompt: insuficiente como estrategia unica para especializacao persistente

## 7. Runtime e trainer separados

Decisao:

- manter o ambiente de treino em container proprio (`trainer`)
- nao acoplar dependencias pesadas de treino ao `docker-agent`

Motivo:

- reduz complexidade do runtime operacional
- separa inferencia de experimentacao
- facilita reproduzir o ambiente de API sem precisar carregar stack de GPU

## 8. Publicacao do resultado como adapter sobre o modelo base

Decisao:

- gerar `adapter` e empacotar no Ollama como novo modelo

Motivo:

- preserva o modelo base original
- facilita comparacao entre baseline e candidato
- simplifica rollback

## 9. Melhorias estruturais antes de ampliar a camada de ML

Decisao:

- priorizar correcoes de catalogo, canonizacao, gates e regressao automatizada antes de introduzir novos modelos auxiliares

Motivo:

- evita usar ML para mascarar falhas de regra ou dado
- melhora a qualidade do dataset que depois sera usado no fine-tuning
- mantem o escopo do TCC tecnicamente defensavel

## 10. Classificador auxiliar em portugues como hipotese futura, nao prioridade atual

Decisao:

- nao introduzir agora um modelo auxiliar como `BERTimbau` para slot filling

Motivo:

- o ganho potencial ainda nao compensa o custo adicional de arquitetura, dados e testes
- a prioridade atual continua sendo estabilizar as regras deterministicas e o fluxo principal

## 11. Recuperacao semantica por embeddings como evolucao candidata para pedidos genericos

Status:

- opcao levantada e considerada promissora para avaliacao futura
- implementacao condicionada ao fechamento das prioridades estruturais e a ganho comprovado em benchmark

Decisao:

- avaliar uma camada de recuperacao semantica sobre as familias reais de `pre_search_part_type`
- acionar essa camada somente quando alias exato e fuzzy nao identificarem `part_query` com seguranca
- usar os scores apenas para selecionar candidatos e apoiar uma pergunta de confirmacao
- gerar no backend uma pergunta curta por template usando somente candidatos controlados, aguardar a resposta do usuario e somente entao consolidar a familia canonica
- usar a LLM para redacao semantica apenas se um benchmark futuro demonstrar ganho de qualidade que justifique a latencia
- reutilizar o historico e o `ConversationState` que o `docker-comm` ja persiste no Redis
- manter a primeira fase restrita a familias do catalogo, sem vetorizar todos os itens do ERP

Motivo:

- pedidos genericos como `aquilo que segura o carro` expressam funcao ou sintoma e nao sao bem resolvidos apenas por igualdade lexical ou distancia de edicao
- embeddings podem aproximar esse texto de familias como suspensao, amortecedor ou mola e oferecer opcoes reais do catalogo
- a confirmacao pelo usuario reduz o risco de transformar proximidade semantica em identificacao incorreta
- o encaixe preserva a arquitetura atual: banco como fonte estrutural, backend como autoridade, LLM como fallback contextual e Redis como estado multi-turno

Limites da decisao:

- similaridade vetorial nao valida compatibilidade veicular
- embedding nao libera `search` sozinho
- a pergunta de confirmacao nao depende obrigatoriamente da LLM
- alias exato, fuzzy matching, regras de catalogo, gate backend e filtros do ERP continuam prioritarios
- falha ou timeout da recuperacao semantica deve seguir pelo fluxo atual
- a adocao definitiva depende de medir acerto `top-1`, cobertura `top-3`, falsos positivos, confirmacao do usuario e latencia

Consequencia:

- o backlog passa a prever dataset semantico curado, prova de conceito, extensao opcional do `ConversationState`, testes multi-turno e rollout por feature flag
- se a prova de conceito nao superar o baseline atual, a camada nao deve ser promovida para o runtime

## 12. Bypass deterministico antes da LLM para casos comprovadamente completos

Decisao:

- liberar diretamente `search` quando extractor, catalogo, regras obrigatorias e score forem suficientes
- aceitar no bypass somente alias exato, `part_code` literal validado ou follow-up simples que preencha o `pending_slot`
- manter todos os casos incertos no caminho de validacao por LLM
- preservar a persistencia conversacional existente no Redis por meio do mesmo `ConversationState`
- permitir rollback por `PRE_SEARCH_DETERMINISTIC_BYPASS_ENABLED=false`

Motivo:

- a bateria real mostrou que a inferencia da LLM era o maior custo nos fluxos mais comuns
- pedidos ja resolvidos pelas regras nao ganham qualidade ao repetir a mesma decisao na LLM
- a medicao real reduziu a latencia de `71668.38 ms` para `1313.73 ms` no pedido completo e de `46730.79 ms` para `926.96 ms` no follow-up

Limites:

- fuzzy sozinho nao libera o bypass
- familia generica, requisito faltante, motor textual ou estado incerto exigem LLM
- o bypass so produz `search`; perguntas e handoffs continuam no fluxo completo
- o gate backend, a proveniencia de `part_code` e a busca/ranking do ERP permanecem autoridades independentes

Consequencia:

- `tool_trace` passa a expor `pre_search_path` e latencia de pre-busca, ERP e montagem de resposta
- GPU continua relevante apenas para reduzir o custo residual dos casos que realmente precisam de inferencia
- `LLM_KEEP_ALIVE` e prompt so devem mudar depois de comparacao mensuravel posterior ao bypass

## 13. Elegibilidade conservadora para perguntas deterministicas

Status:

- contrato definido e testado
- integracao ao runtime concluida

Decisao:

- permitir o `deterministic_ask` somente para uma familia canonica encontrada por alias exato na mensagem atual ou para um pedido explicitamente automotivo sem familia
- calcular `missing_fields`, pergunta e opcoes exclusivamente pelas regras e templates do backend
- escolher sempre o primeiro campo pela prioridade fixa: `part_query`, `vehicle_model`, `vehicle_year`, `engine`, `side`, `position`, `axle`, `variant`
- nao reaproveitar historico antigo para provar a elegibilidade inicial; o historico continua disponivel no fluxo completo da LLM e no tratamento posterior de follow-up
- encaminhar para a LLM qualquer fuzzy isolado, descricao funcional, sintoma, mudanca de assunto, intencao de handoff, candidato de peca nao resolvido ou estado com pergunta pendente
- manter `part_code` fora desse bypass especifico, preservando o caminho que ja valida sua proveniencia

Motivo:

- uma pergunta deterministica so e segura quando o backend conhece tanto o campo ausente quanto a redacao permitida para solicita-lo
- restringir a evidencia a mensagem atual evita que uma familia antiga seja tratada como o assunto atual
- fuzzy e recuperacao semantica expressam aproximacao, nao confirmacao, e por isso nao podem consolidar familia automaticamente

Consequencia:

- o use case tenta `deterministic_bypass` para `search`, depois `deterministic_ask` e somente entao a LLM
- a ativacao possui a feature flag independente `PRE_SEARCH_DETERMINISTIC_ASK_ENABLED`, fallback imediato para LLM e telemetria `pre_search_path = deterministic_ask`
- pergunta, opcoes, criterios e campos ausentes reutilizam o contrato do backend e produzem o mesmo `ConversationState` persistido pelo `docker-comm` no Redis
- a LLM permanece responsavel por todos os casos que nao satisfazem integralmente a politica conservadora

## 14. `no_match` como resultado de consulta, nao prova de incompatibilidade

Decisao:

- tratar zero linhas como ausencia de itens correspondentes aos filtros enviados ao ERP
- listar os criterios pesquisados e separar esse caso de criterio ainda insuficiente ou divergente do contexto anterior
- preservar criterios conhecidos do `ConversationState` somente em continuacoes pendentes da mesma familia
- nunca restaurar `part_code` a partir do estado e nunca reaproveitar criterios quando a familia atual mudou
- manter `handoff.required = false` enquanto o atendimento humano estiver apenas sendo oferecido
- persistir `pending_slot = no_match_retry` para permitir correcao e nova tentativa no mesmo Redis conversacional

Motivo:

- uma consulta sem linhas nao demonstra que a peca seja incompativel com o veiculo; pode haver catalogo incompleto, filtro restritivo, divergencia de cadastro ou item indisponivel na camada pesquisada
- pedir novamente modelo, ano e motor ja informados quebra a coerencia multi-turno e ignora o estado que o `docker-comm` ja conserva
- sinalizar handoff antes da escolha do usuario contradiz a mensagem que apenas oferece essa opcao

Consequencia:

- a resposta permite ao usuario auditar os filtros usados e corrigir somente o dado necessario
- follow-ups de nova tentativa continuam pelo fluxo contextual sem criar store ou chave paralela
- o ERP continua sendo a fonte do resultado comercial, mas o backend limita a interpretacao que pode ser comunicada ao usuario

## 15. Desambiguacao de resultados como estado deterministico multi-turno

Decisao:

- estender `PartItem` com atributos opcionais de desambiguacao provenientes da view existente do ERP
- escolher no backend o atributo que realmente divide os candidatos entre aplicacao, versao, motor, lado, posicao, injecao, transmissao e caracteristicas lexicais controladas como `com/sem ar condicionado`
- armazenar candidatos, opcoes, atributo perguntado, campos ja usados e contador de tentativas em `ConversationState.result_disambiguation`
- persistir esse objeto na mesma chave `conv:{conversation_id}:state` usada pelo `docker-comm`, sem novo banco, chave ou store
- aceitar resposta por numero, valor do atributo, codigo ou titulo exato
- apresentar diretamente ate dez resultados, pois alternativas comercialmente validas
  nao exigem a escolha artificial de um unico codigo
- consultar uma janela de ate 50 candidatos e usar paginas de dez itens quando houver
  excedente e nenhum atributo confiavel separar os resultados
- tratar negacao, mudanca de familia, correcao de filtro, pedido de handoff e limite de tres tentativas sem consultar a LLM

Motivo:

- uma pergunta adicional so ajuda quando a resposta elimina candidatos de forma comprovavel
- a view do ERP ja possui aplicacao, complemento, motor, injecao e transmissao; esses dados sao evidencia melhor que uma pergunta inventada pela LLM
- manter os candidatos no estado existente permite resolver a proxima mensagem sem repetir a busca nem criar persistencia paralela

Limites:

- um atributo so vira pergunta quando produz pelo menos duas assinaturas distintas e entre duas e seis opcoes curtas
- valores extensos ou que nao separam os itens sao ignorados
- a selecao nao afirma compatibilidade; a resposta ainda solicita confirmacao do codigo antes de finalizar
- mudanca de familia limpa a desambiguacao anterior e reinicia o fluxo normal
- correcao de um filtro usado na busca tambem limpa candidatos e resultados
  pendentes; somente a familia pode ser recuperada como contexto quando ela
  foi omitida na frase de correcao

Consequencia:

- buscas com ate dez itens retornam a lista diretamente; buscas maiores perguntam
  somente quando houver discriminador confiavel e, nos demais casos, exibem a
  primeira pagina com a opcao `ver mais`
- a resposta seguinte usa `pre_search_path = result_disambiguation` e nao chama LLM nem ERP
- `result_disambiguation_requested` identifica handoff escolhido pelo usuario e `result_disambiguation_limit` identifica o limite operacional

### Indicadores publicos da busca

- `confidence` representa a confianca heuristica do fluxo na decisao tomada; nao e
  probabilidade comprovada de encaixe da peca
- `score` ordena a relevancia dos candidatos retornados; nao confirma aplicacao,
  disponibilidade ou compatibilidade comercial
- qualquer calibracao numerica desses indicadores depende de exemplos rotulados por
  avaliador humano e das metricas top-1, top-3, incompatibilidade, empate e `no_match`

## 16. Bateria real separa contrato estrutural de aprovacao comercial

Decisao:

- versionar a bateria real em um schema proprio de cenarios e turnos, preservando os 50 casos legados
- usar niveis cumulativos `smoke`, `regression` e `extended`
- automatizar apenas propriedades objetivas, como status, caminho, ferramentas, estado, proveniencia e tipo de acao
- marcar ranking, discriminadores dependentes do ERP e politicas sem resposta unica com `review_required`
- manter uma lista humana separada para promover expectativas comerciais depois da validacao no Streamlit
- gravar execucoes exploratorias em `.tmp/eval/` com nome unico por padrao

Motivo:

- uma assercao ampla pode esconder uma regressao ou falhar por uma mudanca comercial legitima do ERP
- respostas geradas ou inferidas nao devem virar verdade de negocio sem curadoria
- separar os niveis permite feedback rapido sem impedir uma regressao mais ampla antes de releases

Consequencia:

- a bateria passa a ter cobertura multi-turno reproduzivel para `docker-agent` e `docker-comm`
- os relatorios historicos deixam de ser sobrescritos acidentalmente por uma execucao comum
- a lista de validacao mostra exatamente quais casos ainda dependem do responsavel pelo negocio

## 17. Historico anterior e precedencia da mensagem atual

Decisao:

- o runner deve enviar somente mensagens anteriores ao turno avaliado
- uma entidade explicitamente presente na mensagem atual prevalece sobre o estado anterior e sobre a resposta da LLM
- `side`, `position` e `axle` permanecem campos independentes; `eixo dianteiro/traseiro` nao preenche `position`

Motivo:

- respostas futuras no contexto contaminam a validade metodologica da bateria
- troca de veiculo, nova peca e correcoes do usuario sao informacoes novas, nao complementos obrigatorios do estado antigo
- misturar posicao e eixo produz perguntas comerciais incoerentes e filtros incorretos

Consequencia:

- contextos capturados pelo runner sao truncados antes da mensagem atual
- o backend preserva informacoes espontaneas e usa a mensagem atual como autoridade para entidades extraidas
- regressao automatizada cobre vazamento temporal, troca de identidade e separacao eixo/posicao

## 18. Estado multi-item e quantidade conservadora

Decisao:

- adicionar `ConversationState.items` opcional, mantendo `criteria` como item ativo retrocompativel
- criar itens somente para familias reconhecidas em clausulas independentes
- aceitar quantidade apenas com marcador linguistico como `unidades`, `pecas`, `itens`, `x` ou `quantidade`
- preservar frases compostas conhecidas antes da normalizacao de familia

Motivo:

- pedidos reais podem conter varias pecas e criterios diferentes na mesma mensagem
- numeros de ano, modelo, motor e cilindrada nao sao evidencias de quantidade
- reduzir uma composicao a seu substantivo mais conhecido muda o produto procurado

Limite atual:

- a colecao ja e persistida e transportada, mas a pesquisa comercial agregada por item permanece como proxima etapa

## 19. Marca comercial da peca como preferencia

Decisao:

- representar NGK, Nakata, Cofap e marcas equivalentes em `preferred_product_brand`
- manter `vehicle_brand` exclusivamente para a montadora do veiculo
- usar a marca comercial somente como preferencia de ranking no ERP
- continuar retornando itens compativeis de outras marcas quando a preferida nao estiver disponivel

Motivo:

- pedidos reais frequentemente citam uma marca desejada sem exigir exclusividade
- tratar a marca da peca como montadora contamina o criterio do veiculo
- transformar preferencia em filtro rigido pode produzir `no_match` falso e esconder similares validos

Consequencia:

- a LLM, o extractor, o estado conversacional e o dataset preservam a preferencia explicitamente
- o ranking favorece a marca solicitada sem adiciona-la aos filtros obrigatorios da consulta

## 20. Identidade De Familia E Aplicacao Veicular No Contrato ERP V2

Decisao:

- identificar a familia pelo subgrupo canonico do item, antes de qualquer ranking
- preservar uma linha por `produto_veiculos.id_geral` no novo objeto `soccol.item_search_applications`
- exigir marca, modelo, ano, motor e versao na mesma aplicacao; modelo usa igualdade normalizada
- obter motores, injecoes e transmissoes pelas relacoes `produto_veiculos_*`, nunca pelas possibilidades gerais do modelo
- manter intervalos independentes e reconhecer fim aberto somente pela marcacao explicita da aplicacao
- fornecer atributos de desambiguacao apenas das aplicacoes que passaram pelos filtros
- exportar ERP e snapshot pelo mesmo SELECT, em transacao consistente e UTF-8, com verificacao de checksum

Motivo:

- agregados por item cruzavam atributos de veiculos e periodos diferentes; `MIN/MAX` preenchia lacunas inexistentes
- substring aceitava `Golf` ao procurar `Gol`, e texto de acessorio podia superar a peca pedida no ranking
- o ERP usa WIN1252; copiar bytes sem conversao impedia carregar o snapshot no PostgreSQL UTF-8 local

Consequencias:

- o contrato v2 exige migracao coordenada de SQL externo, runtime e fallback
- o snapshot v1 permanece legado; suas colunas agregadas nao permitem reconstruir proveniencia com seguranca
- falta de motor ou ano comprovado pode reduzir resultados; texto livre nao e usado para inventar compatibilidade
- o golden set ERP valida contrato e COPY, incluindo os quatro candidatos controlados da auditoria; `--integration-sql` adiciona auditoria dos SELECTs de origem fornecidos localmente

## Organizacao De Artefatos Em 14/09/2026

- schema e carga do banco local ficam em `db/init/pre_search_init.sql`; o instalador reutiliza somente seu bloco de fallback
- snapshots gzip ficam no Git LFS; manifestos e checksums ficam no Git comum com finais de linha LF
- DDL do ERP pertence a operacao do banco quente e fica fora do Git; o contrato e a proveniencia exigida permanecem documentados
- exportacao le as views instaladas em `REPEATABLE READ, READ ONLY`, em UTF-8 e com ordem explicita de colunas, sem depender do arquivo DDL
- historico de relatorios e backlog legado fica em `HISTORICO.md`; saidas de execucao ficam em `.tmp/eval/`

## 21. Negacao E Conflito De Veiculo Sao Resolvidos Antes Da Busca

Decisao:

- resolver substituicao explicita como `nao quero X, quero Y` para somente Y;
- excluir direcoes negadas da extracao, preservando a direcao afirmativa;
- nao criar `items[]` a partir de uma clausula negativa;
- responder com `intent_resolution` quando a negacao ou correcao nao possui
  alvo afirmativo seguro;
- responder com `vehicle_identity` quando a marca conflita com a relacao
  modelo/montadora comprovada no catalogo; `vehicle_model_brand.csv` alimenta
  essa relacao durante o bootstrap.

Motivo:

- uma busca pode ser estruturalmente completa e ainda contrariar o pedido do
  cliente se uma negativa for lida como item ou filtro positivo;
- marca e modelo contraditorios nao comprovam uma aplicacao veicular.

Consequencia:

- os caminhos `deterministic_bypass`, `deterministic_ask` e LLM passam pelo
  mesmo gate de seguranca antes de chamar o ERP;
- a pergunta resultante fica no `ConversationState`, para que a proxima
  mensagem complete a intencao em vez de manter uma combinacao insegura.

## 22. Contexto Veicular E Identidade De Item Sao Locais A Clausula

Decisao:

- deduplicar itens pela combinacao completa de criterios, e nao somente por
  familia, lado e posicao;
- manter marca, modelo, ano e motor encontrados na propria clausula;
- compartilhar a aplicacao somente quando o veiculo estiver explicitamente
  associado ao conjunto no fim do pedido, como `radiador e pastilha para Gol`.

Motivo:

- dois pedidos da mesma familia podem ser para veiculos e motores distintos;
- herdar o veiculo da frase inteira transforma uma ausencia de dado em filtro
  inventado e pode retornar uma peca incompatível.

Consequencia:

- `ConversationState.items` preserva cada aplicacao para o gate e a pesquisa
  individual posteriores;
- a validacao executavel foi adicionada, mas golden set e bateria ficaram
  pendentes de execucao a pedido do usuario.

## 23. Curadoria Prioriza Novidade Sobre Volume

- revisar conversas por `conversation_id` e comparar candidatas com exemplos
  ja promovidos;
- descartar duplicatas, contexto contaminado e selecao sem aplicacao provada;
- promover somente cobertura nova de familia, estado ou seguranca;
- manter casos bloqueados como `reviewed` ate a evidencia de catalogo existir.

## 24. Falha De Busca E Ausencia De Produto Sao Estados Distintos

Decisao:

- devolver HTTP 503 quando a unica busca ERP nao puder ser executada;
- em pedidos com varias pecas, manter o resultado de cada item, incluindo
  `error`, para que o cliente possa repetir apenas a parte indisponivel;
- registrar os estados por item na captura de revisao e na telemetria.

Motivo:

- `no_match` afirma que a consulta foi concluida sem resultado; usa-lo para uma
  falha de infraestrutura induz o atendimento e a curadoria ao diagnostico
  errado.

## 25. I/O Sincrono Roda Em Workers Limitados

Decisao:

- manter as integracoes existentes sincrona em workers via `asyncio.to_thread`;
- limitar inferencia e busca por configuracao e aplicar prazo externo ao worker;
- aplicar tambem `statement_timeout` no PostgreSQL;
- manter a auditoria da LLM em `ContextVar` por requisicao.

Motivo:

- a migracao completa de todos os clientes para APIs assincronas aumentaria o
  escopo sem melhorar o contrato. O isolamento atual preserva as integracoes e
  impede que uma chamada lenta bloqueie o loop da FastAPI.

## 26. Motor Textual E Uma Opcao Governada Pelo Catalogo

Decisao:

- carregar de `pre_search_engine_option` o nome da motorizacao e seus anos de
  vigencia, alem da lista usada para sugerir respostas;
- em resposta a uma pergunta pendente de motor, canonizar somente uma opcao
  textual inteira do modelo ativo, priorizando a forma mais especifica;
- aceitar a resposta quando algum intervalo conhecido cobre o ano informado;
  se nao houver intervalo, manter a evidencia para a camada posterior, sem
  inventar compatibilidade;
- interpretar tokens como `BE`, `Zetec Rocam`, `Duratec HE`, `Sigma`, `EA111`
  e `EA211` como motor nesse contexto, e nao como codigo de peca.

Motivo:

- o catalogo ja possui esses nomes e intervalos, mas o runtime carregava apenas
  a lista visual e extraia somente cilindrada numerica;
- repetir a mesma pergunta depois de uma resposta catalogada perde evidencia e
  degrada o atendimento.

Consequencia:

- o follow-up preenche o item pendente e avanca para o proximo atributo
  obrigatorio; `coxim amortecedor` ainda pergunta a posicao quando ela faltar;
- uma motorizacao incompatavel com o ano conhecido nao libera busca
  deterministica.

## 27. Lista Comercial E Delimitada Por Aliases Do Catalogo

Decisao:

- localizar todas as ocorrencias exatas e nao sobrepostas de aliases de familia
  em uma mensagem antes de depender de virgulas ou da conjuncao `e`;
- construir cada `SearchCriteria` com o texto entre sua ancora e a proxima,
  preservando quantidade, lado, posicao e aplicacao locais;
- compartilhar uma aplicacao apenas quando ela estiver antes da primeira ou
  depois da ultima peca e o item nao tiver marca ou modelo proprio;
- manter itens sem veiculo como pendentes parciais, em vez de completar seus
  campos com outra clausula da lista.

Motivo:

- pedidos reais enumeram produtos por espacos, abreviacoes e quantidades;
  separar somente por pontuacao colapsava a lista em uma familia;
- copiar ano ou motor de uma peca para outra transforma ausencia de evidencia
  em um filtro falso no ERP.

Consequencia:

- os casos `real_005`, `real_052`, `real_055`, `real_067` e `real_081` cobrem
  listas comerciais, veiculos distintos e sucesso parcial sem frases especiais
  no runtime;
- novos sinonimos continuam sendo adicionados ao catalogo, nao a uma lista de
  excecoes do extractor.

## 28. Prompt Da LLM Residual E Um Contrato De Evidencia

Decisao:

- chamar a LLM somente depois de os caminhos deterministicos nao produzirem
  busca ou pergunta governada;
- enviar o payload residual com fontes separadas e ordem explicita: mensagem
  atual, seed extraido dela, estado do item ativo para campos omitidos,
  mensagens anteriores do usuario para omissoes e mensagens do assistant como
  contexto nao factual;
- instruir a LLM a nao reutilizar historico que conflite com a mensagem atual;
- manter o backend como autoridade para canonizacao, proveniencia de codigo,
  campos obrigatorios, score e decisao de busca.

Motivo:

- um historico misturado sem origem torna facil confundir uma pergunta ou uma
  resposta anterior do assistente com fato informado pelo cliente;
- a LLM deve conduzir casos residuais, nao substituir o contrato operacional.

Consequencia:

- o payload e auditavel por fonte de evidencia;
- uma saida da LLM continua sendo candidata e passa pelos mesmos gates do
  backend antes de chegar ao ERP.

## 29. Direcoes Publicas Usam Vocabulario Unico

Decisao:

- publicar `side` como esquerdo/direito, `position` como dianteiro/traseiro e
  `axle` como eixo dianteiro/traseiro;
- gerar perguntas desses tres campos pelo backend, mesmo quando a LLM sugerir
  outra redacao;
- normalizar equivalentes de genero e ingles na desambiguacao, preservando
  `position` e `axle` como atributos diferentes.

Motivo:

- textos como `lateral`, `frente` e `eixo` sem padrao confundem a resposta do
  cliente e dificultam retomar o estado;
- eixo nao e sinonimo de posicao: cada um filtra uma caracteristica distinta.

Consequencia:

- regras de familia continuam decidindo quando perguntar eixo;
- a desambiguacao pode usar eixo quando os candidatos realmente o separam,
  exibindo uma opcao compreensivel e consistente.

## 30. ERP Quente E A Fonte Operacional; Snapshot E Contingencia

Decisao:

- usar o ERP quente pelo backend `erp_postgres` como fonte operacional da
  busca e manter o snapshot local v2 para contingencia e reproducao;
- distinguir indisponibilidade de ausencia de produto e executar I/O de
  inferencia, PostgreSQL e revisao fora do event loop, com limite, timeout e
  auditoria por requisicao.

Motivo:

- o snapshot permite recuperar e repetir testes, mas nao prova disponibilidade
  comercial atual; falha tecnica nao pode virar `no_match`;
- isolamento evita bloquear saude e misturar auditorias de conversas distintas.

Consequencia:

- beta e avaliacao de ranking devem medir o ERP quente com rotulos humanos;
- o snapshot permanece verificavel sem mascarar falha da fonte operacional.

## 31. Exposicao Externa Separa Processo, Prontidao E Credenciais

Decisao:

- exigir `REVIEW_API_KEY` e `RESPOND_GATEWAY_API_KEY` antes de iniciar com
  `APP_ENV=production`;
- proteger `/review/*` com `X-Review-Key` e proteger somente requisicoes de
  `/respond` que tragam historico ou `ConversationState` com
  `X-Agent-Gateway-Key`, encaminhado pelo `docker-comm`;
- limitar entrada a 2.000 caracteres por mensagem, 20 mensagens de historico,
  10 itens e 50 candidatos no estado;
- manter `/health` sem I/O e usar `/ready` para verificar catalogo, ERP e
  inferencia com timeout curto por dependencia.
- executar warm-up opcional da LLM somente depois de a aplicacao estar pronta,
  em tarefa de fundo, sem reter o startup HTTP.

Motivo:

- revisao e estado conversacional mudam dados ou influenciam a decisao do
  atendimento; nao podem ficar expostos por ausencia acidental de segredo;
- disponibilidade do processo nao prova que catalogo, ERP ou inferencia estao
  utilizaveis, e uma verificacao completa nao pode atrasar o health check.

Consequencia:

- o deploy de producao precisa definir os dois segredos iguais nos pontos
  correspondentes de `docker-agent` e `docker-comm`;
- proxy e orquestrador podem usar `/health` para liveness e `/ready` para
  readiness, sem aceitar um `200` do processo como garantia de busca pronta.

## 32. Servicos Internos Do TCC Ficam No Loopback Ou Na Rede Docker

Decisao:

- publicar no host somente bindings em `127.0.0.1` para manutencao do agente,
  catalogo, Ollama, `docker-comm` e Streamlit;
- retirar a porta publicada do Redis; usar a rede Docker para comunicacao entre
  os containers;
- manter Nginx como unica entrada publica do chat e manter ERP como conexao de
  saida do agente.

Motivo:

- banco, cache, modelo e API interna nao precisam aceitar trafego da internet;
- a configuracao existente do Nginx ja encaminha o chat para o Streamlit no
  loopback, portanto nao ha dependencia funcional de portas publicas do TCC.

Consequencia:

- o deploy precisa confirmar `ss -ltnp`, Nginx e ERP depois do restart;
- o firewall da VPS deve ser revisado sem alterar portas pertencentes a outros
  projetos, como painel, Portainer e Wings.

## 33. Backup Manual Revisado Precede Automacao

Decisao:

- manter backup e restore manuais, ja revisados, como procedimento operacional
  atual para catalogo, regras, fila de revisao, dataset e estado conversacional;
- adiar automacao ate haver evidencia de frequencia, volume ou risco que o
  procedimento manual nao cubra adequadamente.

Motivo:

- a automacao adicionaria infraestrutura e pontos de falha antes de a beta
  demonstrar necessidade operacional concreta.

Consequencia:

- cada deploy relevante continua exigindo o backup manual documentado;
- a automacao deixa de bloquear as proximas entregas e pode retornar ao
  backlog com criterios operacionais mensuraveis.

## 34. Resposta Explicita De Desconhecimento Encerra O Follow-Up Sem Repeticao

Decisao:

- reconhecer respostas curtas de desconhecimento somente quando houver uma
  pergunta governada ativa no `ConversationState`;
- quando os dados atuais nao fornecerem outro discriminador catalogado que
  permita uma busca segura, encaminhar ao atendimento humano imediatamente;
- preservar os criterios ja confirmados e registrar o caminho como
  deterministico, sem enviar `nao sei` para a LLM nem repetir a mesma pergunta.

Motivo:

- `nao sei a motorizacao` nao e evidencia para selecionar um motor e nao pode
  liberar a busca de radiador para Gol 2010;
- insistir no mesmo slot transforma uma ausencia declarada em ciclo de conversa
  e delegar a decisao a LLM permitiria inventar uma restricao.

Consequencia:

- `radiador Gol 2010 -> nao sei a motorizacao` termina em handoff, mantendo a
  aplicacao confirmada para o atendente;
- a politica vale tambem para lado, posicao, eixo, versao, ano e tipo de coxim
  quando forem o slot pendente.

## 35. Alias Comercial E Marca Preferida Sao Evidencias Independentes

Decisao:

- governar `vela` e `velas` como aliases da familia catalogada `velas de
  ignicao automotivas` em `pre_search_part_alias.csv`;
- aceitar quantidade nua apenas quando ela preceder imediatamente um alias
  exato de familia, mantendo ano, motor, cilindrada e outros numeros fora da
  extracao de quantidade;
- manter `preferred_product_brand` como preferencia de produto independente de
  `vehicle_brand`.

Motivo:

- "4 velas NGK para Gol 2010 1.0" contem cinco evidencias distintas; perder
  qualquer uma delas reduz a qualidade da busca ou confunde fabricante da peca
  com a marca do veiculo;
- aliases pertencem ao catalogo auditavel, em vez de a excecoes textuais do
  runtime.

Consequencia:

- a mensagem preserva familia, quantidade `4`, preferencia `NGK`, modelo Gol,
  ano 2010 e motor 1.0;
- aliases mais especificos continuam vencendo o alias curto durante a
  resolucao exata.

## 36. Diagnostico De Ranking E Interno, Limitado E Reproduzivel

Decisao:

- registrar na consulta os candidatos que passaram pela identidade, os
  rejeitados por refinamento do item ou aplicacao, os filtrados e os
  ranqueados, com contagens e amostra limitada a 50 por etapa;
- anexar `search_diagnostics` somente aos logs estruturados e a acao interna da
  fila de revisao; ele nao altera o contrato publico de resposta;
- expor no diagnostico o `score_breakdown` de cada candidato final, inclusive o
  total e componentes ainda com peso zero.

Motivo:

- a bateria humana mostrou empates completos, mas sem saber quais candidatos
  foram eliminados ou por que um entrou na lista nao seria possivel separar
  falha de recuperacao, filtro ou ordenacao;
- observar o inventario inteiro por requisicao adicionaria custo e risco de
  indisponibilidade ao proprio caminho de busca.

Consequencia:

- revisoes futuras podem comparar a mesma consulta no ERP quente e no snapshot
  sem inferir o caminho apenas pela resposta final;
- o log de diagnostico permanece dado operacional sujeito aos mesmos cuidados
  de acesso da fila de revisao.

## 37. Desempate Conservador Precede Calibracao Rotulada

Decisao:

- identidade de familia e aplicacao na mesma linha continuam filtros
  eliminatorios; aplicacao exata nao recebe bonus que possa compensar falha de
  compatibilidade;
- somente `preferred_product_brand`, quando informado pelo cliente, recebe o
  desempate explicito atual; empates restantes usam titulo e codigo apenas para
  ordem estavel;
- manter injecao, transmissao, complemento e atributos comerciais em peso zero
  ate que a bateria rotulada meca Top-1, Top-3, incompatibilidades e empates.

Motivo:

- o baseline de 139 turnos evidencia empates, mas nao fornece rotulos
  suficientes para afirmar que qualquer atributo comercial melhora a escolha;
- dar peso a texto presente no cadastro sem medicao poderia deslocar um item
  compativel para cima apenas por metadado ruidoso.

Consequencia:

- o novo dataset fixa uma preferencia de marca e rejeicoes por aplicacao para
  regressao;
- a proxima bateria no ERP quente decide se algum peso adicional deve ser
  promovido, e a calibracao publica de `score` continua pendente dessa medicao.

## 38. Bateria Real Correlaciona Diagnostico Pelo Trace Da Captura Interna

Decisao:

- a bateria de respostas reais le `final_actions` da fila protegida
  `pre_search_review_interaction` pelo `trace_id` de cada turno e extrai apenas
  a acao interna `search_diagnostics`;
- o alvo direto usa o id criado pela bateria; pelo `docker-comm`, usa o
  `trace_id` gerado e devolvido pelo gateway;
- os artefatos JSON mantem o diagnostico completo, enquanto os dois Markdown
  mostram apenas o resumo operacional; indisponibilidade da fila e registrada
  como evidencia, sem falhar a chamada do chat.

Motivo:

- a resposta publica mostra somente candidatos permitidos e nao permite
  distinguir recuperacao, rejeicao de aplicacao e desempate;
- a fila ja oferece persistencia protegida e correlacionada, evitando criar
  endpoint diagnostico ou expor os candidatos internos ao usuario final.

Consequencia:

- a proxima anotacao de Top-1/Top-3 pode auditar o caminho real do ERP no
  mesmo arquivo da bateria;
- executar o avaliador fora da rede do catalogo produz `unavailable`, o que
  exige repetir a coleta no ambiente integrado antes de concluir ranking.

## 39. Corroboracao De Aplicacao No Reranking Real

Decisao (22/09/2026):

- aplicar `application_corroboration_v1` no SQL compartilhado pelo ERP e pelo
  snapshot, antes do LIMIT; preservar filtros obrigatorios de identidade e
  aplicacao na mesma linha estruturada;
- complementar a base com ano corroborado (+0.04), motor explicito (+0.02),
  versao solicitada corroborada (+0.02), conflito de ano (-0.16) e exclusao
  explicita da versao (-0.16). Sao pesos heuristicos iniciais, nao calibrados;
- anos exigem intervalos fechados de quatro digitos no segmento do modelo;
  versoes podem aparecer em continuacoes do titulo, mas precisam primeiro
  corresponder a aplicacao estruturada. Ausencia de evidencia e neutra;
- consultas por codigo nao recebem esses ajustes. Nao inferir injecao ou
  transmissao nem usar titulo para resgatar aplicacao rejeitada;
- governar JOY/Onix e SURF/Parati por aliases de versao no catalogo, com carga
  aditiva transacional para volumes existentes;
- registrar backend, criterios, aplicacoes, motivos e componentes na captura
  interna, preservando a ordem real dos candidatos no diagnostico.

Motivo e limites:

- o ERP associa `YM6160` a Corolla 2002/2008 apesar do titulo 1998/2002;
  um score empatado nao demonstrava execucao de codigo antigo;
- JOY e SURF eram perdidos antes da consulta. A comparacao destes casos inclui
  tanto a preservacao da versao quanto o reranking, nao apenas troca de pesos;
- esta decisao amplia o desempate apenas por marca da decisao 37. Os tres
  casos investigados sustentam regressao local, nao ganho geral de Top-1/Top-3;
- corrigir divergencias na origem e avaliar a mesma bateria rotulada continuam
  pendentes. O reranking nao comprova compatibilidade comercial.

## 40. Nova Familia Explicita Substitui O Item Pendente

Decisao:

- durante uma pergunta pendente, uma familia reconhecida por alias exato e
  diferente da familia ativa substitui o item ativo; a proxima resposta passa
  a completar a nova familia;
- os dados de veiculo ja informados continuam como contexto da conversa. Se a
  troca ocorrer enquanto o ano ainda e o campo pendente, o ano permanece a
  proxima pergunta para que a nova aplicacao nao use um valor inexistente;
- nomes compostos comerciais entram como aliases auditaveis da familia
  catalogada, sem criar regras por frase no fluxo conversacional.

Motivo:

- em `real_004`, a pergunta pelo ano da polia nao podia fazer `2013` completar
  a polia depois de o cliente trocar explicitamente para rolamentos;
- `real_001` e `real_046` mostraram que separar `bucha estabilizador` ou
  `junta da tampa de valvula` em palavras soltas perde a familia comercial que
  o cliente informou.

Consequencia:

- `real_004` preserva Focus e a posicao dianteira, passa a perguntar o ano dos
  rolamentos e associa `2013` a esse novo item;
- `real_001` conserva bieleta e bucha estabilizador como duas familias, e
  `real_046` reconhece junta da tampa de valvula como uma familia;
- aliases novos exigem a carga normal do catalogo no ambiente onde serao
  exercitados, pois um volume PostgreSQL ja inicializado nao relê o CSV em
  tempo de execucao.

## 41. Refinamento Direcional Apos Busca Encerrada Nao Usa LLM

Decisao (22/09/2026):

- quando uma busca concluida tiver criterios estruturados e o cliente informar
  somente lado, posicao ou eixo, aplicar esse atributo ao criterio anterior e
  pesquisar novamente pelo caminho deterministico;
- a regra e limitada a atributos direcionais explicitos. Familia, veiculo,
  motor, versao, marca preferida e texto comercial continuam no fluxo normal;
- uma pergunta sobre valor nao cria confirmacao de preco: ela apenas pode
  acompanhar um refinamento direcional, e a resposta continua pedindo a
  confirmacao comercial na filial.

Motivo:

- em `real_041`, a primeira busca por amortecedor traseiro do Onix 2018 JOY
  encerrou com quatro itens. `Dianteiro mesmo valor?` e `Preciso dianteiro`
  tinham posicao explicita, mas sem slot pendente caiam no Ollama;
- a fila correlacionada mostrou que o ERP nao era a causa: os dois calls de
  LLM completaram em 140,6 s e 115,3 s, apesar de devolverem criterios validos.

Consequencia:

- ambos os follow-ups preservam familia, Onix, ano, JOY e quantidade, trocam
  apenas a posicao para dianteira e chegam ao ERP sem inferencia residual;
- a regressao parametrizada cobre as duas frases reais. Outros follow-ups que
  nao tenham atributo direcional explicito continuam seguros no caminho usual.

## 42. Divida Deterministica Observada Fica Fora Do Ciclo Atual De Fine-Tuning

Decisao (22/09/2026):

- registrar `real_004`, `real_043`, `real_045_t2`, `real_080_t3`, `real_032`
  e `real_028` como divida deterministica para a Prioridade 4.5, sem bloquear
  a preparacao e a execucao controlada de QLoRA;
- congelar os artefatos da bateria atual como baseline pre-fine-tuning e manter
  esses casos no conjunto de regressao posterior;
- nao promover exemplos desses defeitos para o dataset de treinamento com a
  expectativa de que a LLM corrija familia, estado, filtros ou atributos do
  catalogo. Casos linguísticos revisados continuam elegiveis normalmente;
- manter `confidence` como heuristica de fluxo e `score` como relevancia. A
  calibracao numerica e a nova anotacao global de Top-1/Top-3 ficam para a
  retomada da Prioridade 4.5.

Motivo:

- a bateria atual ja demonstra ganho pareado de reranking e reducao de
  latencia deterministica; nao ha evidência de que pesos ou gates de busca
  sejam o problema principal neste momento;
- os casos restantes pertencem a camadas que o fine-tuning nao deve mascarar:
  entidade, estado conversacional, atributo comercial, identidade de item e
  interpretacao de rejeicoes.

Consequencia:

- o experimento de fine-tuning mede melhor a contribuicao da adaptacao de
  linguagem, sem transformar divida de backend em falso ganho do modelo;
- apos a comparacao baseline/candidato, a Prioridade 4.5 reabre esses casos
  com os traces e rotulos humanos preservados.

## 43. Recuperacao De Turno Da Convert Usa Chave Temporaria E `trace_id`

Decisao (30/09/2026, ajustada em 01/10/2026):

- a primeira chamada ao `POST /test/send` envia origem, conversa, filial e
  texto; o gateway usa esses campos normalizados para evitar trabalho duplicado
  durante a janela de retencao;
- o processamento continua no servidor quando a espera HTTP termina. O Redis
  guarda a concessao do worker e o resultado por cinco minutos. Depois de
  35 s sem resultado, o gateway retorna `processing` com `trace_id`;
- a repeticao do turno pela Convert usa somente `trace_id`. Essa consulta nao
  depende do ultimo texto nem do identificador atual da sala e nao abre um
  novo processamento. `status` controla a espera; `stage` so deve orientar o
  caminho conversacional quando o status for `completed`.

Motivo:

- o bloco HTTP da Convert tem limite de 40 s, e o texto da mensagem ou o ID da
  sala podem mudar apos o bloco `Aguardar`. O trace da primeira chamada e a
  referencia estavel para consultar seu resultado.

Consequencia:

- respostas concluidas podem ser recuperadas sem repetir a inferencia nem
  gravar o mesmo turno de conversa novamente;
- sem ID unico da mensagem de origem, textos iguais na mesma conversa e filial
  dentro da janela ainda podem compartilhar uma chave. A validacao da
  Categoria 1C foi encerrada por confirmacao do usuario em 02/10/2026 e
  registrada no [HISTORICO.md](HISTORICO.md); esse limite de identidade permanece.

## 44. Status De Processamento E Etapa Conversacional Sao Independentes

Decisao (01/10/2026):

- `status=processing` indica que a Convert deve esperar e consultar o mesmo
  turno; somente `status=completed` permite enviar `reply` e usar `stage`;
- para um turno concluido, `handoff.required` prevalece como
  `transfer_to_human`; `request_info` produz `more_info`, mesmo junto com
  candidatos; `show_items` produz `mostrar_produtos` quando nao houver
  handoff nem pergunta; os demais casos seguem por `fallback`;
- conservar `actions` e `items` estruturados e oferecer `items_text` e as
  opcoes sugeridas no `reply` para os blocos de mensagem da Convert.

Motivo:

- conclusao do processamento e proximo passo do atendimento sao decisoes
  diferentes. A Convert precisa distingui-las para nao enviar resposta vazia
  durante a espera nem perder perguntas ou produtos na apresentacao.

Consequencia:

- o gateway fornece o contrato, e o roteamento completo e o handoff no fluxo
  publicado foram aceitos pelo usuario em 02/10/2026, encerrando as Categorias
  1B e 1C. O registro da validacao fica no [HISTORICO.md](HISTORICO.md).

### Encerramento Das Categorias 1B E 1C Em 02/10/2026

- Manter `$.stage` mapeado para `$estado_ia` e as saidas `more_info`,
  `mostrar_produtos`, `transfer_to_human` e `fallback` no fluxo publicado.
- Enquanto `status=processing`, aguardar e consultar o mesmo `trace_id`;
  enviar `$resposta_ia` e avaliar a etapa somente depois de `completed`.
- Apresentar `$itens_ia` quando houver produtos e encerrar as perguntas
  automaticas quando o usuario for transferido ao atendimento humano.
- Aceitar a confirmacao do usuario sobre a validacao ponta a ponta e os
  cenarios controlados ja testados como encerramento operacional dessas
  categorias. A confirmacao nao representa nova execucao automatizada pelo
  agente nem conclui a avaliacao comercial ou as demais pendencias do produto.

## 45. Integracao Do Canal Pelo Sistema Interno Omni/Convert

Decisao (02/10/2026):

- Adotar o sistema interno Omni/Convert como intermediario da conexao com o
  canal WhatsApp, conforme implementacao e equivalencia funcional confirmadas
  pelo usuario, encerrando a Prioridade 4 do backlog original.
- Manter a conexao ao canal e o transporte de mensagens sob responsabilidade
  do sistema interno. O TCC recebe origem, identificador da conversa e filial
  pelo contrato HTTP existente; conserva historico/estado e devolve resposta,
  produtos, perguntas e sinalizacao de handoff.
- Usar o identificador estavel da conversa fornecido pelo intermediario,
  preservando a persistencia existente no Redis. Nao exigir que o TCC receba
  diretamente o telefone para identificar a sessao.
- Retirar do escopo atual o webhook `POST /webhooks/whatsapp` e o envio direto
  pela API da Meta no `docker-comm`. Esses componentes eram uma proposta de
  implementacao e foram substituidos pela conexao existente no sistema interno.

Motivo:

- O objetivo e integrar o atendimento ao canal; a infraestrutura interna ja
  atende a essa funcao, sem exigir um segundo conector no TCC.

Consequencia:

- A entrega fica registrada como integracao via Omni/Convert. O aceite se
  baseia na confirmacao do usuario e na validacao operacional ja encerrada
  nas Categorias 1B e 1C. Este registro nao afirma implementacao de cliente
  Meta no repositorio nem auditoria das regras internas de transporte,
  duplicatas e reentregas do intermediario.

## 46. Adiar Nova Adaptacao Do Modelo Apos O Experimento LoRA

Decisao (19/10/2026), por orientacao do usuario:

- Considerar concluido o experimento de treino LoRA em BF16 de
  `Qwen/Qwen2.5-7B-Instruct`, com comparacao e preservacao dos artefatos.
  Esta execucao nao usou QLoRA 4-bit.
- Manter o modelo ativo e adiar novos treinos, publicacao/validacao do
  adapter no Ollama e a arquitetura de Ollama remoto em GPU com fallback.
  Esses requisitos pendentes passam a Hipoteses Adiadas no [TODO.md](TODO.md),
  sem declarar como concluidas funcionalidades nao implementadas.
- Retomar avaliacao comercial e correcoes deterministicas de catalogo,
  perguntas, filtros e busca. Esta ordem substitui a prioridade anterior
  de preparar fine-tuning como proximo bloco.

Fundamento:

- Na configuracao avaliada, o adapter nao trouxe ganho global: golden isolado
  de 27/27 para 24/27, mais JSON incompleto sob 220 tokens (23/80 para 44/80)
  e maior tempo medio por turno de categorias (2,900 s para 3,435 s).
  Ganhos pontuais nao justificaram promocao. Evidencias e limites estao em
  [HISTORICO.md](HISTORICO.md#experimento-lora-em-gpu-de-19102026).
- A comparacao foi entre original e adapter no mesmo motor Transformers/PEFT
  BF16. O resultado nao prova que toda adaptacao futura seria ineficaz, nem
  mede diretamente a versao quantizada do Ollama.

Condicoes para eventual retomada:

- Demonstrar uma lacuna residual da LLM com exemplos revisados e criterio
  de ganho definido, depois de separar causas de backend/catalogo.
- Endurecer benchmark e proteger splits independentes; tratar a sobreposicao
  exata de seis mensagens golden com o treino e ampliar a cobertura residual.
- Concluir paridade/versionamento de payload, prompt, estado e regras;
  auditar mascara de perda e truncamento antes de outro treino.
- Validar importacao/execucao no Ollama em candidato separado do ativo,
  com comparacao controlada, criterios de promocao e rollback documentados.
  O pacote local preservado permite retomar sem arquivos da VPS antiga.

## 47. Preservar Identidade E Governar Follow-Up Pelo Contexto

Decisao (19/10/2026):

- O backend preserva a identidade composta da peca e a aplicacao explicitamente
  pedida. Modelos/anos no titulo sao contexto; a clausula de aplicacao prevalece.
  Aliases internos nao dividem polia/bomba ou rolamento/amortecedor em pedidos
  independentes. Cada item conserva seus proprios fatos veiculares.
- Contradicao de direcao na mesma peca e negacao nao representavel interrompem
  a busca para confirmacao. Um componente protegido sem identidade catalogada
  pede esclarecimento; nao se amplia automaticamente para a familia interna.
- Uma resposta curta de versao/motor textual preenche o `pending_slot` do item
  ativo. Opcoes do catalogo sao interpretadas pelo modelo/ano anterior; versoes
  desconhecidas e valores textuais adicionais usam prova na mesma aplicacao,
  conservando identidade, ano, motor e demais filtros. Correcao explicita ou
  novo pedido completo continuam prevalecendo sobre o estado anterior.
- Reutilizar `ToolsPort` e o SQL do contrato v2 para a prova contextual: somente
  leitura, timeout existente, limite de um produto, sem relaxamento direcional.
  O valor integral comprovado e salvo em `ConversationState`; nao criar store,
  schema publico ou lista paralela de versoes. Codigo de motor isolado nao
  comprova um deslocamento adicional informado pelo cliente.
- Executar a prova em worker sob o limite de concorrencia ERP e reutiliza-la
  apenas na mesma requisicao. Zero evidencia pede esclarecimento; falha de
  fonte usa o fallback por indisponibilidade e, se necessario, handoff. Zero
  resultados nao aciona outra fonte como tentativa de aprovar uma opcao.

Motivo e alcance:

- As falhas reproduzidas eram de extracao/contexto, anteriores ao ranking;
  novo treino nao corrige sua causa. A LLM permanece responsavel pela linguagem
  residual, com fatos explicitos e gates do backend prevalecendo na saida.
- Os controles estruturais e no snapshot comprovam as invariantes deste lote;
  nao comprovam curadoria de kits/aliases, referencias comerciais ou ganho
  global nas 371 conversas. Esses trabalhos e a implantacao continuam pendentes.
  Evidencias e conclusao local em [PROGRESS.md](PROGRESS.md#identidade-e-follow-up-concluidos-localmente-em-19102026).

## 48. Curadoria De Familias E Refinamentos Tipados

Decisao (19/10/2026):

- Refinar a prova da decisao 47: consultar existencia da opcao veicular na
  mesma aplicacao, separadamente da disponibilidade/identidade do produto.
  O FH 460 revelou uma presilha classificada como caixa de bateria. Excluir
  essa identidade incorreta da busca final sem voltar a perguntar o motor
  comprovado. Essa prova nao retorna produtos nem autoriza sua apresentacao.

- Versionar conceitos, decisoes de alias e scopes nos CSVs
  `pre_search_family_concept.csv`, `pre_search_alias_decision.csv` e
  `pre_search_family_scope.csv`. O bootstrap e o atualizador transacional
  alimentam as mesmas tabelas do catalogo. Manter a classificacao original ERP.
- Revisar os 21 aliases conflitantes com 43 decisoes, incluindo qualificadores
  e erros de escrita relacionados. Unificar trizeta/trizetas; separar bucha de
  carroceria, batentes de carroceria/suspensao e pinos de freio/eixo/combustivel.
  Quinze formas genericas ou vagas permanecem ambiguas e pedem funcao/componente.
  Colisao nova tambem pede esclarecimento, sem desempate pela ordem do dicionario.
- Um alias nao amplia scopes de outra familia. Scopes adicionais precisam de
  registro explicito. Componentes especializados em subgrupos amplos exigem
  classificacao permitida e padrao completo de identidade no titulo: kit de
  amortecedor, kit de dobradica e tapa-po de cilindro sao identidades proprias.
  Reparo, conjunto e peca avulsa nao se tornam equivalentes automaticamente;
  composicao desconhecida pede confirmacao. O bloqueio global de acessorios
  continua aplicado as pecas principais.
- O avaliador reconhece scopes curados de eletroventilador/trizeta, verificando
  componente e aplicacao. Diferenca de subgrupo isolada nao comprova erro;
  titulo semelhante sem scope permitido tambem nao comprova acerto.
- A auditoria dos 86 handoffs por lado/eixo consulta o ERP somente leitura.
  Retirar exigencia direcional padrao apenas de arruelas, correia de comando,
  cabos de velas e velas de ignicao para motos. Manter exigencias nas demais
  familias quando a revisao nao comprovar que sao dispensaveis. Direcao explicita
  continua filtrando mesmo quando nao e obrigatoria; versao exigida nao e
  satisfeita por combustivel ou ABS.
- Acrescentar `fuel`, `transmission` e `abs` opcionais a SearchCriteria e ao
  estado do gateway, mantendo contrato v1.0 e Redis existentes. `variant`
  representa versao veicular ou viscosidade de lubrificante; nao transportar
  ABS/combustivel/cambio nesse campo. `False` e evidencia negativa, nao ausencia.
- Combustivel e cambio precisam de evidencia estruturada na mesma aplicacao;
  ABS usa marcacao explicita do proprio produto. Ausencia de ABS no titulo nao
  comprova produto sem ABS. Abreviacoes direcionais usam limites de palavra;
  posicao e eixo permanecem distintos. Nao alterar pesos de ranking neste lote.
- A resposta da LLM nao pode inventar refinamento tipado. Follow-up parcial
  conserva o atributo informado e continua pedindo a versao completa quando
  necessaria. Novo veiculo/componente nao herda restricoes tipadas de outro.
  Gateway conserva tambem o item ativo e resultados por item do estado existente.

Alcance operacional: implantacao inicial na stack Docker local, autorizada
pelo usuario; atualizacao da VPS e teste externo no Omni/Convert ficam para a
etapa seguinte. Testes estruturais nao certificam referencias comerciais nem
ganho global nas 371 conversas. Evidencias em [PROGRESS.md](PROGRESS.md).

## 49. Grafia De Semieixo E Sugestoes De Motor Por Ano

Decisao (19/10/2026), apos reteste do usuario no Omni/Convert:

- Resolver as grafias `semieixo` e `semieixos` deterministicamente para a mesma
  familia `semi eixo`, com decisoes de alias versionadas. Nao unir a familia
  diferencial nem alterar scopes/requisitos de busca.
- Mostrar apenas motores com ao menos um intervalo valido para modelo/ano,
  aceitando limites inclusivos e intervalos abertos, como no follow-up. Sem ano,
  manter opcoes do modelo; com intervalos conhecidos sem opcao valida, mostrar
  apenas `Nao sei`, sem voltar a sugerir motores de outro ano. Catalogos legados
  sem intervalos conservam as opcoes existentes.
- Nao aceitar D13K460 para FH 460 2016 apenas porque foi sugerido por erro;
  corrigir a pergunta. A prova contextual e a busca final mantem seus filtros.
- Deploy inicial da VPS confirmado pelo usuario; complemento depende de nova
  publicacao e reteste. Nao promover os casos observados automaticamente a treino.
