"""Core application layer."""

