# Reprodução da avaliação local de 26/10/2026

Este diretório contém evidência de pesquisa, não uma atualização da stack ativa.
O documento principal distingue resultados medidos, triagem automática e revisão
comercial ainda pendente. Não importe o dump sobre o banco de atendimento.

## Conferir a entrega

`manifest_entrega.json`, na pasta superior a `tecnico`, contém tamanho e SHA-256
dos arquivos. `freeze_manifest_v2.json` contém os hashes congelados antes da rodada
oficial. Os caminhos deste último são relativos a `tecnico`. Compare os hashes
antes de reproduzir; não regenere o manifesto para encobrir uma divergência.

O ensaio completo exige 3408 arquivos em `runs/rep_*/{categories,structural,golden_flow}/{D,H}`:
371, 170 e 27 por configuração em cada uma das três repetições. Não confunda
`pilot`, `pilot_v2`, aquecimento ou fixtures fictícias de QA com resultados oficiais.

## Consultar sem executar novamente

- `summary.json`: métricas por conjunto, repetição e configuração; contagens reais
  de chamadas ao modelo; estabilidade e recorte golden sem coincidência exata.
- `paired_category_results.json`: diferenças pareadas nas 371 conversas.
- `runs/rep_1/categories/{D,H}/<id>.json`: conversa, pedidos incrementais,
  respostas, estado, critérios, buscas, itens, saída bruta e tempos. As demais
  repetições seguem o mesmo caminho.
- `protocol.json`: configuração efetiva; a versão inicial está preservada ao lado.
- `inputs`: entradas originais, referência de treino e snapshot de catálogo.
- `frozen` e `gateway_frozen`: código e controles congelados; não contêm `.env`.

Para recalcular somente as métricas, Python 3.11 ou posterior é suficiente:

```powershell
python -X utf8 .\analysis\aggregate_results.py
```

Esse comando recalcula JSONs consolidados a partir das saídas já existentes;
não chama a LLM. Exige a bateria completa. A opção `--partial` serve apenas para
acompanhamento, e não certifica conclusão.

## Reexecutar inferência e buscas

Pré-requisitos: Docker Linux, PostgreSQL 16, imagem do agente com as dependências
registradas, Ollama e o modelo `qwen2.5:7b` com digest
`845dbda0ea48ed749caafd9e6037047aa19acfcfd82e704d7ca97d631a0b697e`.
Os pesos de aproximadamente 4,68 GB não foram duplicados nesta entrega. Uma tag
de modelo pode mudar: confira o digest, não apenas o nome.

1. Crie um diretório novo, vazio, para a reprodução. Copie apenas `frozen`,
   `gateway_frozen`, `harness`, `analysis`, `inputs` e `protocol.json`. Não copie
   `runs`, `database_prepared.json` ou `database_sealed.json`: esses são resultados
   da execução anterior. Preserve a entrega original intacta.
2. Use uma nova rede Docker `--internal`, sem publicar portas. Crie contêineres
   com nomes novos, sem substituir os de atendimento. Na rede nova, o PostgreSQL
   deve ter alias `tcc-eval-db-20261026` e Ollama alias
   `tcc-eval-ollama-20261026`, pois o harness resolve esses endereços.
3. No banco exclusivo, crie usuário e base `presearch`, senha de laboratório
   `avaliacao-local`. Restaure `inputs/catalog.dump` usando `pg_restore --no-owner
   --no-privileges -U presearch -d presearch`. É um dump de catálogo sem dados de
   interações de revisão ou treino. Esta senha pertence somente ao laboratório.
4. Monte `frozen` em `/app:ro` e o diretório novo em `/study`. Use `/app` como
   working directory, `PYTHONDONTWRITEBYTECODE=1` e a imagem do agente. Execute
   `python /study/harness/prepare_database.py`. O script importa os CSVs gzip de
   19/10, confere hashes/contagens, aplica os seeds congelados e salva o catálogo
   efetivo. Seu único alvo é o alias do banco isolado acima.
5. Antes das medições, confira os testes com PostgreSQL/Redis exclusivos, seguindo
   as variáveis em `frozen/tests` e `gateway_frozen/tests`. Os XMLs entregues
   documentam 604 testes do agente e 33 do gateway nesta execução. Dependências
   novas ou testes ignorados devem ser registrados, não declarados equivalentes.
6. No banco exclusivo, execute `ALTER DATABASE presearch SET
   default_transaction_read_only=on`. Confirme a configuração numa conexão nova.
   Grave no diretório novo `database_sealed.json` com data, resultado dessa
   conferência e resultados dos controles. Não copie uma certificação anterior.
7. Inicie Ollama exclusivo com pesos montados em somente leitura, limite de
   4 CPUs/8 GB, paralelismo 1 e um modelo carregado. Não altere os pesos do
   Ollama ativo. Confira versão e digest. Não publique porta.
8. Com o mesmo `/app:ro`, `/study`, rede e imagem, execute:

```text
python /study/harness/run_study.py --mode official
```

Não use `--suite` para certificar uma execução completa: o comando final deve
abranger os três conjuntos. O runner salva cada caso e retoma os que faltam,
sem repetir arquivos já concluídos. Se houver interrupção no meio de um caso,
registre o evento; a nova tentativa não deve ser escondida como primeira execução.
Para uma réplica independente, use outro diretório vazio. Não altere labels,
regras ou parâmetros durante a medição.

Após concluir, execute o agregador sem `--partial`; ele exige 3408 registros.
Use `harness/export_review_source.py` no mesmo ambiente somente leitura para
extrair o dossiê dos códigos de referência e retornados. O gerador de fichas
`analysis/build_review_package.py` exige todas as 371 duplas da primeira
repetição. Os geradores de relatório/leitor reconhecem tanto a organização
local original quanto a pasta `tecnico` desta entrega. O pacote de especialistas
já selado não deve ser sobrescrito: o gerador recusa essa operação. Para uma
nova avaliação, use outro diretório/versão e ajuste apenas a raiz de exportação
se escolher outra estrutura, registrando a adaptação sem alterar o código de
medição. A chave e as letras A/B da revisão em andamento devem permanecer iguais.

## Recolher e consolidar revisão humana

Encaminhe somente `pacote_para_especialistas.zip` aos profissionais. Mantenha
`analyst_key.json` reservado ao responsável pela análise até os formulários
independentes terem sido recebidos. Cada pessoa deve usar um ID distinto, avaliar
o pedido antes de revelar as duas saídas e exportar seu próprio JSON.

```powershell
python -X utf8 .\analysis\analyze_human_reviews.py .\respostas\avaliador1.json .\respostas\avaliador2.json --output .\human_review_analysis.json
```

O script não inventa um consenso: apresenta julgamentos individuais, concordância,
kappa quando definido e discordâncias para adjudicação. IDs e experiência são
autodeclarados. O autor deve verificar a independência real, a fonte da evidência
e solucionar divergências com registro. Ausência de item não prova ausência de
produto; “indeterminado” deve permanecer indeterminado.

O lote inicial de 60 foi selecionado por cobertura e suspeitas de problema;
não é amostra aleatória. Para sustentar independência prospectiva, solicite
também os dez novos pedidos do template, com gabaritos definidos por especialista
antes de expor ou ajustar o sistema. Esses pedidos ainda não foram avaliados.

## Limites de comparação

Os tempos representam CPU local, use case e banco, com cache normal de prefixo
e três repetições blocadas por caso. Não medem latência no WhatsApp, carga
concorrente nem desempenho da VPS. Mudanças de hardware, quantização ou digest
criam outra condição experimental. O estudo usa o modelo base Q4_K_M e não o
adapter BF16/LoRA de 19/10. O baseline D é conservador ao encaminhar casos que
chegam à inferência residual; não representa o melhor backend determinístico
possível. Mais resultados ou menos handoffs não significam maior acerto comercial.

Não há certificado de precisão comercial humana nesta entrega. A ficha está
vazia e as respostas de QA foram excluídas. Houve interrupção entre 26 e 27/10:
o Docker Desktop estava desligado ao continuar, e sua inicialização reiniciou
automaticamente os serviços existentes, com as mesmas imagens. O estudo preservou
1809 registros concluídos e retomou os incompletos após verificar banco, hashes
e modelo. O reaquecimento da retomada foi excluído das métricas. Não se trata
de execução contínua: `recovery_20261027.json`, `recovery_warmup_20261027.json`
e `interruption_analysis.json` documentam os segmentos e a sensibilidade de
latência sem pares que atravessaram a interrupção.

Os horários de início originais e os posteriores ao reinício do motor são
checkpoints distintos. `active_services_after.txt` deve coincidir com
`services_after_engine_restart.txt`, e as imagens devem coincidir com o
registro original. Somente os contêineres exclusivos do laboratório são parados
ao encerrar a avaliação; não atualizar ou recriar os serviços de atendimento.
