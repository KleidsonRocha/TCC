# Avaliação final do projeto e protocolo de revisão comercial

Estudo iniciado em 26/10/2026, com retomada registrada em 27/10/2026

Este documento consolida uma nova avaliação técnica do projeto entre 26 e 27/10/2026: comparação do fluxo determinístico com o fluxo híbrido, reexecução em versão congelada e preparação da revisão comercial independente. Os testes automatizados foram executados; a compatibilidade comercial final permanece pendente das respostas de especialistas. Nenhum julgamento humano foi preenchido pelo agente.

Na primeira repetição das 371 conversas, H acionou inferência em 45 casos (12,1%), enquanto D fez zero chamadas. Houve 326 conversas idênticas entre as configurações. Somente H apresentou produtos em 7 casos e somente D em 0. Esses resultados medem comportamento e autonomia; não comprovam, sem revisão comercial, que os produtos adicionais ou encaminhamentos foram adequados. As três repetições completas estão detalhadas abaixo.

| Frente | Entrega realizada | Limite que permanece |
| --- | --- | --- |
| Contribuição incremental da LLM | Ablação pareada D versus H, com três repetições e mesma fonte e código | Benefício comercial depende de julgar perguntas, encaminhamentos e candidatos; D usa política conservadora de handoff residual |
| Validação comercial | Auditoria dos 371 casos (337 com referência) e ficha mascarada com lote inicial de 60 e acesso aos 371 | Necessárias duas revisões humanas independentes e tratamento das discordâncias |
| Versão consolidada | 3408 execuções de caso planejadas e concluídas, além dos testes automatizados | A bateria histórica não se torna amostra aleatória ou gabarito comercial apenas por ser reexecutada |

## 1 Perguntas de pesquisa e alcance

A comparação procura determinar o que muda quando a mesma arquitetura passa a usar inferência residual: recuperação observada, necessidade de encaminhamento, preservação do pedido, repetição de perguntas, erros técnicos e custo de tempo. Não compara uma LLM isolada contra SQL, não cria um novo modelo e não repete o fine-tuning de 19/10/2026. A condição H utiliza o modelo base do Ollama; o adapter LoRA não foi importado nem promovido.

O estudo mede a cópia congelada do código disponível localmente, identificada pelo commit 52e4d7460009d9635445c8ca69c604488b5dacef e por hashes dos arquivos. A diferença de trabalho local foi registrada. A cópia do catálogo foi atualizada com os CSVs congelados e a busca utilizou o snapshot exportado em 19/10/2026: 52.798 produtos e 1.779.443 aplicações. As imagens dos serviços de atendimento foram preservadas. O início do Docker Desktop na retomada provocou o reinício automático dos serviços; os checkpoints registram essa mudança operacional.

## 2 Condições comparadas e intervenção

| Condição | Comportamento |
| --- | --- |
| D sem LLM | Mantém extração, aliases, regras, estado, provas contextuais no banco, desambiguação e busca. Quando chega ao ponto em que seria necessária inferência residual, aplica encaminhamento humano explícito e conservador. Não simula timeout, não fabrica JSON de modelo e não contabiliza essa decisão como falha técnica. |
| H híbrida | Executa os mesmos caminhos determinísticos. Somente o caminho residual chama qwen2.5:7b e mantém os controles existentes do backend sobre a resposta. |

O encaminhamento residual define uma alternativa operacional para D. Portanto, o efeito estimado é relativo a essa política, não ao melhor sistema determinístico que poderia ser desenvolvido. Um handoff pode ser a decisão correta; uma busca adicional pode ser inadequada. A qualidade dessas diferenças precisa do julgamento comercial cego. O código do produto não foi alterado para favorecer uma condição; a intervenção fica no harness de avaliação e preserva os mesmos helpers de preparação antes da inferência.

O tratamento H inclui a inferência e o processamento existente de sua proposta: validação, coerção e possíveis fallbacks do backend. A ablação mede a contribuição operacional desse ramo híbrido em relação ao encaminhamento residual declarado. Ela não separa quanto de cada saída adicional decorreu da geração linguística e quanto decorreu das regras que interpretaram ou repararam a proposta. Os traces e conteúdos brutos permitem investigar essa atribuição por caso; não se deve creditar automaticamente todo produto adicional a raciocínio autônomo do modelo.

As chamadas efetivas ao provedor foram registradas separadamente dos nomes internos de ferramentas. No caminho D, a contagem de chamadas de inferência é zero. Nomes legados como pre_search_validator no trace não foram usados para presumir que houve chamada à LLM.

As contagens de chamadas e as métricas de resposta referem-se aos registros de caso concluídos, incluindo os que terminaram com erro registrado. A tentativa interrompida sem resultado salvo fica identificada separadamente e não pode ser quantificada integralmente por esses registros. Os logs dos serviços isolados são preservados como diagnóstico adicional; incluem pilotos e reaquecimentos excluídos e não devem ser somados indiscriminadamente às medições oficiais.

## 3 Congelamento e execução

| Aspecto | Configuração |
| --- | --- |
| Período registrado (UTC) | 2026-10-26T17:49:42.393400+00:00 até 2026-10-27T13:56:13.968653+00:00 |
| Código | Cópia somente leitura do app, scripts, testes, seeds e documentação; manifestos de hashes antes da rodada oficial |
| Dados | PostgreSQL exclusivo, sem porta publicada, catálogo sem linhas de revisão/treino e snapshot verificado; banco selado com default_transaction_read_only=on |
| Inferência | Servidor Ollama exclusivo, sem porta publicada, pesos existentes montados em somente leitura; qwen2.5:7b, digest 845dbda0ea48ed749caafd9e6037047aa19acfcfd82e704d7ca97d631a0b697e, formato GGUF Q4_K_M |
| Recursos | Docker local com 8 CPUs virtuais e aproximadamente 16,65 GB disponibilizados; servidor de inferência limitado a 4 CPUs e 8 GB; execução em CPU, sem GPU |
| Geração | Temperatura 0, num_predict 220, contexto 8192, num_thread 4, seed 20261026; restrição de JSON existente |
| Repetições | Três por configuração e caso. Ordem D/H determinada por hash, invertida na segunda repetição e contrabalançada na terceira |
| Bloqueio | As três repetições do mesmo caso são executadas antes do próximo. O cache de prefixo do Ollama permanece ativo; não existe cache de resposta da aplicação |
| Aquecimento | Geração curta excluída das métricas. Pilotos ficam separados; uma duração keep_alive inválida foi corrigida antes de qualquer rodada oficial |
| Concorrência | Um caso por vez. Não é teste de carga nem simulação de clientes simultâneos |
| Segurança operacional | Sem chamadas ao ERP quente, sem escrita na fila, sem alteração de pesos, sem mensagens ao WhatsApp e com reinício automático dos serviços pelo Docker Desktop na retomada, documentado separadamente |

Os arquivos protocol_registered_v1.json, protocol.json e freeze_manifest_v2.json preservam o protocolo e a correção de infraestrutura feita no piloto. Os pilotos foram excluídos. As saídas oficiais são salvas por caso concluído; a retomada usa somente arquivos já concluídos. Cada inferência planejada é uma nova chamada. Erros de infraestrutura, caso existam, permanecem separados de resultado vazio e de inadequação comercial.

Houve interrupção externa entre 26 e 27/10/2026. Ao continuar, o Docker Desktop estava desligado e o runner anterior não existia. Foram preservados 1809 registros concluídos, até D da segunda repetição do caso sub-19-10. O motor foi iniciado em 27/10 e reiniciou automaticamente os serviços existentes, com as mesmas imagens. Somente os contêineres do laboratório foram iniciados explicitamente para a retomada. O catálogo, os 199 hashes e o digest do modelo foram reconferidos. Um reaquecimento curto foi registrado e excluído das métricas. O primeiro caso incompleto foi executado novamente; o resultado da tentativa interrompida não foi recuperado e não foi classificado como falha de qualidade do modelo.

O estudo tem dois segmentos de execução. As datas de cada caso permitem separá-los, e a análise complementar mostra os pares de latência que atravessam a interrupção. As diferenças de cache e carga após o reinício limitam a interpretação dos tempos agregados. A rodada não deve ser descrita como uma execução contínua ou um benchmark controlado de capacidade. Protocolo, código, entradas, pesos e critérios de avaliação foram preservados na retomada.

A pausa entre os segmentos não foi somada aos tempos de resposta. A latência por caso é a soma dos tempos dos seus turnos registrados; não corresponde à diferença de relógio entre a primeira execução de D e a execução posterior de H. O período total do estudo inclui a interrupção e não representa tempo contínuo de processamento.

## 4 Conjuntos e unidade de análise

Foram preservados 4695 registros de turno, com pedidos, respostas, estado e telemetria. Um turno é uma interação de entrada/saída, e não uma conversa ou cliente independente.

| Conjunto | Casos por condição e repetição | Como interpretar |
| --- | --- | --- |
| Categorias e subcategorias | 371 | 24 grupos e 347 subgrupos, com 347 mensagens iniciais normalizadas distintas. Mesmas entradas originais; follow-ups respondidos com fatos da referência. Referências duvidosas seguem marcadas para revisão. |
| Regressão estrutural | 170 | 208 turnos fixos por condição e repetição. Replay das mensagens e expectativas existentes; inclui regressões, negação, aliases, estado e contrato. Não é rótulo comercial independente. |
| Golden no fluxo completo | 27 | Checagem dos campos esperados da primeira decisão pré-busca e registro do atendimento completo. Não é a avaliação isolada BF16 do experimento de fine-tuning. |

A soma é 568 identificadores por condição e repetição, totalizando 3408 registros de caso nas duas condições e três repetições. Esses identificadores não são 568 clientes independentes: há sobreposição de mensagens entre conjuntos, duplicação de categoria/subcategoria e várias observações do mesmo caso. Turnos e chamadas também não são tratados como clientes adicionais. Na bateria estrutural, os turnos fixos continuam sendo reproduzidos mesmo após um handoff anterior; essa propriedade testa regressão de contrato, não descreve uma conversa natural continuada após transferência.

Na bateria de categorias, a resposta seguinte depende da pergunta feita e de fatos da mesma referência. As duas configurações podem gerar números diferentes de turnos; o pareamento é por caso inicial. Os pedidos históricos não foram reescritos para favorecer o agente. A auditoria automática acrescenta flags e rastreabilidade, mas não substitui a curadoria humana necessária para uma bateria comercial revisada.

A coleção foi construída para percorrer a taxonomia e inclui pedidos baseados em títulos de catálogo, alguns extensos, ambíguos ou contraditórios. Não é uma amostra aleatória de conversas reais de clientes. O respondente de follow-up é automatizado e utiliza a referência registrada; quando essa referência está errada ou não sustenta a aplicação, a própria conversa simulada pode ficar contaminada. A origem de cada resposta incremental está preservada nos JSONs. A validade comercial e a naturalidade do pedido continuam sendo questões para a revisão humana e para os novos casos prospectivos.

Cobrir as 371 entradas históricas não significa testar todos os produtos, aplicações ou classificações do ERP. A revisão de subcategorias da fonte ausentes do catálogo ativo continua no backlog. Os scopes curados ajudam a preservar identidades existentes, mas não tornam essa bateria uma prova de cobertura integral do catálogo comercial.

## 5 Controles automatizados e resultados estruturais

| Controle | Resultado |
| --- | --- |
| Agente com PostgreSQL de testes | 604 testes aprovados, nenhum ignorado |
| Gateway com Redis de testes | 33 testes aprovados, nenhum ignorado |
| Dependências | Uma advertência de depreciação Starlette/AnyIO em cada suíte; não houve falha nesses controles |
| Modelo e fontes | Manifestos, hashes, contagens de snapshot, catálogo com 19 conceitos e 45 decisões de alias |
| Serviços ativos | Imagens preservadas; início do motor e reinícios automáticos na retomada registrados em recovery_20261027.json e services_after_engine_restart.txt; conferência final em active_services_after.txt |

| Repetição | Estrutural D | Estrutural H | Golden D | Golden H |
| --- | --- | --- | --- | --- |
| 1 | 163/170 | 164/170 | 22/27 | 24/27 |
| 2 | 163/170 | 164/170 | 22/27 | 24/27 |
| 3 | 163/170 | 164/170 | 22/27 | 24/27 |

A aprovação estrutural aplica as expectativas registradas, incluindo algumas expectativas de caminho e ferramenta. Uma diferença intencional da política sem LLM pode reprovar esse teste sem ser uma conduta comercial insegura; as falhas individuais estão preservadas. O golden continua sendo uma checagem parcial de campos esperados e não reprova genericamente todo slot extra. Os resultados não devem ser chamados de acurácia semântica integral.

Achado verificável no cenário search_008: o pedido é “coxim amort ecosport 2008 zetec rocam dianteiro”. D e H perguntam “Qual a motorizacao do veiculo?”, conservando engine nulo, embora ZETEC ROCAM apareça entre as opções oferecidas. A expectativa de busca direta fica reprovada e foi preservada. Nenhuma LLM foi chamada nesse caso; a omissão ocorre no caminho determinístico/catálogo. É necessário investigar o reconhecimento do motor textual e distinguir dado ausente de identificação ainda insuficiente. A segurança de liberar busca apenas com o nome da família do motor precisa de evidência de aplicação e não foi decidida automaticamente nesta análise.

Exemplo do alcance das expectativas: disambiguation_005 passa nas checagens estruturais, mas registra o mesmo texto de apresentação de quatro opções após “radiador focus 2010 1.6”, “talvez”, “aquela” e “indefinido”. As três respostas posteriores acionaram a LLM. O registro não comprova que essa interação seja comercialmente útil ou que tenha resolvido a ambiguidade. Ele mostra por que aprovação de contrato, condução conversacional e adequação dos produtos precisam de julgamentos distintos; a conversa e suas ações completas estão preservadas no leitor.

| Casos estruturais conferidos, repetição 1 | Evidência observada | Interpretação e próxima verificação |
| --- | --- | --- |
| real_004_regression | Após polia da bomba d’água, o usuário pede rolamentos e informa 2013. O estado volta de rolamentos para polia nas duas condições. | D também reproduz a troca sem inferência: revisar precedência do componente atual sobre o histórico. É dívida determinística já registrada no projeto, ainda reproduzida. |
| disambiguation_002 | H reapresenta as três opções do EcoSport após “nenhuma dessas”; D encaminha. A expectativa no_match_retry fica reprovada. | Revisar rejeição de lista curta e impedir que uma nova inferência ignore a rejeição explícita. Não equivale à rejeição de uma página parcial. |
| disambiguation_007 | Após rejeitar a página visível de dez entre doze opções, D/H mostram as duas restantes, sem inferência. | O código atual exclui os candidatos visíveis e permite os restantes; reconciliar a expectativa antiga de no_match_retry com essa política de paginação. Não classificar isso automaticamente como mesma falha do caso anterior. |
| erp_batentes_s10_1996_dianteiro | “Batente” provoca pergunta de componente/função; “dianteiro” não resolve a família e H encaminha. | A curadoria vigente separa batente de carroceria/suspensão. A expectativa antiga de pesquisar “batentes” precisa revisão sem remover a exigência de identidade. |
| real_046_regression | A consulta de junta da tampa de válvula retorna vazio e items_contains reprova porque a lista de critérios no estado não está materializada. | items_contains verifica ConversationState.items, não produtos do ERP. Reconciliar representação de solicitação única; não transformar essa mensagem em falso negativo confirmado sem candidato e mesma aplicação. |

Essa triagem preserva os escores registrados e evita tratar todas as reprovações como defeito da LLM ou como referência obsoleta. O inventário completo está em checagens_e_falhas.md e failures_and_controls.json. Critérios de contrato, texto, estado e catálogo devem ser revisados com sua fonte normativa e evidência antes de produzir outra versão de expectativas.

| Reprovações H no golden da primeira repetição | Conferência no fluxo | Limite da interpretação do escore |
| --- | --- | --- |
| ask_correia_side | A regra vigente deixou de exigir lado para correia de comando; o primeiro validador decide search. | A expectativa antiga de pedir lado não acompanha a curadoria atual. |
| ask_coxins_position | O agente pergunta se o coxim é de motor/câmbio ou amortecedor antes de pedir posição. | A pergunta atual prioriza identidade; o golden ainda espera position. |
| search_multi_item_gate_radiador_bandeja | O primeiro retorno pré-busca mistura CORSA com o radiador, mas o use case separa radiador/GOL/2010 e bandeja/CORSA/2011; a busca registrada usa apenas o Gol e a bandeja aguarda lado. | O escore verifica o primeiro retorno, não o estado/consulta finais. É evidência de divergência entre etapas do contrato, sem demonstrar busca final cruzada entre veículos. |

Os resultados 22/27 em D e 24/27 em H foram mantidos conforme o avaliador original, em todas as repetições. A triagem acima não os transforma retroativamente em aprovação total. Para outro benchmark, é necessário versionar expectativas alinhadas à política atual e decidir explicitamente qual etapa é avaliada; comparação de modelo isolado e comportamento final do runtime não podem ser confundidos.

## 6 Comparação das conversas por categoria

| Indicador da repetição 1 | D sem LLM | H híbrida |
| --- | --- | --- |
| Casos | 371 | 371 |
| Turnos | 539 | 556 |
| Casos com alguma busca | 187 | 199 |
| Casos com produtos apresentados | 165 | 172 |
| Triagem automática coerente com cadastro | 160 | 167 |
| Triagem de possível divergência cadastral | 5 | 5 |
| Casos com handoff | 176 | 159 |
| Repetição de slot/resposta no simulador | 5 | 10 |
| Casos com erro técnico | 0 | 0 |
| Chamadas de inferência | 0 | 57 |

| Repetição | Casos expostos ao caminho residual em algum braço | Só H apresentou itens | Só D apresentou itens | Conversas idênticas |
| --- | --- | --- | --- | --- |
| 1 | 45 | 7 | 0 | 326 |
| 2 | 45 | 7 | 0 | 326 |
| 3 | 45 | 7 | 0 | 326 |

| Motivo de término da simulação, repetição 1 | D | H |
| --- | --- | --- |
| human_handoff | 176 | 159 |
| items_presented | 165 | 172 |
| pergunta_sem_resposta_comprovada | 25 | 30 |
| repeated_question | 5 | 10 |

Uma redução de handoffs também pode terminar em nova pergunta sem uma resposta comprovada disponível na referência. Por isso, produtos apresentados, encaminhamento e simulação não concluída são mostrados separadamente. A falta de resposta do simulador não demonstra que um cliente real seria incapaz de responder, nem garante que a pergunta foi necessária.

| Casos com apresentação somente em H, repetição 1 | Pedido inicial | Término em D | Códigos apresentados em H |
| --- | --- | --- | --- |
| sub-3-20 | Preciso de POLIA 6PK BOMBA DA ÁGUA VW GOL/PARATI/SAVEIRO/SANTANA 97/ MOTOR AP - 6 CANALETAS para SAVEIRO 2005 motor 2.0 | human_handoff | COR-78654 |
| sub-5-10 | Preciso de CABO CÂMBIO ENGATE/SELEÇÃO DAS MARCHAS GM AGILE/MONTANA 2014/ para MONTANA 2013 motor 1.4 | human_handoff | YM245841 |
| sub-10-10 | Preciso de GARFO TULIPA ESQUERDO FORD FOCUS 2.0 2000/2008 AUTOMATICO/MANUAL - 26 DENTES para FOCUS 2009 motor 2.0 esquerdo | human_handoff | AL-1259, NJH09-204D, AL-1204 |
| sub-12-10 | Preciso de LONA DE FREIO GM MONZA/KADETT 93/ - CORSA PICK-UP 1.6 para MONZA 1995 motor 1.8 traseiro | human_handoff | CB/41, CB/40 |
| sub-12-20 | Preciso de SAPATA DE FREIO TRASEIRA GM AGILE 1.4 2009/2014 - CORSA  1.4 2007/2012 - C/LONA para AGILE 2010 motor 1.4 traseiro | human_handoff | CB/49-CPA |
| sub-19-10 | Preciso de ROLAMENTO AMORTECEDOR FIAT PALIO/SIENA/STRADA/TEMPRA para PALIO 2009 motor 1.0 dianteiro | human_handoff | 7130071100 |
| group-19 | Preciso de ROLAMENTO AMORTECEDOR FIAT PALIO/SIENA/STRADA/TEMPRA para PALIO 2009 motor 1.0 dianteiro | human_handoff | 7130071100 |

A tabela enumera todos os casos de apresentação adicional dessa repetição, sem selecionar apenas exemplos favoráveis. São candidatos para inspeção, não novos acertos comerciais confirmados. As conversas completas, filtros e aplicações do catálogo estão no leitor e no dossiê; a revisão mascarada deve ocorrer antes de entregar esta identificação das configurações aos avaliadores.

Essas diferenças quantificam a contribuição operacional da inferência para esta coleção. Não demonstram sozinhas ganho de precisão: o contador de produtos adicionais pode incluir candidatos inadequados, e o handoff adicional pode ser necessário. A triagem verifica classificação, identidade curada e relações cadastradas, mas depende da referência e não certifica aplicação física. A validação humana das saídas A/B é a etapa que permitirá julgar se cada mudança foi benéfica, neutra ou prejudicial.

O motivo repeated_question interrompe a simulação quando o par (pending_slot, resposta incremental gerada pelo simulador) já apareceu no mesmo caso. Não compara semanticamente todas as perguntas do assistente e pode refletir uma referência inadequada ou uma resposta insuficiente que voltou a ser usada. Portanto, o contador não é uma taxa confirmada de perguntas desnecessárias. A ficha humana avalia repetição, necessidade da pergunta e preservação dos fatos no contexto completo.

## 7 Latência e saídas brutas

| Repetição | Média por turno D em s | Média por turno H em s | P95 por turno D em s | P95 por turno H em s | Média pareada H menos D por caso em s |
| --- | --- | --- | --- | --- | --- |
| 1 | 1,49 | 6,87 | 2,88 | 54,18 | 8,14 |
| 2 | 1,47 | 5,69 | 2,85 | 38,50 | 6,39 |
| 3 | 1,48 | 5,64 | 2,88 | 36,20 | 6,30 |

| Repetição | Chamadas H | JSON bruto completo H | Saídas cortadas H | Fallback de saída no backend H |
| --- | --- | --- | --- | --- |
| 1 | 57 | 57 | 0 | 0 |
| 2 | 57 | 57 | 0 | 0 |
| 3 | 57 | 57 | 0 | 0 |

JSON bruto completo significa que o conteúdo pôde ser analisado sintaticamente por json.loads. Esse contador não certifica todos os campos do contrato, ausência de slots extras ou correção comercial. O backend mantém sua validação/coerção e registra separadamente o uso de fallback. Saída cortada é identificada pelo motivo length ou pelo limite de tokens atingido junto com JSON não analisável; os conteúdos originais estão preservados para conferência.

Tempos são wall clock do use case, com banco e inferência locais isolados, excluindo a inspeção cadastral independente. Não incluem transporte do WhatsApp, gateway ou túnel SSH. Média, mediana e P95 completos estão em summary.json; o P95 usa interpolação linear. A latência por caso e por turno são métricas diferentes, especialmente quando as configurações fazem quantidades diferentes de perguntas.

O relógio para quando o fluxo automatizado termina ou encaminha o caso. O trabalho e o tempo de atendimento humano após um handoff não foram medidos. Portanto, um encaminhamento rápido de D não equivale a uma resolução mais rápida para o cliente, e os tempos não permitem calcular isoladamente a economia total de operação ou o custo de substituição do atendente. A utilidade da autonomia adicional depende também de qualidade, risco e custo humano.

As repetições do mesmo caso foram blocadas, e o cache normal de prefixo pode reduzir o custo de prefill nas seguintes. Por isso, cada repetição é mostrada separadamente. A máquina também executa outros serviços, com limites de CPU aplicados ao estudo. Estes números não são um benchmark de carga, uma estimativa de capacidade na VPS nem uma comparação direta com o experimento BF16 de 19/10. Três repetições descrevem estabilidade, sem garantir independência estatística ou inferência sobre clientes futuros.

| Repetição | Pares totais | Pares no mesmo segmento | Diferença média H menos D por caso, todos (s) | Diferença sem pares entre segmentos (s) |
| --- | --- | --- | --- | --- |
| 1 | 371 | 371 | 8,14 | 8,14 |
| 2 | 371 | 370 | 6,39 | 5,95 |
| 3 | 371 | 371 | 6,30 | 6,30 |

Esta sensibilidade não altera a comparação principal nem remove resultados de qualidade. Apenas apresenta a latência com e sem os pares cuja execução D/H atravessou a interrupção: [('sub-19-10', 2)]. Os demais agregados por segmento são descritivos, pois contêm casos diferentes e não constituem um experimento causal antes/depois do reinício.

## 8 Estabilidade e independência

| Conjunto | Casos com conversa diferente entre as três repetições em D | Casos com conversa diferente entre as três repetições em H |
| --- | --- | --- |
| categories | 0 | 0 |
| structural | 0 | 0 |
| golden_flow | 0 | 0 |

A assinatura compara mensagem do cliente, texto de resposta, critérios, itens e estado, sem usar tempos ou identificadores aleatórios. Estabilidade não significa correção: um erro determinístico pode se repetir nas três rodadas. O arquivo paired_category_results.json preserva as mudanças por caso, e os identificadores de variação ficam em summary.json.

| Conjunto | Coincidência exata da mensagem inicial com treino | Interpretação |
| --- | --- | --- |
| Categorias | 0 | Não foi encontrada coincidência exata; paráfrases, padrões e conhecimento prévio continuam possíveis |
| Golden | 6 | Mostrar também o subconjunto de 21 sem coincidência exata |
| Estrutural | 70 | Conjunto de regressão conhecido no desenvolvimento; não é teste retido independente |

| Repetição | Golden sem coincidência D | Golden sem coincidência H |
| --- | --- | --- |
| 1 | 18/21 | 19/21 |
| 2 | 18/21 | 19/21 |
| 3 | 18/21 | 19/21 |

A auditoria adicional não encontrou payloads completos idênticos entre os splits exportados de treino, validação e teste. Há mensagens curtas em comum entre splits, o que isoladamente não prova compartilhamento da conversa. Os metadados exportados não preservam conversation_id original; portanto, não é possível certificar retrospectivamente o isolamento por conversa. O modelo usado aqui é o base, não o adapter treinado nesses dados, mas os conjuntos também orientaram o desenvolvimento das regras. Um teste prospectivo independente exige novos pedidos e gabaritos congelados antes de executar ou ajustar o sistema.

## 9 Auditoria das referências

| Verificação automática | Resultado |
| --- | --- |
| Casos | 371 |
| Casos com referência | 337 |
| Códigos distintos de referência | 314 |
| Códigos encontrados no snapshot | 314 |
| Mensagens iniciais normalizadas distintas | 347 |
| Casos com pelo menos um sinal de revisão | 107 |

| Sinal para investigação | Casos |
| --- | --- |
| no_reference_product | 34 |
| family_canonical_mapping_unresolved | 15 |
| reference_scope_or_component_identity_requires_review | 41 |
| request_title_and_taxonomy_resolve_to_different_families | 21 |
| multiple_position_terms_requires_human_interpretation | 2 |
| multiple_side_terms_requires_human_interpretation | 1 |

Os sinais podem se sobrepor e não são rótulos de erro comercial confirmado. Alguns significam falta de referência ou uma família ambígua que deveria provocar esclarecimento. Outros indicam divergência de classificação, composição ou texto do pedido. A existência do código confirma apenas que o registro está na fonte; não demonstra que a referência deveria aparecer para aquela solicitação. Nenhum caso foi retirado da comparação principal por ter um desfecho desfavorável.

## 10 O que pedir aos especialistas

Solicite duas avaliações independentes de profissionais com conhecimento de autopeças e aplicações veiculares. O autor pode realizar uma delas, mas é necessário outro avaliador. Cada pessoa registra seu identificador e experiência, interpreta a solicitação antes de abrir as saídas e exporta seu próprio JSON sem consultar o outro. Após as duas revisões, preserve os arquivos originais, calcule concordância e adjudique divergências em registro separado, preferencialmente com terceiro especialista.

O pacote para especialistas contém uma ficha HTML offline, instruções, 21 perguntas e um modelo para dez novos casos independentes. O lote inicial tem 60 casos, cobrindo os 24 grupos e priorizando divergências e referências a revisar. Todos os 371 casos ficam disponíveis. Essa seleção é intencional para diagnóstico; sua taxa de adequação não deve ser generalizada como acurácia aleatória dos clientes.

| Antes de abrir as saídas | Ao julgar A e B |
| --- | --- |
| Identificar peça e composição corretas; distinguir kit, reparo, acessório e conjunto | Verificar preservação de identidade e aplicação, correções e negações |
| Separar dados informados e informações indispensáveis ainda ausentes | Avaliar necessidade das perguntas, repetição e encaminhamento |
| Conferir referência e códigos com fonte, data e mesma aplicação | Julgar Top-1, existência de compatível no Top-3 e códigos individualmente |
| Indicar se é possível pesquisar, se é preciso perguntar ou encaminhar | Classificar ausência: adequada, falso negativo com prova ou indeterminada |
| Registrar evidência e sua suficiência, sem inventar lacunas | Avaliar adequação final, risco e preferência entre as saídas |

Para confirmar falso negativo, o avaliador precisa citar um candidato cuja mesma aplicação atenda aos critérios do pedido. Ausência no recorte do dossiê, produto da mesma categoria ou preferência do vendedor não bastam. Caso consulte um ERP mais recente, deve registrar data e eventual mudança desde o snapshot de 19/10/2026. Quando não conseguir verificar uma família, deve responder indeterminado; falta de evidência não vira erro automaticamente.

As letras A e B alternam por caso e não incluem nome de modelo, trace, latência ou score automático. O texto das respostas ainda pode permitir inferências sobre o comportamento, portanto isso é mascaramento de condição, não garantia de cegamento perfeito. A interpretação inicial é registrada antes de abrir as saídas; edições posteriores ficam marcadas. O formulário passou por verificação de sintaxe e testes de fluxo em DOM simulado; não havia navegador de automação disponível para uma inspeção visual nesta sessão.

## 11 Como incorporar as respostas humanas

Envie apenas pacote_para_especialistas.zip aos revisores. Mantenha analyst_key.json e o relatório técnico com o responsável pela análise até concluir as revisões. A ficha não envia dados para nenhum servidor. Exporte os JSONs a cada sessão, pois o armazenamento do navegador é apenas auxiliar. Revisão, adjudicação e fonte de evidência precisam ficar versionadas separadamente, sem promover automaticamente os exemplos para treino.

O script analysis/analyze_human_reviews.py aceita os arquivos exportados e a chave privada, verifica study_id e identificadores distintos, apresenta contagens por avaliador, concordância e Cohen kappa, além da lista de divergências. Ele não escolhe silenciosamente um gabarito nem chama um julgamento individual de acurácia adjudicada. Casos indeterminados e edições de interpretação após ver as respostas precisam permanecer identificados nos denominadores.

As contagens estritas de ranking positivo usam o mesmo subconjunto pareado em D e H: pedido inicial coerente e já pesquisável, evidência prévia suficiente, pelo menos um código confirmado, sem edição posterior da referência e com Top-1/Top-3 determinados nas duas saídas. Esse recorte não representa a taxa de acerto de todos os atendimentos; pedidos inicialmente incompletos ficam fora dele. Seus julgamentos brutos continuam disponíveis nas contagens e formulários individuais. A concordância usa os dois primeiros arquivos de avaliadores informados, identificados na saída; a independência real e a experiência devem ser verificadas pelo autor.

Para fortalecer a independência futura, peça dez pedidos reais anonimizados ainda não usados nas baterias, com contexto, respostas de complementação, ação correta e evidência de produtos compatíveis ou de ausência. Congele os rótulos antes de rodar o sistema e mantenha todos os turnos de uma conversa no mesmo grupo. Esse material depende do especialista e permanece em branco no modelo entregue.

## 12 Conclusão e pendências reais

A execução técnica isola a presença da inferência residual em uma arquitetura comum e quantifica seus efeitos observáveis. A rodada consolidada oferece uma versão identificada, três repetições e rastreabilidade dos casos; os controles de fonte, código, sobreposição e estabilidade ficaram documentados. Isso fortalece os pontos de ablação e consolidação que estavam pendentes.

Ainda não existe, nesta entrega, uma nova taxa de precisão comercial validada por dois especialistas. Ela não pode ser produzida apenas pelo agente ou pela consulta ao ERP, pois o próprio cadastro e as referências podem estar errados. A ficha e as perguntas são a parte que o autor deve solicitar aos profissionais. Após receber as respostas, será possível julgar se a maior autonomia da LLM compensou seus custos e riscos nos casos residuais, com denominadores e discordâncias explícitos.

A versão congelada também preserva falhas conhecidas, inclusive a governança de motor textual dentro da desambiguação de resultados relatada no Logus. Não houve correção de produção durante a medição. Os 604 testes aprovados não eliminam essas lacunas nem substituem a avaliação comercial. Aceite do canal e resultados da VPS continuam separados deste ensaio local em CPU.

## 13 Arquivos e reprodução

| Arquivo ou pasta | Finalidade |
| --- | --- |
| relatorio_avaliacao_final.html e .md | Este documento, em leitura no navegador e versão editável |
| leitor_conversas.html | Consulta offline de todos os casos, com filtros, comparação D/H, três repetições e links para JSONs completos |
| checagens_e_falhas.md | Inventário de todas as expectativas estruturais/golden reprovadas e erros técnicos, com links para os registros |
| pacote_para_especialistas.zip | Único pacote a encaminhar aos avaliadores; não contém a chave D/H |
| para_especialistas/ficha_revisao_comercial.html | Ficha offline com pedidos, dossiê, saídas A/B e exportação das respostas |
| para_especialistas/PERGUNTAS_PARA_O_ESPECIALISTA.md | As perguntas prontas para solicitar aos profissionais |
| para_especialistas/modelo_novos_casos_independentes.json | Dez fichas em branco para pedidos prospectivos |
| tecnico/protocol.json e freeze_manifest_v2.json | Protocolo e hashes antes da execução oficial |
| tecnico/summary.json e paired_category_results.json | Métricas consolidadas e diferenças pareadas por caso |
| tecnico/runs/rep_1, rep_2, rep_3 | Respostas, estado, buscas, saídas brutas, tempos e erros de cada caso |
| tecnico/runtime_logs | Logs dos serviços isolados, com pilotos/reaquecimentos e recuperação; não equivalem apenas às chamadas oficiais |
| tecnico/input_audit.json e independence_audit_extended.json | Auditoria de referências, duplicação e sobreposição |
| tecnico/recovery_20261027.json e interruption_analysis.json | Interrupção, retomada e sensibilidade da latência; reaquecimento excluído em recovery_warmup_20261027.json |
| tecnico/agent_tests.xml e gateway_tests.xml | Resultados dos controles automatizados |
| tecnico/analyst_key.json | Chave das configurações por caso; não entregar antes da revisão cega |
| tecnico/analysis e tecnico/harness | Consolidadores, leitura dos formulários e scripts de execução |
| tecnico/inputs e tecnico/frozen | Entradas, snapshot e código congelados para reprodução |

A reprodução exige ambiente Docker, PostgreSQL, Ollama e os pesos com o digest registrado. Os pesos não foram duplicados no pacote. Use rede e banco exclusivos, nunca restaure o dump sobre o serviço ativo, preserve as entradas e gere um novo diretório de saídas. Uma nova máquina ou mudança de contexto/quantização constitui outra condição de desempenho. Instruções operacionais e limites estão em tecnico/REPRODUCAO.md.
