"""Create complete paired JSON, CSV, JSONL, Markdown and offline HTML reports."""
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import html
import json
from pathlib import Path
import statistics
import runpy

ROOT=Path(__file__).resolve().parent
MODELS=['qwen-base-bf16','qwen-ft-bf16']
OVERLAP=json.loads((ROOT/'dataset_overlap.json').read_text(encoding='utf-8'))
NORMALIZE=runpy.run_path(str(ROOT/'frozen_code/app/infra/pre_search_text.py'))['normalize_pre_search_text']

def criteria_differences(case):
    differences=[]
    for index,search in enumerate(case.get('searches',[]),1):
        for field in ['vehicle_model','vehicle_brand','vehicle_year','engine']:
            provided=case.get('supplied_facts',{}).get(field)
            used=search.get('criteria',{}).get(field)
            if provided is not None and used is not None and NORMALIZE(str(provided))!=NORMALIZE(str(used)):
                differences.append({'search':index,'field':field,'provided':provided,'used':used})
    return differences

def write_json(path,data): path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
def stats(values):
    values=sorted(values)
    return {'count':len(values),'mean_s':statistics.mean(values) if values else None,
        'median_s':statistics.median(values) if values else None,
        'p95_s':values[int((len(values)-1)*.95)] if values else None,'sum_s':sum(values)}

def all_turns(suite,case):
    if suite=='categories': return case.get('turns',[])
    return [case.get('end_to_end',{})]

def json_valid(call):
    try:
        json.loads(call['response']['message']['content'])
        return True
    except (KeyError,ValueError,TypeError): return False

def summarize(suite,results):
    turns=[t for c in results for t in all_turns(suite,c)]
    searches=[s for t in turns for s in t.get('searches',[])]
    llm=[call for t in turns for call in t.get('llm_calls',[])]
    report={'completed':len(results),'turns':len(turns),'turn_errors':sum('error_type' in t for t in turns),
        'turn_latency':stats([t['latency_s'] for t in turns if 'latency_s' in t]),
        'turn_latency_with_llm':stats([t['latency_s'] for t in turns if t.get('llm_called')]),
        'turn_latency_without_llm':stats([t['latency_s'] for t in turns if not t.get('llm_called')]),
        'llm_calls':len(llm),'llm_errors':sum('error' in c for c in llm),
        'llm_roundtrip_latency':stats([c['latency_s'] for c in llm]),
        'llm_generation_latency':stats([c['response']['eval_duration']/1e9 for c in llm if 'eval_duration' in c.get('response',{})]),
        'generated_tokens':sum(c.get('response',{}).get('eval_count',0) for c in llm),
        'valid_raw_json_outputs':sum(json_valid(c) for c in llm),
        'invalid_or_incomplete_raw_json_outputs':sum(not json_valid(c) for c in llm),
        'outputs_at_token_limit':sum(c.get('response',{}).get('done_reason')=='length' for c in llm),
        'complete_json_at_token_limit':sum(c.get('response',{}).get('done_reason')=='length' and json_valid(c) for c in llm),
        'truncated_llm_outputs':sum(c.get('response',{}).get('done_reason')=='length' and not json_valid(c) for c in llm),
        'backend_llm_fallback_turns':sum(bool(t.get('backend_audit',{}).get('llm_fallback_used')) for t in turns),
        'searches':len(searches),'search_errors':sum('error' in s for s in searches),
        'search_latency':stats([s['latency_s'] for s in searches if 'latency_s' in s]),
        'returned_item_occurrences':sum(len(s.get('returned_ids',[])) for s in searches)}
    if suite=='categories':
        report['verdicts']=dict(Counter(c['verdict'] for c in results))
        report['stop_reasons']=dict(Counter(c['stop_reason'] for c in results))
        report['conversations_with_llm']=sum(any(t.get('llm_called') for t in c['turns']) for c in results)
        report['conversations_with_known_vehicle_fact_filter_mismatches']=sum(bool(criteria_differences(c)) for c in results)
    else:
        excluded=set(OVERLAP['golden']['train'])|set(OVERLAP['golden']['validation'])
        for label,group in [('all',results),('without_exact_train_validation_overlap',[c for c in results if c['id'] not in excluded])]:
            criteria_total=sum(len(c['input']['expected'].get('criteria',{})) for c in group)
            missing_total=sum(len(c['input']['expected'].get('missing_fields_contains',[])) for c in group)
            percentage=lambda value,total:round(100*value/total,2) if total else None
            report[label]={'total':len(group),'passed':sum(bool(c.get('evaluation',{}).get('case_pass')) for c in group),
                'decision_correct':sum(bool(c.get('evaluation',{}).get('decision_ok')) for c in group),
                'errors':sum('validator_error' in c for c in group),
                'case_pass_pct':percentage(sum(bool(c.get('evaluation',{}).get('case_pass')) for c in group),len(group)),
                'decision_accuracy_pct':percentage(sum(bool(c.get('evaluation',{}).get('decision_ok')) for c in group),len(group)),
                'expected_criteria_accuracy_pct':percentage(sum(c.get('evaluation',{}).get('criteria_ok',0) for c in group),criteria_total),
                'expected_missing_fields_recall_pct':percentage(sum(c.get('evaluation',{}).get('missing_ok',0) for c in group),missing_total),
                'next_question_key_accuracy_pct':percentage(sum(c.get('evaluation',{}).get('next_key_ok',0) for c in group),len(group))}
        report['validator_latency']=stats([c['validator_latency_s'] for c in results])
        isolated_calls=[call for c in results for call in c.get('validator_llm_calls',[])]
        report['validator_only_llm_calls']=len(isolated_calls)
        report['validator_only_truncated_outputs']=sum(c.get('response',{}).get('done_reason')=='length' and not json_valid(c) for c in isolated_calls)
        report['validator_only_invalid_raw_json_outputs']=sum(not json_valid(c) for c in isolated_calls)
    return report

def render_case(suite,case):
    if not case: return '<p>Pendente</p>'
    parts=[]
    if suite=='golden':
        parts.append('<p>Golden: '+html.escape(str(case.get('evaluation',case.get('validator_error'))))+'</p>')
        parts.append('<details><summary>Validação isolada e expectativa</summary><pre>'+html.escape(json.dumps({k:case.get(k) for k in ['input','validator_response','validator_audit','validator_llm_calls','evaluation']},ensure_ascii=False,indent=2))+'</pre></details>')
    else:
        parts.append('<p>'+html.escape(case['verdict'])+'</p>')
        if criteria_differences(case):
            parts.append('<p><strong>Divergência entre dados conhecidos e filtros:</strong> '+html.escape(json.dumps(criteria_differences(case),ensure_ascii=False))+'</p>')
    for turn in all_turns(suite,case):
        parts.append('<div class="turn"><b>Cliente:</b> '+html.escape(turn.get('user',''))+'<br><b>Assistente:</b> '+html.escape(turn.get('assistant',turn.get('error_message','')))+
            f"<p>Tempo: {turn.get('latency_s',0):.3f} s · LLM: {turn.get('llm_called',False)} · Buscas: {len(turn.get('searches',[]))}</p>")
        parts.append('<details><summary>Payload, estado, buscas, produtos e LLM</summary><pre>'+html.escape(json.dumps(turn,ensure_ascii=False,indent=2))+'</pre></details></div>')
    return ''.join(parts)

def main():
    reports={}; summaries={}; paired=[]; rows=[]; turns=[]; searches=[]; calls=[]
    for model in MODELS:
        reports[model]={}; summaries[model]={}
        for suite in ['categories','golden']:
            path=ROOT/model/suite/'report.json'
            report=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {'results':[]}
            reports[model][suite]=report
            summaries[model][suite]=summarize(suite,report['results'])
            for case in report['results']:
                for index,turn in enumerate(all_turns(suite,case),1):
                    prefix={'model':model,'suite':suite,'case_id':case['id'],'turn':index}
                    turns.append({**prefix,**turn})
                    searches.extend({**prefix,**search} for search in turn.get('searches',[]))
                    calls.extend({**prefix,'phase':'end_to_end',**call} for call in turn.get('llm_calls',[]))
                if suite=='golden':
                    calls.extend({'model':model,'suite':suite,'case_id':case['id'],'phase':'validator_only',**call} for call in case.get('validator_llm_calls',[]))
    complete=all(summaries[m][s]['completed']==n and reports[m][s].get('metadata',{}).get('finished_at') for m in MODELS for s,n in [('categories',371),('golden',27)])
    result={'generated_at':datetime.now(timezone.utc).isoformat(),'status':'complete' if complete else 'partial',
        'models':summaries,'dataset_overlap':OVERLAP,'limitations':[
            'Os dois modelos usam Transformers em BF16, com a mesma geração greedy e restrição de JSON Schema. O artefato quantizado histórico do Ollama não foi reexecutado.',
            'Snapshot do ERP e código do backend congelados; as referências preservam as entradas dos 371 casos originais.',
            'Os julgamentos por categoria são triagem de coerência com o cadastro, exigem revisão humana e não certificam encaixe físico nem recuperação de todo o estoque.',
            'O golden usa a pontuação existente dos campos esperados na validação isolada de pre-search; seis mensagens coincidem exatamente com o treino e são reportadas separadamente. A execução do fluxo completo é evidência distinta.',
            'Ausência de coincidência exata não exclui paráfrases ou modelos de conversa compartilhados com o treino.',
            'Uma rodada por modelo; tempos incluem SSH e backend, excluem a inspeção independente da fonte e não constituem benchmark de carga.',
            'O transporte pelo gateway, Redis e WhatsApp não foi exercitado.'
        ]}
    for suite,file in [('categories','cases_371.json'),('golden','golden_27.json')]:
        cases=json.loads((ROOT/file).read_text(encoding='utf-8'))
        indexes={m:{c['id']:c for c in reports[m][suite]['results']} for m in MODELS}
        for case in cases:
            a=indexes[MODELS[0]].get(case['id']); b=indexes[MODELS[1]].get(case['id'])
            va=a.get('verdict') if a and suite=='categories' else a.get('evaluation',{}).get('case_pass') if a else None
            vb=b.get('verdict') if b and suite=='categories' else b.get('evaluation',{}).get('case_pass') if b else None
            differences={
                'verdict_changed':va!=vb,
                'assistant_messages_changed':[t.get('assistant') for t in all_turns(suite,a)]!=[t.get('assistant') for t in all_turns(suite,b)] if a and b else False,
                'search_results_changed':[[s.get('returned_ids') for s in t.get('searches',[])] for t in all_turns(suite,a)]!=[[s.get('returned_ids') for s in t.get('searches',[])] for t in all_turns(suite,b)] if a and b else False,
                'search_criteria_changed':[[s.get('criteria') for s in t.get('searches',[])] for t in all_turns(suite,a)]!=[[s.get('criteria') for s in t.get('searches',[])] for t in all_turns(suite,b)] if a and b else False,
                'golden_validator_output_changed':a.get('validator_response')!=b.get('validator_response') if a and b and suite=='golden' else False,
            }
            changed=bool(a and b and any(differences.values()))
            paired.append({'suite':suite,'id':case['id'],'input':case,'base':a,'fine_tuned':b,'changed':changed,'differences':differences,
                'known_vehicle_fact_filter_mismatches':{m:criteria_differences(c) if c and suite=='categories' else [] for m,c in zip(MODELS,[a,b])}})
            ta=sum(t.get('latency_s',0) for t in all_turns(suite,a)) if a else None
            tb=sum(t.get('latency_s',0) for t in all_turns(suite,b)) if b else None
            rows.append({'suite':suite,'id':case['id'],'category':case.get('group_name'),'subcategory':case.get('family'),
                'base_verdict':va,'ft_verdict':vb,'changed':changed,**differences,
                'base_known_vehicle_fact_filter_mismatches':len(criteria_differences(a)) if a and suite=='categories' else 0,
                'ft_known_vehicle_fact_filter_mismatches':len(criteria_differences(b)) if b and suite=='categories' else 0,
                'base_response_time_s':ta,'ft_response_time_s':tb,
                'base_turns':len(all_turns(suite,a)) if a else None,'ft_turns':len(all_turns(suite,b)) if b else None,
                'exact_training_overlap':case['id'] in OVERLAP[suite]['train']})
    result['category_transitions']={f'{a} -> {b}':n for (a,b),n in Counter((r['base_verdict'],r['ft_verdict']) for r in rows if r['suite']=='categories' and r['base_verdict'] is not None and r['ft_verdict'] is not None).items()}
    result['paired_case_counts']={suite:sum(bool(pair['base'] and pair['fine_tuned']) for pair in paired if pair['suite']==suite) for suite in ['categories','golden']}
    result['paired_differences']={suite:{key:sum(bool(pair['differences'][key]) for pair in paired if pair['suite']==suite and pair['base'] and pair['fine_tuned']) for key in ['verdict_changed','assistant_messages_changed','search_results_changed','search_criteria_changed','golden_validator_output_changed']} for suite in ['categories','golden']}
    golden_regressions=[pair for pair in paired if pair['suite']=='golden' and pair['base'] and pair['fine_tuned'] and pair['base'].get('evaluation',{}).get('case_pass') and not pair['fine_tuned'].get('evaluation',{}).get('case_pass')]
    result['golden_isolated_regressions']=[pair['id'] for pair in golden_regressions]
    result['golden_isolated_regressions_with_identical_deterministic_end_to_end_replies']=[pair['id'] for pair in golden_regressions
        if not pair['base']['end_to_end']['llm_called'] and not pair['fine_tuned']['end_to_end']['llm_called']
        and pair['base']['end_to_end'].get('assistant')==pair['fine_tuned']['end_to_end'].get('assistant')
        and not pair['differences']['search_results_changed'] and not pair['differences']['search_criteria_changed']]
    write_json(ROOT/'comparison_summary.json',result)
    write_json(ROOT/'paired_conversations.json',{'metadata':result,'cases':paired})
    with (ROOT/'case_comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    for name,data in [('turns',turns),('searches',searches),('llm_calls',calls)]:
        with (ROOT/(name+'.jsonl')).open('w',encoding='utf-8') as f:
            for row in data: f.write(json.dumps(row,ensure_ascii=False)+'\n')
    lines=['# Comparação Qwen original e fine-tuning','',f"Estado: {result['status']}",'',
        '| Conjunto | Original | Fine-tuning |','|---|---:|---:|']
    for suite,label in [('categories','Conversas por categoria'),('golden','Casos golden')]:
        lines.append(f"| {label} | {summaries[MODELS[0]][suite]['completed']} | {summaries[MODELS[1]][suite]['completed']} |")
    lines+=['','## Categorias','', '| Resultado | Original | Fine-tuning |','|---|---:|---:|']
    verdicts=sorted(set().union(*(summaries[m]['categories'].get('verdicts',{}) for m in MODELS)))
    for v in verdicts: lines.append(f"| {v} | {summaries[MODELS[0]]['categories'].get('verdicts',{}).get(v,0)} | {summaries[MODELS[1]]['categories'].get('verdicts',{}).get(v,0)} |")
    lines+=['','## Métricas complementares','']
    lines+=['| Métrica | Original | Fine-tuning |','|---|---:|---:|']
    metrics=[
        ('Golden aprovado (todos)',lambda m:f"{summaries[m]['golden'].get('all',{}).get('passed',0)}/{summaries[m]['golden'].get('all',{}).get('total',0)}"),
        ('Golden aprovado (sem coincidência exata com treino/validação)',lambda m:f"{summaries[m]['golden'].get('without_exact_train_validation_overlap',{}).get('passed',0)}/{summaries[m]['golden'].get('without_exact_train_validation_overlap',{}).get('total',0)}"),
        ('Golden: decisão correta (%)',lambda m:summaries[m]['golden'].get('all',{}).get('decision_accuracy_pct')),
        ('Golden: critérios esperados corretos (%)',lambda m:summaries[m]['golden'].get('all',{}).get('expected_criteria_accuracy_pct')),
        ('Golden: campos faltantes esperados recuperados (%)',lambda m:summaries[m]['golden'].get('all',{}).get('expected_missing_fields_recall_pct')),
        ('Golden: chave da próxima pergunta correta (%)',lambda m:summaries[m]['golden'].get('all',{}).get('next_question_key_accuracy_pct')),
        ('Categorias: turnos',lambda m:summaries[m]['categories']['turns']),
        ('Categorias: chamadas LLM',lambda m:summaries[m]['categories']['llm_calls']),
        ('Categorias: respostas LLM cortadas em 220 tokens',lambda m:summaries[m]['categories']['truncated_llm_outputs']),
        ('Categorias: JSONs brutos completos',lambda m:summaries[m]['categories']['valid_raw_json_outputs']),
        ('Categorias: erros de turno',lambda m:summaries[m]['categories']['turn_errors']),
        ('Categorias: média por turno (s)',lambda m:round(summaries[m]['categories']['turn_latency']['mean_s'] or 0,3)),
        ('Categorias: mediana por turno (s)',lambda m:round(summaries[m]['categories']['turn_latency']['median_s'] or 0,3)),
        ('Categorias: p95 por turno (s)',lambda m:round(summaries[m]['categories']['turn_latency']['p95_s'] or 0,3)),
        ('Categorias: média de turno com LLM (s)',lambda m:round(summaries[m]['categories']['turn_latency_with_llm']['mean_s'] or 0,3)),
        ('Categorias: buscas',lambda m:summaries[m]['categories']['searches']),
        ('Categorias: conversas com filtro divergente de dado veicular conhecido',lambda m:summaries[m]['categories'].get('conversations_with_known_vehicle_fact_filter_mismatches',0)),
    ]
    for label,getter in metrics: lines.append(f'| {label} | {getter(MODELS[0])} | {getter(MODELS[1])} |')
    lines+=['','## Alterações por caso','', '| Resultado original → ajustado | Casos |','|---|---:|']
    lines += [f'| {key} | {value} |' for key,value in result['category_transitions'].items()]
    lines+=['','## Validação isolada e fluxo completo','',
        'Regressões do candidato no golden isolado: '+(', '.join(result['golden_isolated_regressions']) or 'nenhuma nas comparações disponíveis')+'.',
        'Dessas regressões, os seguintes casos tiveram respostas e buscas idênticas no fluxo completo, resolvidas deterministicamente sem chamar a LLM: '+(', '.join(result['golden_isolated_regressions_with_identical_deterministic_end_to_end_replies']) or 'nenhum nas comparações disponíveis')+'.',
        'Uma falha da validação isolada não deve ser descrita automaticamente como falha do atendimento completo. Os dois registros estão preservados separadamente.',
        '', '## Limites','']+['- '+x for x in result['limitations']]
    (ROOT/'comparison.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    body=[]
    for row,pair in zip(rows,paired):
        label=pair['input'].get('family',pair['input'].get('message.text',''))
        body.append(f"<section class='case' data-changed='{str(pair['changed']).lower()}'><h2>{html.escape(pair['suite']+' · '+pair['id']+' · '+label)}</h2><p>Original: {html.escape(str(row['base_verdict']))} · Fine-tuning: {html.escape(str(row['ft_verdict']))}</p><div class='pair'><article><h3>Original</h3>{render_case(pair['suite'],pair['base'])}</article><article><h3>Fine-tuning</h3>{render_case(pair['suite'],pair['fine_tuned'])}</article></div></section>")
    metrics_html='<details><summary>Métricas consolidadas</summary><table><tr><th>Métrica</th><th>Original</th><th>Fine-tuning</th></tr>'+''.join(f'<tr><td>{html.escape(label)}</td><td>{html.escape(str(getter(MODELS[0])))}</td><td>{html.escape(str(getter(MODELS[1])))}</td></tr>' for label,getter in metrics)+'</table></details>'
    page='''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Comparação de modelos — TCC</title>
<style>body{font:15px system-ui;margin:28px;background:#f3f5f8;color:#162132}header{position:sticky;top:0;background:#f3f5f8;padding:12px 0;z-index:1}input{padding:10px;width:55%}.pair{display:grid;grid-template-columns:1fr 1fr;gap:18px}article{min-width:0;background:white;padding:16px;border:1px solid #d5dce6;border-radius:8px}.case{margin:25px 0;padding-top:8px;border-top:2px solid #c5d1df}.turn{border-top:1px solid #ddd;padding:12px 0;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px monospace}summary{cursor:pointer;color:#174e89}details{margin:8px 0}h2{font-size:18px}@media(max-width:850px){.pair{grid-template-columns:1fr}}</style>
<header><h1>Comparação: Qwen original × fine-tuning</h1><p>371 conversas por modelo e 27 casos golden por modelo. Mesmos dados congelados, código e parâmetros. Julgamentos de categoria exigem revisão humana.</p><input id="q" placeholder="Filtrar ID, categoria, código ou mensagem" oninput="filter()"> <label><input id="changed" type="checkbox" style="width:auto" onchange="filter()"> Somente resultado diferente</label><p id="count"></p><a href="comparison_summary.json">Resumo JSON</a> · <a href="case_comparison.csv">Comparação CSV</a> · <a href="paired_conversations.json">Conversas completas JSON</a></header>
'''+f'<p>Estado: <strong>{result["status"]}</strong>. Gerado: {result["generated_at"]}. Seis casos golden coincidem com mensagens de treino; consulte as métricas separadas. A tentativa de instrumentação anterior está excluída.</p>'+metrics_html+''.join(body)+'''<script>function filter(){let q=document.querySelector('#q').value.toLowerCase(),changed=document.querySelector('#changed').checked,n=0;document.querySelectorAll('.case').forEach(e=>{e.hidden=!e.textContent.toLowerCase().includes(q)||(changed&&e.dataset.changed!=='true');if(!e.hidden)n++});document.querySelector('#count').textContent=n+' casos exibidos'}filter()</script></html>'''
    (ROOT/'comparison.html').write_text(page,encoding='utf-8')
    checksums={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.json','.jsonl','.csv','.md','.py','.gz','.dump'} and '__pycache__' not in str(p) and p.name!='checksums.json'}
    write_json(ROOT/'checksums.json',checksums)
    print(json.dumps({'status':result['status'],'counts':{m:{s:d['completed'] for s,d in suites.items()} for m,suites in summaries.items()}},ensure_ascii=False))

if __name__=='__main__': main()
