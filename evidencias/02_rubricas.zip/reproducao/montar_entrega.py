import csv,hashlib,html,json,os,re,shutil,zipfile
from pathlib import Path
from collections import Counter
R=Path(__file__).resolve().parent;O=R/'entrega';X=json.load(open(R/'cache.json'));C=X['study']['cases'];KEY=X['key'];M=json.load(open(O/'metricas_por_configuracao.json'));T=json.load(open(O/'auditoria_tecnica_recalculada.json'));F=json.load(open(O/'verificacoes_742_saidas.json'))['cases'];B=json.load(open(O/'gabarito_exploratorio_371.json'))['cases'];REF=json.load(open(O/'evidencias_referencias_371.json'));GAPS=json.load(open(O/'lacunas_recuperacao.json'));DIS=json.load(open(O/'discordancias_e_sintese.json'));N=json.load(open(O/'dez_novos_casos_sinteticos.json'))
AS=[json.load(open(O/('avaliacao_'+p+'.json')))for p in ['IA_BALCAO_V3','IA_APLICACAO_V3','IA_AUDITORIA_V3']]
NOTICE=M['notice']
def dump(n,d):(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2))
def esc(v):return html.escape(str(v))
labels={'adequate':'Adequada','partly':'Parcial','inadequate':'Inadequada','unknown':'Indeterminada'}
rows=[r for r in M['counts']if r['scope']=='all_371']
table='\n'.join('|'+r['persona']+'|'+r['arm']+'|'+'|'.join(str(r[k])for k in ['adequate','partly','inadequate','unknown'])+'|' for r in rows)
technical='\n'.join('|'+rep+'|'+arm+'|'+'|'.join(str(T['groups']['categories'][rep][arm][k])for k in ['items_presented_cases','handoff_cases','repeated_question_cases','llm_calls'])+'|'+str(round(T['groups']['categories'][rep][arm]['case_latency']['mean_s'],3))+'|'+str(round(T['groups']['categories'][rep][arm]['case_latency']['p95_s'],3))+'|'for rep in ['1','2','3']for arm in ['D','H'])
rev={v['original_case_id']:cid for cid,v in KEY['cases'].items()};gains=[]
for item in T['H_incremental_items']:
 if item['rep']!=1:continue
 cid=rev[item['original_case_id']];l=next(l for l,a in KEY['cases'][cid]['arms'].items()if a=='H')
 gains.append({'case_id':cid,'request':item['request'],'H_codes':item['H_codes'],'top1_registry':F[cid][l]['top1'],'personas':{a['reviewer_id']:a['assessments'][cid][l]['overall']for a in AS},'bugs':F[cid][l]['bugs']})
dump('contribuicao_incremental_H.json',{'scope':'7 IDs com produto somente em H, na primeira repetição; resultados iguais nas três repetições. Não são necessariamente 7 pedidos distintos.','cases':gains})
gt='\n'.join('|'+g['case_id']+'|'+g['top1_registry']+'|'+' / '.join(g['H_codes'])+'|'+' / '.join(labels[v]for v in g['personas'].values())+'|'for g in gains)
agreements=[]
for i in range(3):
 for j in range(i+1,3):
  same=sum(AS[i]['assessments'][c['id']][l]['overall']==AS[j]['assessments'][c['id']][l]['overall']for c in C for l in['A','B']);agreements.append({'personas':[AS[i]['reviewer_id'],AS[j]['reviewer_id']],'same_class':same,'total_outputs':742,'agreement_percent':round(same/742*100,2),'interpretation':'Consistência descritiva de perspectivas do mesmo processo. Sem independência; não é confiabilidade entre especialistas.'})
dump('concordancia_sintetica_descritiva.json',{'pairs':agreements,'cohen_kappa':None,'reason':'Não calcular kappa como validação interavaliadores humanos para perspectivas dependentes.'})
groupnames={}
for cid,entry in KEY['cases'].items():
 p=R/'tecnico/runs/rep_1/categories/D'/ (entry['original_case_id']+'.json');rr=json.load(open(p));groupnames[str(entry['group_code'])]=rr['input']['group_name']
tax=json.load(open(O/'metricas_por_grupo.json'))
with(O/'categorias_por_grupo.csv').open('w',newline='',encoding='utf-8-sig')as f:
 w=csv.writer(f);w.writerow(['grupo','nome','configuracao','adequadas','parciais','inadequadas','indeterminadas'])
 for e in tax:w.writerow([e['group_code'],groupnames[str(e['group_code'])],e['arm'],*[e.get(k,0)for k in ['adequate','partly','inadequate','unknown']]])
dump('nomes_grupos.json',groupnames)
gap_table='\n'.join('|'+g['case_id']+'|'+g['arm']+'|'+g['code']+'|'+str(g['application_id'])+'|'for g in GAPS)
report=f'''# Revisão ampliada dos 371 casos — versão 3

**{NOTICE}**

## Entrega e fonte corrigida

Esta revisão cobre os 371 casos (347 pedidos textualmente distintos) e as 742 saídas D/H da primeira repetição. As três perspectivas produzem 2.226 julgamentos de saída e respostas aos 21 campos da ficha por caso/saída. Há 337 referências históricas e 34 casos sem referência. A classificação indeterminada é uma resposta válida, não foi substituída por acerto/erro inventado.

Foi usado o snapshot de **19/10/2026** contido em `tecnico/inputs/source_snapshot`: **52.798 produtos e 1.779.443 aplicações**. Seus hashes e contagens foram conferidos. O CSV enviado separadamente antes era exportação de 14/09/2026 com 1.776.907 aplicações; tinha 2.536 vínculos a menos. Portanto a ressalva de divergência temporal global da versão 2 foi resolvida nesta versão usando a fonte efetiva do ensaio, sem apagar o histórico anterior.

**D** é a arquitetura determinística existente com encaminhamento conservador no ponto residual. **H** é a mesma arquitetura com Qwen2.5:7b residual e validações existentes. A chave `analyst_key.json` foi usada para converter A/B em D/H. **Esta bateria não compara modelo base versus fine-tuning.** D também não é uma implementação ideal ou exaustiva de todas as alternativas determinísticas possíveis.

## Metodologia efetivamente realizada

1. Conferência dos hashes e leitura dos CSV principais do snapshot correto; conservação dos arquivos originais.
2. Interpretação explícita dos 371 pedidos por função/composição e dados presentes. O gabarito está em `gabarito_exploratorio_371.json`; as anotações e regras de pontuação estão nos scripts e em `criterios_371.py`/`criterios_prioritarios.json`.
3. Verificação das referências e dos códigos retornados contra todas as suas aplicações no snapshot. Foram examinados 627 produtos referenciados/retornados ou selecionados para novos cenários, com 51.615 vínculos. A varredura do arquivo completo não significa que 1,77 milhão de linhas receberam interpretação humana individual.
4. Para sustentar um candidato, modelo, ano, motor e versão conhecida precisam ocorrer no **mesmo vínculo**. Identidade/composição e oposição explícita de lado/posição são verificadas separadamente; não se combinam veículo de uma linha e motor de outra. Dados omitidos não são completados por suposição.
5. Três perspectivas são aplicadas sequencialmente, por rubricas explícitas: balcão (perguntas/continuidade), aplicação (identidade/evidência/contenção de risco) e auditoria (fidelidade/rastreabilidade). O processo foi assistido por IA e materializado por scripts, **não foram três chamadas isoladas de LLM ou três profissionais independentes**.
6. Cada saída recebe adequada, parcial, inadequada ou indeterminada. Encaminhar pode ser seguro e adequado sob contenção de risco e parcial em autonomia. Um Top-1 sustentado não torna toda a lista correta. Parcial não entra na taxa estrita de adequação.
7. A chave foi aplicada à agregação e os desacordos preservados. A síntese só mantém uma classe quando unânime; divergência com indeterminado fica indeterminada, demais divergências ficam parciais. Isso é regra de apresentação, não adjudicação humana.
8. Os 3.408 registros técnicos arquivados foram recontados; somas de latência, chamadas, resultados e assinaturas das três repetições foram conferidos, sem nova execução do agente.

O contexto já continha respostas anteriores. **Não houve cegamento, pré-registro prospectivo ou independência entre personas.** Os hashes preservam os bytes desta entrega daqui em diante. Regras/aliases do próprio sistema não foram usados como verdade comercial independente; servem para diagnóstico. Não houve consulta a fabricante/ERP atual, nem demonstração de preço, estoque ou encaixe físico.

## Resultado por perspectiva e configuração

Cada linha tem 371 saídas. Os critérios da versão 3 incluem a fonte correta, cobertura ampliada e verificações de composição/lado por candidato; as contagens antigas da versão 2 não devem ser comparadas como se apenas o tamanho da amostra tivesse mudado.

|Perspectiva|Configuração|Adequadas|Parciais|Inadequadas|Indeterminadas|
|---|---|---:|---:|---:|---:|
{table}

Adequação por perspectiva não é precisão comercial validada. Por exemplo, uma pergunta genérica de eixo para uma peça elétrica pode ser inadequada em diálogo/auditoria, enquanto um encaminhamento que evita recomendar peça pode conter o risco de aplicação. Candidatos que dependem de medida de retífica, sistema, conector ou composição permanecem parciais/indeterminados.

Os recortes de 60 prioritários, 311 adicionais e 371 totais estão separados em `metricas_por_configuracao.json`. A síntese por todos os 24 grupos está em `categorias_por_grupo.csv`; a tabela de 2.226 linhas está em `avaliacoes_371.csv`. Nenhum desses denominadores foi multiplicado pelas três repetições como se fossem novos clientes.

## Contribuição incremental observada de H

Em cada repetição, **326/371 conversas foram idênticas**, 45 casos acionaram o modelo em H (12,1%), e H apresentou produtos em sete IDs nos quais D não apresentou. Esses sete IDs correspondem a seis pedidos distintos, pois AV-093 e AV-203 repetem o mesmo pedido.

|Caso|Top-1 cadastral H|Códigos retornados H|Balcão / Aplicação / Auditoria|
|---|---|---|---|
{gt}

Há cinco Top-1 sustentados cadastralmente e dois indeterminados entre esses sete IDs. Isso não significa sete sucessos comerciais: AV-028 oferece a sapata com lona, mas desmembra a composição em dois pedidos; AV-296 tem o primeiro código sustentado, mas o segundo candidato não foi aprovado. AV-152/194 permanecem pendentes de conferir período/composição. AV-093/203 e AV-312 apresentam conduções adequadas pelas rubricas, com AV-093/203 sendo duplicata textual.

Assim, os registros sustentam aumento de autonomia/retorno em um subconjunto e também mostram custo de latência e falhas residuais. Não sustentam superioridade comercial geral do híbrido nem ganho atribuível a fine-tuning.

## Auditoria técnica das três repetições

Foram conferidos **3.408 registros**, em 18 combinações de conjunto/repetição/configuração, sem divergências nas contagens e somas recalculadas. Os **3.716 arquivos do manifesto** conferem em tamanho/SHA-256. O manifesto de congelamento também cita um cache `.pyc` não incluído no pacote; ele foi registrado como bytecode ausente, não como código-fonte verificado. Os arquivos-fonte presentes conferem. Não foi ocultada essa omissão.

Os XMLs arquivados registram **604 testes do agente e 33 do gateway**, sem falhas/erros/skips. São evidências da execução anterior, não testes executados por mim nesta revisão. As 294 chamadas de inferência registradas estão em H; D tem zero. As conversas permaneceram iguais nas três repetições, conforme assinaturas recalculadas, embora os tempos variassem.

|Repetição|Configuração|Com produtos|Com handoff|Paradas por repetição de pergunta|Chamadas LLM|Média por caso (s)|P95 por caso (s)|
|---|---|---:|---:|---:|---:|---:|---:|
{technical}

Nos 170 cenários estruturais, os checks arquivados/recontados passam em 163 casos para D e 164 para H em cada repetição. Nos 27 golden, os checks de campos originais passam em 22 para D e 24 para H. São checks de expectativa, não gabarito comercial independente. A análise de sobreposição/independência original continua separada desses números; esta entrega não transforma exemplos de treino em testes independentes.

## Lacunas de recuperação sustentadas

São {len(GAPS)} ocorrências em {len({g['case_id']for g in GAPS})} IDs de caso, com duplicatas preservadas. O caso da flange para F-1000 4.9 aparece em AV-243 e AV-361 com o mesmo pedido. Há sete pedidos distintos nesse conjunto de oito IDs.

|Caso|Configuração|Código de evidência|Application ID|
|---|---|---|---|
{gap_table}

O escopo é recuperação **cadastral**: mesmo componente e vínculo que satisfaz modelo/ano/motor/versão conhecida. No pedido de flange, os critérios observados usam “semi eixo”, perdendo a identidade principal de flange; o vazio não comprova inexistência. Ainda assim, apontar esse sintoma não equivale a provar por contrafactual qual alteração no mecanismo recuperaria a peça. A causa interna final e a montagem física não foram adjudicadas.

Não foram promovidos a falso negativo pedidos genéricos cuja referência é kit, acessório ou outro componente. Por exemplo, kit com batente não comprova batente avulso; vareta não comprova cabeçote; maçaneta não comprova cabo do capô; pinhão não comprova cabo do velocímetro.

## Dez novos cenários

`dez_novos_casos_sinteticos.json` contém dez cenários com frase, contexto, complementações quando cabíveis, ação esperada e evidência do catálogo. Os identificadores de produtos são reais do snapshot, exceto o código inexistente usado em controle de consulta literal. Há casos completos, ambiguidade, correção, kit versus avulso, dado desconhecido, dimensão, volume/quantidade e ausência de referência exata.

O único caso de ausência confirmada restringe a conclusão ao identificador literal inexistente nos 52.798 registros; não afirma que uma peça funcionalmente equivalente não existe. Os dez casos são **sintéticos, gerados após exposição à bateria, não independentes e ainda não executados no agente**. Não são relatos de clientes reais. O hash preserva este gabarito para uma execução futura; não cria independência retroativa. O conjunto não entra nos denominadores 371/742.

## O que continua pendente

- Duas revisões de profissionais reais, independentes, com informação sobre vínculo e domínio.
- Adjudicação humana dos desacordos e conflitos de descrição/aplicação, sem apagar os originais.
- Dez pedidos reais anonimizados com evidências e gabarito congelados antes de testar.
- Executar os novos casos em ambiente isolado, preservando saídas e versões. Nenhuma execução nova do agente foi feita aqui.
- Para afirmar encaixe/equivalência, confirmar catálogo técnico/dimensões e configuração instalada onde o snapshot é conflitante.

## Uso acadêmico e reprodução

Redação fiel: “Foi realizada revisão exploratória assistida por IA dos 371 casos da bateria, sob três perspectivas dependentes de julgamento, fundamentada no snapshot de 19/10/2026. Foram preservadas avaliações parciais, indeterminadas e discordantes. A análise foi complementada por recontagem dos registros técnicos e não substituiu revisão comercial humana.”

Extraia o pacote e abra `RESULTADOS_371.html`. Para importar respostas na ficha original, use um dos três JSON `avaliacao_IA_*_V3.json`. Para reproduzir a parte computacional: `python reproducao/reproduzir.py /caminho/avaliacao_final_completa.zip`. É necessário Python 3.11+ e o ZIP original; o script usa apenas biblioteca padrão, cria diretório temporário separado e não chama rede, Docker, banco ou LLM. Ele reaplica os julgamentos registrados e refaz contagens/vínculos; não produz uma nova opinião independente.
'''
(O/'RELATORIO_371.md').write_text(report)
(O/'PENDENCIAS.md').write_text('# Limites do protocolo\n\nA avaliação exploratória por IA está preenchida para os 371 casos. Continuam pendentes revisões humanas independentes, adjudicação humana, dez pedidos reais novos e execução dos cenários sintéticos no agente. Não foram inventados profissionais, experiência, clientes reais ou execuções novas.\n')

# HTML autocontido com evidência detalhada nos JSON e filtros em toda a revisão.
tablehtml=''.join('<tr><td>'+esc(r['persona'])+'</td><td>'+r['arm']+'</td>'+''.join('<td>'+str(r[k])+'</td>'for k in['adequate','partly','inadequate','unknown'])+'</tr>'for r in rows)
cards=[]
for c in C:
 cid=c['id'];group=KEY['cases'][cid]['group_code'];b=B[cid];ce=REF[cid]
 details='<h3>Interpretação</h3><p><b>Ação esperada:</b> '+esc(b['expected_action'])+'</p><p>'+esc(b['interpretation'])+'</p><p><b>O que falta:</b> '+esc(b['indispensable_missing'])+'</p>'
 if ce:
  details+='<p><b>Referência histórica:</b> '+esc(ce['code'])+' — '+esc(ce['title'])+'<br>'+esc(ce['nm_item'])+'</p><p>Vínculos que satisfazem os dados presentes: '+str(ce['same_tuple_matching_count'])+'.</p>'
  details+='<details><summary>Consultar evidência da referência (até 8 vínculos nesta página)</summary><pre>'+esc(json.dumps(ce['matching_applications'][:8],ensure_ascii=False,indent=2))+'</pre></details>'
 for arm in ['D','H']:
  label=next(l for l,a in KEY['cases'][cid]['arms'].items()if a==arm);f=F[cid][label];details+='<h3>'+arm+' — saída '+label+'</h3>'
  details+=''.join('<p><b>Cliente:</b> '+esc(t['user'])+'<br><b>Atendimento:</b> '+esc(t['assistant'])+'</p>'for t in c[label]['turns'])
  if c[label]['products']:details+='<p><b>Códigos:</b> '+esc(', '.join(p['code']for p in c[label]['products']))+'</p>'
  details+='<p><b>Falhas demonstradas:</b> '+esc(', '.join(f['bugs'])or'nenhuma demonstrada')+'</p>'
  for a in AS:
   e=a['assessments'][cid][label];details+='<div class="judgment '+e['overall']+'"><b>'+esc(a['reviewer_id'])+' — '+labels[e['overall']]+'</b><p>'+esc(e['error_reason'])+'</p></div>'
  if f['products']:details+='<details><summary>Evidência dos candidatos</summary><pre>'+esc(json.dumps(f['products'],ensure_ascii=False,indent=2))+'</pre></details>'
 cards.append('<details class="case" data-group="'+str(group)+'" data-priority="'+str(int(c['priority']))+'"><summary>'+esc(cid+' — '+c['initial_message'])+'</summary><article>'+details+'</article></details>')
groupopts=''.join('<option value="'+g+'">'+g+' — '+esc(n)+'</option>'for g,n in sorted(groupnames.items(),key=lambda kv:int(kv[0])))
page='''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Revisão dos 371 casos</title><style>body{font:16px/1.5 system-ui;background:#eef2f7;color:#18283f;max-width:1200px;margin:auto;padding:24px}header,section{background:white;padding:24px;border-radius:12px;margin:16px 0}h1{font-size:36px;line-height:1.2}.notice{background:#fff1cc;border-left:5px solid #b88712;padding:16px}.stats{font-weight:650;font-size:18px}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;padding:10px;border-bottom:1px solid #d6dfea}.case{background:white;border:1px solid #c6d2e0;border-radius:8px;margin:10px 0}summary{cursor:pointer;font-weight:650;padding:14px}article{padding:0 20px 20px}.judgment{background:#f1f4f8;border-left:5px solid #8796a9;padding:14px;margin:12px 0}.adequate{border-color:#25845b}.partly{border-color:#c89712}.inadequate{border-color:#b54c4c}.unknown{border-color:#7d5cab}pre{white-space:pre-wrap;overflow-wrap:anywhere;max-height:350px;overflow:auto;background:#f3f6fa;padding:14px;font-size:12px}input,select{padding:11px;border:1px solid #8c9fb6;border-radius:6px;margin:5px}input{width:92%}a{color:#15599c}small{color:#506178}@media(max-width:600px){body{padding:10px}header,section{padding:16px}th,td{padding:6px}table{font-size:12px}h1{font-size:28px}}</style></head><body><header><h1>Revisão ampliada dos 371 casos</h1><p class="notice">'''+esc(NOTICE)+'''</p><p class="stats">371 casos · 742 saídas · 2.226 julgamentos · 24 grupos</p><p><b>D:</b> determinístico com handoff residual. <b>H:</b> mesma arquitetura com Qwen residual. Esta não é uma comparação base versus fine-tuning.</p><p>Snapshot correto: 19/10/2026 — 52.798 produtos e 1.779.443 aplicações. Há 347 pedidos textualmente distintos.</p><p><a href="RELATORIO_371.md">Relatório e metodologia</a> · <a href="avaliacoes_371.csv">Avaliações CSV</a> · <a href="categorias_por_grupo.csv">Resultados por grupo</a> · <a href="metricas_por_configuracao.json">Métricas JSON</a> · <a href="PENDENCIAS.md">Pendências</a></p></header><section><h2>Resultado das perspectivas</h2><p>Cada linha tem 371 saídas. Parciais e indeterminadas ficam separadas das adequadas; os critérios são exploratórios e não medem acurácia comercial humana.</p><div style="overflow:auto"><table><thead><tr><th>Perspectiva</th><th>Configuração</th><th>Adequadas</th><th>Parciais</th><th>Inadequadas</th><th>Indeterminadas</th></tr></thead><tbody>'''+tablehtml+'''</tbody></table></div></section><section><h2>Auditoria técnica</h2><p>3.408 registros conferidos; 3.716 hashes/tamanhos conferem com o manifesto. XMLs: 604 testes do agente e 33 do gateway sem falhas. Não houve nova execução.</p><p>Nas três repetições: 326 conversas D/H idênticas; H apresenta produtos em sete IDs adicionais (seis pedidos distintos), com resultados comerciais mistos. Consulte a avaliação individual antes de interpretar ganho de retorno como acerto.</p></section><section><h2>Consultar os 371 casos</h2><input id="query" placeholder="Filtrar por caso, peça, código ou falha" aria-label="Busca nos casos"><br><select id="group" aria-label="Grupo"><option value="">Todos os grupos</option>'''+groupopts+'''</select><select id="scope" aria-label="Lote"><option value="all">Todos os 371</option><option value="1">60 prioritários</option><option value="0">311 adicionais</option></select><p id="count">371 casos</p></section>'''+''.join(cards)+'''<section><h2>Dez cenários sintéticos novos</h2><p>Não são pedidos reais ou independentes. Estão preenchidos com evidência, mas ainda não foram executados no agente. <a href="dez_novos_casos_sinteticos.json">Baixar JSON</a>.</p>'''+''.join('<details><summary>'+esc(c['id']+' — '+c['pedido_anonimizado'])+'</summary><article><pre>'+esc(json.dumps(c,ensure_ascii=False,indent=2))+'</pre></article></details>'for c in N['cases'])+'''</section><script>const q=document.querySelector('#query'),g=document.querySelector('#group'),s=document.querySelector('#scope');function filter(){const text=q.value.toLocaleLowerCase('pt-BR');let n=0;document.querySelectorAll('.case').forEach(e=>{const yes=(!g.value||e.dataset.group===g.value)&&(s.value==='all'||e.dataset.priority===s.value)&&e.textContent.toLocaleLowerCase('pt-BR').includes(text);e.hidden=!yes;if(yes)n++});document.querySelector('#count').textContent=n+' casos'}[q,g,s].forEach(e=>e.addEventListener('input',filter));</script></body></html>'''
(O/'RESULTADOS_371.html').write_text(page)
(O/'LEIA_PRIMEIRO.txt').write_text('Abra RESULTADOS_371.html.\n'+NOTICE+'\n371 casos avaliados; 347 pedidos distintos; 2.226 julgamentos.\nFonte correta do estudo: snapshot 19/10/2026.\nD=determinístico; H=determinístico+Qwen residual, não fine-tuning.\nOs três JSON de avaliação podem ser importados na ficha original incluída.\nLeia RELATORIO_371.md e PENDENCIAS.md antes de usar números no TCC.\n')
rd=O/'reproducao';rd.mkdir(exist_ok=True)
for name in ['preparar_evidencias.py','auditar_tecnico.py','avaliar_371.py','criar_testes_novos.py','montar_entrega.py','criterios_371.py','criterios_prioritarios.json','reproduzir.py']:shutil.copyfile(R/name,rd/name)
(rd/'LEIA-ME.txt').write_text('Python 3.11+ (somente biblioteca padrão).\nExecute: python reproduzir.py /caminho/avaliacao_final_completa.zip\nUsa o ZIP original como evidência; cria diretório temporário próprio.\nNão executa código do projeto original, inferência, Docker ou SQL.\nReaplica rubricas registradas e recalcula evidência: não gera avaliação independente.\n')
source=Path(os.environ.get('EVAL_SOURCE_ZIP',R.parent/'upload/avaliacao_final_completa(1).zip'))
with zipfile.ZipFile(source)as z:
 for fn in ['relatorio_avaliacao_final.md','LEIA_PRIMEIRO.md']:
  p=O/'relatorios_tecnicos_originais'/fn;p.parent.mkdir(exist_ok=True);p.write_bytes(z.read(fn))
hashes={str(p.relative_to(O)):hashlib.sha256(p.read_bytes()).hexdigest()for p in O.rglob('*')if p.is_file()and p.name!='SHA256.json'};dump('SHA256.json',hashes)
zipout=R/'Revisao_371_Casos_3_Personas_Completa_IA.zip'
with zipfile.ZipFile(zipout,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(O.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(O)))
print('Pacote criado:',zipout,'arquivos',len(hashes)+1)
