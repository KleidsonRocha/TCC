"""Uso: python reproduzir.py /caminho/avaliacao_final_completa.zip"""
import os,sys,shutil,tempfile,zipfile,subprocess
from pathlib import Path
source=Path(sys.argv[1]).resolve();here=Path(__file__).resolve().parent;work=Path(tempfile.mkdtemp(prefix='avaliacao_371_'))
scripts=['preparar_evidencias.py','auditar_tecnico.py','avaliar_371.py','criar_testes_novos.py','montar_entrega.py','criterios_371.py','criterios_prioritarios.json','reproduzir.py']
for name in scripts:shutil.copyfile(here/name,work/name)
with zipfile.ZipFile(source)as z:
 selected=[n for n in z.namelist()if n.startswith('tecnico/runs/rep_')or n.startswith('tecnico/inputs/source_snapshot/')or n in['tecnico/analyst_key.json','tecnico/summary.json','tecnico/protocol.json','tecnico/paired_category_results.json']]
 for name in selected:
  if name.endswith('/'):continue
  p=work/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
env=dict(os.environ,EVAL_SOURCE_ZIP=str(source))
for name in scripts[:5]:subprocess.run([sys.executable,str(work/name)],cwd=work,env=env,check=True)
print('Resultado:',work/'entrega')
