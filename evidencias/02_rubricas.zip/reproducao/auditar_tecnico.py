import json,zipfile,hashlib,statistics,xml.etree.ElementTree as ET,os
from pathlib import Path
from collections import defaultdict,Counter
R=Path(__file__).resolve().parent;T=R/'tecnico';O=R/'entrega';O.mkdir(exist_ok=True)
def write(n,d):(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2))
def sig(r):
 ss=[]
 for t in r['turns']:
  b=t.get('response')or{};s=b.get('conversation_state')or{}
  ss.append({'user':t['user'],'assistant':t.get('assistant'),'criteria':s.get('criteria'),'items':s.get('items'),'pending':s.get('pending_slot'),'handoff':b.get('handoff'),'public_products':[(x.get('item_id'),x.get('title'))for a in b.get('actions',[])if a.get('type')=='show_items' for x in a.get('items',[])]})
 return hashlib.sha256(json.dumps(ss,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def pct(v,p):
 s=sorted(v);pos=(len(s)-1)*p;i=int(pos);return s[i]+(s[min(i+1,len(s)-1)]-s[i])*(pos-i)
zip_path=Path(os.environ.get('EVAL_SOURCE_ZIP',R.parent/'upload/avaliacao_final_completa(1).zip'));hashes=[];test_results={};freeze_results={}
with zipfile.ZipFile(zip_path)as z:
 manifest=json.loads(z.read('manifest_entrega.json'))
 for n,expected in manifest['files'].items():
  data=z.read(n);actual=hashlib.sha256(data).hexdigest();hashes.append({'path':n,'sha256':actual,'bytes':len(data),'matches':actual==expected['sha256'] and len(data)==expected['bytes']})
 freeze=json.loads(z.read('tecnico/freeze_manifest_v2.json'))
 for n,h in freeze['files'].items():
  if 'tecnico/'+n in z.namelist():freeze_results[n]={'status':'verified','matches':hashlib.sha256(z.read('tecnico/'+n)).hexdigest()==h}
  else:freeze_results[n]={'status':'not_packaged_python_bytecode'if n.endswith('.pyc')else'missing_source_file','matches':None}
 for n in ['agent_tests','gateway_tests']:
  rt=ET.fromstring(z.read('tecnico/'+n+'.xml'));cases=list(rt.iter('testcase'));test_results[n]={'cases':len(cases),'failures':sum(c.find('failure')is not None for c in cases),'errors':sum(c.find('error')is not None for c in cases),'skipped':sum(c.find('skipped')is not None for c in cases),'evidence':'XML arquivado; não reexecutei os testes.'}
freeze_ok=all(x['matches']is True or x['status']=='not_packaged_python_bytecode'for x in freeze_results.values())
write('hashes_pacote_original.json',{'files':hashes,'all_match':all(x['matches']for x in hashes),'freeze_files':freeze_results,'freeze_packaged_source_files_match':freeze_ok,'bytecode_omissions':[n for n,x in freeze_results.items()if x['status']=='not_packaged_python_bytecode']})
reported=json.load(open(T/'summary.json'));groups=defaultdict(list);bykey={};diffs=[]
for p in sorted((T/'runs').glob('rep_*/*/*/*.json')):
 r=json.load(open(p));g=(r['suite'],r['repetition'],r['arm']);groups[g].append(r);bykey[(r['suite'],r['id'],r['repetition'],r['arm'])]=r
out={};group_checks=[]
for (suite,rep,arm),rows in groups.items():
 turns=[t for r in rows for t in r['turns']];calls=[c for t in turns for c in t.get('llm_calls',[])];lat=[sum(t['latency_s']for t in r['turns'])for r in rows]
 x={'cases':len(rows),'turns':len(turns),'technical_error_cases':sum(any(t['status']>=500 for t in r['turns'])for r in rows),'technical_error_turns':sum(t['status']>=500 for t in turns),'domain_rejections':sum(t['status']in[400,422]for t in turns),'searched_cases':sum(any(t.get('searches')for t in r['turns'])for r in rows),'items_presented_cases':sum(bool(r.get('items'))for r in rows),'handoff_cases':sum(any((t.get('response',{}).get('handoff')or{}).get('required')for t in r['turns'])for r in rows),'repeated_question_cases':sum(r.get('stop_reason')=='repeated_question'for r in rows),'llm_calls':len(calls),'llm_technical_call_errors':sum(bool(c.get('error'))for c in calls),'structural_case_passes':sum(bool(r.get('structural_pass'))for r in rows),'golden_expected_field_passes':sum(bool(r.get('original_expected_field_pass'))for r in rows),'case_latency':{'n':len(lat),'mean_s':statistics.mean(lat),'median_s':statistics.median(lat),'p95_s':pct(lat,.95),'sum_s':sum(lat)},'backend_fallback_turns':sum(bool((t.get('backend_audit')or{}).get('llm_fallback_used'))for t in turns)}
 rr=reported['per_repetition'][suite][str(rep)][arm];checks={k:x[k]==rr[k]for k in x if k!='case_latency'};checks['latency_sum']=abs(x['case_latency']['sum_s']-rr['case_latency']['sum_s'])<1e-6;checks['latency_median']=abs(x['case_latency']['median_s']-rr['case_latency']['median_s'])<1e-9
 if not all(checks.values()):diffs.append({'group':[suite,rep,arm],'checks':checks})
 group_checks.append({'group':[suite,rep,arm],'all_match':all(checks.values()),'checks':checks});out.setdefault(suite,{}).setdefault(str(rep),{})[arm]=x
paired={};incremental=[]
for rep in [1,2,3]:
 pairs=[(bykey['categories',cid,rep,'D'],bykey['categories',cid,rep,'H'])for cid in {k[1]for k in bykey if k[0]=='categories'}]
 paired[str(rep)]={'pairs':len(pairs),'identical_conversations':sum(sig(d)==sig(h)for d,h in pairs),'H_only_items':sum(bool(h.get('items'))and not d.get('items')for d,h in pairs),'D_only_items':sum(bool(d.get('items'))and not h.get('items')for d,h in pairs),'H_exposed_cases':sum(any(t.get('llm_calls')for t in h['turns'])for d,h in pairs)}
 for d,h in pairs:
  if bool(h.get('items'))and not d.get('items'):incremental.append({'original_case_id':h['id'],'rep':rep,'request':h['input']['initial_message'],'H_codes':[p['item_id']for p in h['items']]})
stability={}
for suite in ['categories','structural','golden_flow']:
 stability[suite]={}
 for arm in ['D','H']:
  cs={k[1]for k in bykey if k[0]==suite and k[3]==arm};changed=[cid for cid in cs if len({sig(bykey[suite,cid,rep,arm])for rep in[1,2,3]})>1];stability[suite][arm]={'case_ids':len(cs),'changed_case_ids':changed}
result={'scope':'Recontagem e conferência das execuções/testes arquivados; nenhuma nova inferência, SQL de produção ou execução de testes.','records':len(bykey),'expected_records':3408,'complete':len(bykey)==3408,'groups':out,'reported_summary_checks':group_checks,'discrepancies':diffs,'paired_categories':paired,'H_incremental_items':incremental,'stability_recomputed':stability,'tests_xml':test_results,'all_original_file_hashes_match':all(x['matches']for x in hashes),'packaged_frozen_source_hashes_match':freeze_ok,'bytecode_not_packaged':[n for n,x in freeze_results.items()if x['status']=='not_packaged_python_bytecode'],'human_commercial_accuracy':None}
write('auditoria_tecnica_recalculada.json',result)
print(json.dumps({'records':len(bykey),'hash_files':len(hashes),'all_hashes':result['all_original_file_hashes_match'],'discrepancies':diffs,'tests':test_results,'pairs':paired},ensure_ascii=False,indent=2))
