import json,hashlib,re,csv,unicodedata
from pathlib import Path
R=Path(__file__).resolve().parent;O=R/'entrega';X=json.load(open(R/'cache.json'));P=X['new_products'];BP={p['cd_item']:p for p in X['products']};AP=X['apps']
def arr(s):return []if not s or s=='{}'else next(csv.reader([s[1:-1]],escapechar='\\'))
def dump(n,d):(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2))
def ev(p,a=None):return {'snapshot':'2026-10-19','code':p['cd_item'],'id_item':p['id_item'],'nm_item':p['nm_item'],'title':p['candidate_title'],'application':a,'support':'Identidade e vínculo cadastral; não certifica montagem ou estoque.'}
def app(p):
 a=AP[p['id_item']][0];return a,int(a['year_start']),arr(a['engines'])[0]if arr(a['engines'])else'desconhecido',arr(a['variants'])[0]if arr(a['variants'])else'desconhecida'
bycode={p['cd_item']:p for p in P};new=[]
def add(pedido,ctx,fam,act,missing,codes,evidence,absence=None,incremental=None):
 new.append({'id':f'NOVO-{len(new)+1:02}','pedido_anonimizado':pedido,'contexto':ctx,'respostas_incrementais':incremental or[],'familia_correta':fam,'acao_esperada':act,'dados_indispensaveis':missing,'codigos_compativeis':codes,'ausencia_confirmada':absence,'evidencia':evidence,'avaliador_id':'IA_TESTES_SINTETICOS_V3','synthetic':True,'real_customer_record':False,'independent_of_prior_review':False,'not_yet_run_on_agent':True})
p=bycode['FP2747'];a,y,en,v=app(p)
add(f'Pode consultar o filtro de cabine FP2747? É para {a["vehicle_model"]} {y}, motor {en}, versão {v}.','Código e aplicação explicitados; localizar candidato sem inferir preço/estoque.','Filtro de cabine/ar-condicionado','search',[],[p['cd_item']],ev(p,a),False)
p=bycode['AV-36036'];a,y,en,v=app(p)
add(f'Quero o jogo de palhetas AV-36036 para {a["vehicle_model"]}. Anotei {y-1}, mas corrigindo: o ano é {y}, motor {en}, versão {v}. São as medidas 24/19.','A correção explícita do ano prevalece. A consulta pelo código não autoriza ampliar dimensões.','Jogo de palhetas dianteiras','search',[],[p['cd_item']],ev(p,a),False)
p=bycode['624 3947 000']
add('A oficina me passou 624 3947 000, mas eu quero só o platô; não quero disco nem rolamento. Tem a peça avulsa?','O código identifica kit com platô/disco/rolamento; não converter kit em avulso.','Platô avulso versus kit de embreagem','ask',['Confirmar a referência/medidas do platô e consultar disponibilidade de avulso sem assumir equivalência'],[],ev(p),None,[{'pergunta':'Esse código é do kit. Você tem código ou medidas do platô avulso e identificação do conjunto?','resposta':'Não tenho; vou pedir para a oficina.','acao_apos_resposta':'handoff'}])
p=bycode['6PK0975-DAYCO']
add('Preciso consultar a correia 6PK0975-DAYCO. Tenho a embalagem, mas não sei em qual carro vai ser montada.','Identificação exata permite consultar o produto; aplicação física permanece pendente.','Correia de acessórios identificada por código','search',[],[p['cd_item']],ev(p),False)
p=bycode['CAR CONTATO']
add('Quero duas latas do CAR CONTATO, limpa-contato elétrico de 300 ml. Não é desengripante.','Quantidade 2; volume por embalagem 300 ml; preservar negação de outra finalidade.','Limpa-contato elétrico/eletrônico','search',[],[p['cd_item']],ev(p,AP[p['id_item']][0]),False)
p=bycode['BF1551-12'];a,y,en,v=app(p)
add(f'Preciso de pastilha para {a["vehicle_model"]} {y}, motor {en}, versão {v}, mas não sei dizer se a oficina pediu dianteira ou traseira.','Não escolher o eixo pela única referência apresentada pelo gabarito.','Pastilha de freio','ask',['Eixo e identificação do sistema de freio'],[],ev(p,a),None,[{'pergunta':'É pastilha dianteira ou traseira e qual o sistema/desenho da peça instalada?','resposta':'A oficina confirmou traseira e passou o código BF1551-12.','acao_apos_resposta':'search','codigos_apos_resposta':[p['cd_item']]}])
p=bycode['KYB339418'];a,y,en,v=app(p)
add(f'Quero o amortecedor esquerdo do {a["vehicle_model"]} {y}, motor {en}, versão {v}. Me passaram o código KYB339418, consegue confirmar?','O código está descrito como dianteiro direito; não aceitar o código em detrimento do lado pedido.','Amortecedor de suspensão dianteiro','ask',['Resolver conflito entre lado esquerdo pedido e código de lado direito'],[],ev(p,a),None,[{'pergunta':'O código está cadastrado como direito. Você precisa do esquerdo ou a oficina corrigiu o lado?','resposta':'É o esquerdo mesmo; vou conferir o código correto.','acao_apos_resposta':'handoff'}])
p=bycode['PAT-9579']
add('Tenho o retentor PAT-9579 de 49,2 × 68,15 × 12,70 mm. Pode localizar pelo código? A oficina ainda vai confirmar o material do lábio.','Localizar candidato por código e dimensão é diferente de aprovar equivalência de material/perfil.','Retentor de eixo de entrada da caixa de redução/transferência','search',[],[p['cd_item']],ev(p),False)
p=bycode['PF1055/1X'];a,y,en,v=app(p)
add(f'Você tem o filtro de óleo PF1055/1X para {a["vehicle_model"]} {y}, motor {en}, versão {v}? Pode mostrar a referência; estoque eu confirmo depois.','Código exato e vínculo de aplicação declarados; não inventar estoque.','Filtro do óleo lubrificante','search',[],[p['cd_item']],ev(p,a),False)
absent='ZZZ-SEM-CADASTRO-20261027'
assert all(absent not in (p.get(f)or'')for p in X['products']for f in['cd_item','cd_fabricante','cd_original','search_text'])
add(f'Procure exatamente o código {absent}. Não quero equivalentes; se não houver essa referência cadastrada, me avise.','Ausência é do identificador literal neste snapshot, não de uma peça/aplicação do mundo real.','Consulta por referência literal inexistente','search',[],[],{'snapshot':'2026-10-19','closed_scope':'52798 registros de candidates.csv.gz; identificador literal ausente nos campos cd_item, cd_fabricante, cd_original e search_text. Não significa ausência comercial de uma peça equivalente.','lookup':absent},True)
originals={c['initial_message'].casefold().strip()for c in X['study']['cases']};assert not any(c['pedido_anonimizado'].casefold().strip()in originals for c in new)
dump('dez_novos_casos_sinteticos.json',{'schema_version':'1.0','status':'Preenchido como conjunto sintético; não são pedidos reais nem independentes. Gabaritos registrados para eventual execução futura, ainda não realizada.','source_snapshot':'2026-10-19','simulation':True,'cases':new})
dump('hash_gabarito_novos_casos.json',{'sha256':hashlib.sha256((O/'dez_novos_casos_sinteticos.json').read_bytes()).hexdigest(),'meaning':'Preserva a versão a partir desta entrega; não constitui pré-registro independente retroativo.','agent_executed':False})
print('10 casos sintéticos com evidência preenchidos; nenhum executado no agente.')
