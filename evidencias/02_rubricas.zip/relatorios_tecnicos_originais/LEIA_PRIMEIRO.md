# Avaliação final — estudo iniciado em 26/10/2026

1. Abra `relatorio_avaliacao_final.html` para metodologia, resultados e limites.
2. Use `leitor_conversas.html` para consultar todos os casos nas três repetições,
   comparar D/H e abrir os JSONs completos de conversas, buscas e tempos.
3. Encaminhe **somente `pacote_para_especialistas.zip`** aos dois profissionais
   qualificados, para revisão independente. As perguntas estão também em
   `para_especialistas/PERGUNTAS_PARA_O_ESPECIALISTA.md`.
4. Cada avaliador deve registrar sua interpretação antes de revelar A/B e
   exportar seu JSON. Há um lote inicial de 60 e acesso aos 371 casos.
   Mantenha a chave de identificação D/H e o pacote técnico com o autor até
   receber as revisões. As letras alternam por caso.
5. Consulte `tecnico/REPRODUCAO.md` para recalcular métricas, reexecutar o
   laboratório e incorporar formulários. Solicite também os dez novos pedidos
   do template com gabaritos congelados antes de rodar o sistema.

A bateria técnica contém 3408 execuções de caso: 371 categorias, 170 cenários
estruturais e 27 golden, duas configurações e três repetições. Os 604 testes
do agente e 33 do gateway também foram executados. Esses números não são
uma taxa de precisão comercial. A revisão humana está pendente e nenhum
formulário de especialista foi preenchido pelo agente.

`avaliacao_final_completa.zip` contém esta entrega para o autor, inclusive a
chave de identificação das configurações. Não o use como pacote de revisão cega.
Os pesos do modelo não foram duplicados; digest e dependências estão registrados.
`manifest_entrega.json` permite conferir os hashes dos arquivos entregues.
